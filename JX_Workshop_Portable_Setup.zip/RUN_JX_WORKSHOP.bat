@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title JX Workshop - Environment Setup and Launcher

set "APP=JX_Workshop_v3_2_1_9_3_8_4C1_3B_2_DETERMINISTIC_OFFSET_DEBUG.py"
set "REQ=requirements.txt"
set "PYEXE="

echo ============================================================
echo   JX WORKSHOP - AUTO ENVIRONMENT SETUP AND RUN
echo ============================================================
echo.

if not exist "%APP%" (
    echo [ERROR] Cannot find:
    echo         %APP%
    echo.
    echo Put this BAT file, requirements.txt and the Python file
    echo in the same folder.
    pause
    exit /b 1
)

rem ------------------------------------------------------------
rem 1. Find Python
rem ------------------------------------------------------------
where py >nul 2>nul
if not errorlevel 1 (
    set "PYEXE=py -3"
    goto :PY_FOUND
)

where python >nul 2>nul
if not errorlevel 1 (
    set "PYEXE=python"
    goto :PY_FOUND
)

rem ------------------------------------------------------------
rem 2. Python is missing - try installing with winget
rem ------------------------------------------------------------
echo [INFO] Python was not found.
echo [INFO] Trying to install Python 3.12 automatically...
echo.

where winget >nul 2>nul
if errorlevel 1 (
    echo [ERROR] winget is not available on this PC.
    echo.
    echo Please install Python manually from python.org.
    echo IMPORTANT: enable "Add python.exe to PATH" during setup.
    echo Then run this BAT file again.
    pause
    exit /b 1
)

winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements

if errorlevel 1 (
    echo.
    echo [ERROR] Automatic Python installation failed.
    echo Please install Python 3.12 manually, then run this BAT again.
    pause
    exit /b 1
)

rem Try common Python 3.12 install locations immediately.
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
    set "PYEXE=%LocalAppData%\Programs\Python\Python312\python.exe"
    goto :PY_FOUND
)

if exist "%ProgramFiles%\Python312\python.exe" (
    set "PYEXE=%ProgramFiles%\Python312\python.exe"
    goto :PY_FOUND
)

echo.
echo [INFO] Python was installed, but this BAT cannot see it yet.
echo Close this window and run RUN_JX_WORKSHOP.bat again.
pause
exit /b 0

:PY_FOUND
echo [OK] Python found.
%PYEXE% --version
if errorlevel 1 goto :PY_ERROR

rem ------------------------------------------------------------
rem 3. Verify pip
rem ------------------------------------------------------------
echo.
echo [INFO] Checking pip...
%PYEXE% -m pip --version >nul 2>nul
if errorlevel 1 (
    echo [INFO] pip is missing. Trying ensurepip...
    %PYEXE% -m ensurepip --upgrade
)

%PYEXE% -m pip --version >nul 2>nul
if errorlevel 1 (
    echo [ERROR] pip is not available.
    pause
    exit /b 1
)
echo [OK] pip is available.

rem ------------------------------------------------------------
rem 4. Install requirements
rem ------------------------------------------------------------
if exist "%REQ%" (
    echo.
    echo [INFO] Installing/updating required Python packages...
    %PYEXE% -m pip install --disable-pip-version-check -r "%REQ%"
    if errorlevel 1 (
        echo.
        echo [ERROR] Dependency installation failed.
        echo Check the Internet connection and try again.
        pause
        exit /b 1
    )
    echo [OK] Requirements are ready.
)

rem ------------------------------------------------------------
rem 5. Verify tkinter - required by the GUI
rem ------------------------------------------------------------
echo.
echo [INFO] Checking Tkinter GUI support...
%PYEXE% -c "import tkinter; print('[OK] Tkinter', tkinter.TkVersion)" 
if errorlevel 1 (
    echo.
    echo [ERROR] Tkinter is missing from this Python installation.
    echo Install the standard Windows Python distribution with Tcl/Tk support.
    pause
    exit /b 1
)

rem ------------------------------------------------------------
rem 6. Run JX Workshop
rem ------------------------------------------------------------
echo.
echo ============================================================
echo   STARTING JX WORKSHOP
echo ============================================================
echo.

%PYEXE% "%APP%"
set "EXITCODE=%ERRORLEVEL%"

echo.
if not "%EXITCODE%"=="0" (
    echo [ERROR] JX Workshop exited with code %EXITCODE%.
    echo Keep this window open to inspect the error above.
    pause
) else (
    echo [OK] JX Workshop closed normally.
)

exit /b %EXITCODE%

:PY_ERROR
echo.
echo [ERROR] Python exists but cannot be executed correctly.
pause
exit /b 1
