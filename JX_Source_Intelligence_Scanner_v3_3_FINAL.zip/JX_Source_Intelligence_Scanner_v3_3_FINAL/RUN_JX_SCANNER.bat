@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title JX Source Intelligence Scanner - Setup and Run

set "APP=JX_Source_Intelligence_Scanner_v3_3_FINAL.py"
set "REQ=requirements.txt"
set "PYEXE="
set "PYARGS="

echo ============================================================
echo   JX Source Intelligence Scanner - Automatic Setup ^& Run
echo ============================================================
echo.

rem ------------------------------------------------------------
rem 1. Find Python (prefer Windows py launcher)
rem ------------------------------------------------------------
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -c "import sys; print(sys.version)" >nul 2>nul
    if not errorlevel 1 (
        set "PYEXE=py"
        set "PYARGS=-3"
    )
)

if not defined PYEXE (
    where python >nul 2>nul
    if not errorlevel 1 (
        python -c "import sys; print(sys.version)" >nul 2>nul
        if not errorlevel 1 set "PYEXE=python"
    )
)

if not defined PYEXE goto :NO_PYTHON

echo [1/5] Python found:
%PYEXE% %PYARGS% --version
echo.

rem ------------------------------------------------------------
rem 2. Ensure pip exists
rem ------------------------------------------------------------
echo [2/5] Checking pip...
%PYEXE% %PYARGS% -m pip --version >nul 2>nul
if errorlevel 1 (
    echo     pip not found. Trying to install pip with ensurepip...
    %PYEXE% %PYARGS% -m ensurepip --upgrade
    if errorlevel 1 goto :PIP_ERROR
)

echo     pip is ready.
echo.

rem ------------------------------------------------------------
rem 3. Install/update requirements
rem ------------------------------------------------------------
echo [3/5] Installing required packages...
if exist "%REQ%" (
    %PYEXE% %PYARGS% -m pip install -r "%REQ%"
    if errorlevel 1 goto :REQUIREMENTS_ERROR
) else (
    echo     WARNING: %REQ% was not found. Skipping package installation.
)
echo.

rem ------------------------------------------------------------
rem 4. Verify tkinter GUI support
rem ------------------------------------------------------------
echo [4/5] Checking tkinter GUI support...
%PYEXE% %PYARGS% -c "import tkinter" >nul 2>nul
if errorlevel 1 goto :TK_ERROR
echo     tkinter is ready.
echo.

rem ------------------------------------------------------------
rem 5. Launch application
rem ------------------------------------------------------------
echo [5/5] Starting %APP% ...
if not exist "%APP%" goto :APP_MISSING

echo.
start "JX Source Intelligence Scanner" %PYEXE% %PYARGS% "%APP%"
exit /b 0

:NO_PYTHON
echo [ERROR] Python 3 was not found on this computer.
echo.
echo This launcher can install Python automatically if Windows Package Manager is available.
where winget >nul 2>nul
if errorlevel 1 goto :NO_WINGET

echo Installing Python 3 with winget...
winget install -e --id Python.Python.3.13 --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
    echo.
    echo [ERROR] Automatic Python installation failed.
    goto :MANUAL_PYTHON
)

echo.
echo Python installation finished.
echo Please CLOSE this window and run RUN_JX_SCANNER.bat again.
echo.
pause
exit /b 0

:NO_WINGET
echo Windows Package Manager ^(winget^) was not found.
goto :MANUAL_PYTHON

:MANUAL_PYTHON
echo Please install Python 3 from python.org.
echo IMPORTANT: during installation, enable "Add python.exe to PATH"
echo and keep "tcl/tk and IDLE" enabled.
echo Then run this BAT file again.
echo.
pause
exit /b 1

:PIP_ERROR
echo.
echo [ERROR] Could not initialize pip.
echo Try repairing/reinstalling the official Python for Windows installation.
echo.
pause
exit /b 1

:REQUIREMENTS_ERROR
echo.
echo [ERROR] pip could not install the packages from %REQ%.
echo Check the Internet connection, then run this BAT file again.
echo.
pause
exit /b 1

:TK_ERROR
echo.
echo [ERROR] tkinter is missing from this Python installation.
echo tkinter cannot normally be installed with pip.
echo Repair/reinstall the official Python for Windows and enable Tcl/Tk support.
echo.
pause
exit /b 1

:APP_MISSING
echo.
echo [ERROR] %APP% was not found in this folder.
echo Keep this BAT, requirements.txt and the PY file in the same folder.
echo.
pause
exit /b 1
