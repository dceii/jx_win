import binascii
import math
import zlib
import os
import re
import json
import hashlib
import struct
import shutil
import sys
import csv
import threading
import queue
import traceback
import subprocess
import time
import ctypes
import sqlite3
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict

APP_TITLE = "JX Workshop v3"
VERSION = "3.0"

# Optional Windows .ICO used for the Tk window icon.
# Set this to an absolute path, or keep a filename next to the .py/.exe.
APP_ICON_PATH = r"JX_Workshop.ico"


SPRITE_SHEET_PROMPT_TEMPLATE = r"""JX / SWORDONLINE GROUND AURA SPRITE SHEET
STRICT ISOMETRIC GROUND-PLANE TEMPLATE

Create ONE animated sprite sheet for a ground aura effect designed specifically for the JX / SwordOnline Windows game.
This effect must appear FLAT ON THE GROUND beneath the player.
It must NOT appear as a vertical portal. It must NOT face the camera directly. It must NOT look like a front-facing circle.

==================================================
CAMERA AND PERSPECTIVE — HIGHEST PRIORITY
==================================================
Use an isometric / oblique top-down RPG camera similar to classic JX / SwordOnline.
The magical ring lies horizontally on the ground plane. The camera looks downward toward the ground at an oblique angle.
Because of this perspective, the circular ring must appear as a HORIZONTAL ELLIPSE. The vertical dimension must be strongly compressed.
Target visual proportions: ellipse width : ellipse height ≈ 2.2 : 1.
If the aura is approximately 120 pixels wide, its visible ellipse height should be approximately 50–60 pixels.
Do NOT render a perfect circle. Do NOT render the ring perpendicular to the ground. Do NOT render it as a portal standing upright.

==================================================
PLAYER POSITION / GROUND CONTACT
==================================================
The aura is designed to sit underneath a standing player. Imagine an invisible JX character standing exactly at the center of the aura.
The character's feet would touch the center of the ellipse. The aura must surround the feet horizontally.
The front half appears closer to the camera; the rear half appears farther away and may appear slightly higher in the image.
The character must look like they are STANDING ON TOP OF the magical effect, not passing through a vertical ring.

==================================================
GROUND-PLANE ORIENTATION LOCK
==================================================
The ground plane must remain identical in every frame.
Do not change: camera elevation, perspective, ellipse compression, orientation, center, scale, or ground-plane angle.
The aura may rotate internally, but the ellipse itself must remain fixed to the ground.

==================================================
SPRITE SHEET SPECIFICATION
==================================================
TOTAL FRAMES: {frames}
GRID: {cols} columns × {rows} rows
FRAME ORDER:
{order}
Read LEFT TO RIGHT, then TOP TO BOTTOM.

==================================================
FRAME CANVAS
==================================================
Each frame: {fw} × {fh} pixels
Full sprite sheet: {sw} × {sh} pixels
Transparent RGBA background. No spacing. No gutters. No borders. No text. No frame numbers.

==================================================
FIXED GROUND ANCHOR
==================================================
Each frame uses the same ground anchor:
ANCHOR X = {ax} px
ANCHOR Y = {ay} px
The center point where the player's feet would stand must remain exactly at this position in every frame.
The effect must never drift horizontally or vertically.

==================================================
AURA SIZE
==================================================
The main ground aura should occupy approximately: Width 115–130 px; visible ellipse height 45–60 px.
Keep sufficient transparent space above and below the effect. Do NOT fill the entire frame vertically.

==================================================
EFFECT DESIGN
==================================================
Create a luminous cyan-blue wuxia magical ground aura containing a horizontal elliptical energy ring, rotating cyan magical currents, thin luminous runes, soft blue flame-like wisps, small magical particles, subtle energy arcs, and bright highlights concentrated around the ring.
The effect should feel like a powerful cultivation / martial arts aura beneath the player's feet.

==================================================
DEPTH CUES
==================================================
Rear arc slightly thinner and less prominent; front arc slightly brighter and visually stronger.
Energy streaks follow the horizontal ground ellipse. Particles may rise slightly upward from the ring.
No vertical circular wall. No tunnel or portal depth.
The effect must visually read as MAGICAL ENERGY LYING ON THE GROUND, not A VERTICAL MAGICAL PORTAL.

==================================================
ANIMATION
==================================================
Create a seamless {frames}-frame loop. The ring remains fixed in shape, position and perspective.
Only the internal magical energy rotates and pulses. Frame 00 begins the cycle. Frames 01–{last:02d} progressively rotate clockwise.
Frame {last:02d} must transition smoothly back into Frame 00.
Do not rotate the physical ground ellipse itself. Do not tilt the ground plane. Do not move the anchor.

==================================================
ABSOLUTE NEGATIVE CONSTRAINTS
==================================================
NO front-facing circle. NO perfect circular portal. NO vertical ring. NO standing portal. NO tunnel. NO camera-facing disc.
NO perspective changes between frames. NO changing ellipse height. NO changing camera angle. NO player character. NO horse.
NO environment. NO floor texture. NO shadows outside the magical effect. NO text. NO watermark.
"""

TEXT_EXTENSIONS = {
    ".ini", ".cfg", ".conf", ".txt", ".tab", ".csv", ".xml", ".json",
    ".lua", ".lst", ".list", ".dat", ".bat", ".cmd", ".log"
}
HASH_EXTENSIONS = {".spr", ".pak", ".ini", ".cfg", ".txt", ".tab", ".lua", ".exe", ".dll"}
DEFAULT_EXCLUDED_DIR_NAMES = {".git", ".svn", ".hg", "__pycache__", ".vs", ".idea", ".vscode"}
NPCRES_HINTS = ("settings/npcres", "spr/npcres", "spr/player", "spr/character")
RESOURCE_TOKEN_RE = re.compile(r'(?i)(?:[A-Za-z]:)?[\\/][^\r\n\t"\'<>|]+?\.(?:spr|txt|tab|ini|lua|wav|jpg|bmp|pak)\b|[^\s"\'<>|]+?[\\/][^\r\n\t"\'<>|]+?\.(?:spr|txt|tab|ini|lua|wav|jpg|bmp|pak)\b')
PAK_NAME_RE = re.compile(r'(?i)([^\r\n\t"\']+?\.pak)\b')

XPACK_HEADER = struct.Struct("<4sIIII12s")      # 32 bytes
XPACK_INDEX = struct.Struct("<IIII")            # uId,uOffset,lSize,lCompressSizeFlag bits
TYPE_METHOD_FILTER = 0x0F000000
TYPE_FILTER = 0xFF000000
TYPE_FRAME = 0x10000000
TYPE_NAMES = {0x00000000:"NONE", 0x01000000:"UCL", 0x02000000:"BZIP2", 0x20000000:"UCL_2ND"}


def display_safe(s):
    if not isinstance(s, str):
        s = str(s)
    return s.encode("utf-8", "backslashreplace").decode("utf-8")


def write_text_safe(path, text):
    with open(path, "w", encoding="utf-8", errors="backslashreplace", newline="") as f:
        f.write(text)


def safe_read_text(path: Path, max_bytes=12 * 1024 * 1024):
    try:
        if path.stat().st_size > max_bytes:
            return None, None
    except Exception:
        return None, None
    for enc in ["utf-8-sig", "utf-8", "gbk", "cp936", "big5", "cp1252", "latin-1"]:
        try:
            text = path.read_text(encoding=enc)
            if "\x00" in text[:4096]:
                continue
            return text, enc
        except Exception:
            pass
    return None, None


def sha1_file(path: Path):
    h = hashlib.sha1()
    try:
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""


def normalize_virtual_path(value: str):
    """Approximate g_GetPackPath + KPakList leading slash behavior for client-root virtual paths."""
    s = value.strip().strip('"\'').replace("/", "\\")
    # remove drive if accidentally captured
    if len(s) >= 2 and s[1] == ":":
        s = s[2:]
    parts = []
    for part in s.split("\\"):
        if part in ("", "."):
            continue
        if part == "..":
            if parts:
                parts.pop()
        else:
            parts.append(part)
    s = "\\".join(parts).lower()
    return "\\" + s if s else "\\"


def virtual_bytes(path: str):
    """JX is MBCS/VC6. Prefer CP936 bytes; preserve odd legacy names with fallback."""
    p = normalize_virtual_path(path)
    for enc in ("gbk", "cp936", "latin-1"):
        try:
            return p.encode(enc)
        except Exception:
            pass
    return p.encode("utf-8", "surrogatepass")


def jx_filename_to_id(path: str):
    """Port of KPakList::FileNameToId, including unsigned 32-bit overflow semantics."""
    data = virtual_bytes(path)
    uid = 0
    index = 0
    for b in data:
        index += 1
        # MSVC x86 char is signed by default. ASCII uppercase branch occurs before signed conversion matters.
        if 0x41 <= b <= 0x5A:
            c = b + 0x20
        else:
            c = b if b < 0x80 else b - 0x100
        term = (index * c) & 0xFFFFFFFF
        uid = (uid + term) & 0xFFFFFFFF
        uid = (uid % 0x8000000B) & 0xFFFFFFFF
        uid = (uid * 0xFFFFFFEF) & 0xFFFFFFFF
    return (uid ^ 0x12345678) & 0xFFFFFFFF


def compression_info(flag):
    frame = bool(flag & TYPE_FRAME)
    method = flag & TYPE_METHOD_FILTER
    comp_size = flag & (~TYPE_FILTER & 0xFFFFFFFF)
    return TYPE_NAMES.get(method, "0x%08X" % method), frame, comp_size


def parse_xpack(path: Path):
    result = {"valid": False, "error": "", "count": 0, "index_offset": 0, "data_offset": 0,
              "crc32": 0, "entries": [], "size": 0}
    try:
        size = path.stat().st_size
        result["size"] = size
        if size < XPACK_HEADER.size:
            result["error"] = "too_small"
            return result
        with path.open("rb") as f:
            raw = f.read(XPACK_HEADER.size)
            if len(raw) != XPACK_HEADER.size:
                result["error"] = "header_short_read"
                return result
            sig, count, index_off, data_off, crc32, reserved = XPACK_HEADER.unpack(raw)
            result.update(count=count, index_offset=index_off, data_offset=data_off, crc32=crc32)
            if sig != b"PACK":
                result["error"] = "bad_signature:%r" % (sig,)
                return result
            if count == 0 or index_off < XPACK_HEADER.size or index_off >= size or data_off < XPACK_HEADER.size or data_off >= size:
                result["error"] = "invalid_header_ranges"
                return result
            table_size = count * XPACK_INDEX.size
            if index_off + table_size > size:
                result["error"] = "index_out_of_range"
                return result
            f.seek(index_off)
            raw_index = f.read(table_size)
            if len(raw_index) != table_size:
                result["error"] = "index_short_read"
                return result
            entries = []
            prev_id = None
            bad_offsets = 0
            unsorted = 0
            for i in range(count):
                uid, off, orig_size, flag = XPACK_INDEX.unpack_from(raw_index, i * XPACK_INDEX.size)
                method, frame, comp_size = compression_info(flag)
                # frame-compressed SPR has special internal layout, but offset must still be inside file.
                if off >= size:
                    bad_offsets += 1
                if prev_id is not None and uid < prev_id:
                    unsorted += 1
                prev_id = uid
                entries.append((uid, off, orig_size, flag, method, frame, comp_size))
            if bad_offsets:
                result["error"] = "bad_entry_offsets:%d" % bad_offsets
                return result
            result["entries"] = entries
            result["unsorted_ids"] = unsorted
            result["valid"] = True
            return result
    except Exception as e:
        result["error"] = "%s: %s" % (type(e).__name__, e)
        return result


def extract_package_ini(client: Path):
    """Read package.ini using the same [Package] Path + numeric keys model as KPakList::Open."""
    candidates = [client / "package.ini", client / "Package.ini", client / "PACKAGE.INI"]
    ini_path = next((p for p in candidates if p.exists()), None)
    if not ini_path:
        return None, "", [], "package.ini not found"
    text, enc = safe_read_text(ini_path)
    if text is None:
        return ini_path, "", [], "package.ini unreadable"
    section = None
    package_path = ""
    numbered = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith((";", "#")):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip().lower()
            continue
        if section != "package" or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip().strip('"\'')
        if k.lower() == "path":
            package_path = v
        elif k.isdigit():
            numbered[int(k)] = v
    ordered = []
    i = 0
    while i in numbered and numbered[i]:
        ordered.append((i, numbered[i]))
        i += 1
    return ini_path, package_path, ordered, "encoding=%s" % enc


def resolve_pak_path(client: Path, package_path: str, pak_name: str):
    base = Path(package_path.replace("\\", os.sep).replace("/", os.sep)) if package_path else Path("")
    # g_GetFullPath is rooted by engine working path; for scanner try client-relative first.
    if base.is_absolute():
        p = base / pak_name
    else:
        p = client / base / pak_name
    if p.exists():
        return p
    # fallback case-insensitive basename lookup in client tree done by caller if needed
    return p


def collect_resource_tokens(text):
    out = set()
    for m in RESOURCE_TOKEN_RE.finditer(text):
        token = m.group(0).strip().strip('"\'').rstrip(",;)")
        if token:
            out.add(normalize_virtual_path(token))
    return out


def split_legacy_row(line):
    """Split common JX tabular formats while preserving empty cells where possible."""
    if "\t" in line:
        return line.rstrip("\r\n").split("\t")
    if "," in line and line.count(",") >= 2:
        try:
            return next(csv.reader([line]))
        except Exception:
            pass
    return re.split(r"\s{2,}", line.strip()) if line.strip() else []


def infer_character_part(source_name, token):
    s=(source_name+" "+token).lower()
    if any(x in s for x in ("_bd", "body", "bodyfile")): return "BODY"
    if any(x in s for x in ("_hd", "head")): return "HEAD"
    if any(x in s for x in ("_rw", "weapon", "weapen")): return "WEAPON"
    if any(x in s for x in ("_cl", "cloth", "clothes", "armor")): return "CLOTHES"
    if any(x in s for x in ("_hh", "_ht", "horse", "mount", "ngua")): return "HORSE/MOUNT"
    if any(x in s for x in ("effect", "_effect", "magic")): return "EFFECT"
    if "shadow" in s: return "SHADOW"
    if "sound" in s or token.lower().endswith(".wav"): return "SOUND"
    return "UNKNOWN"


def resource_candidate_paths(token, source_rel):
    """Generate conservative virtual-path candidates for an NPCRes table cell."""
    raw=token.strip().strip('"\'').rstrip(',;)')
    if not raw: return []
    ext=Path(raw.replace('\\','/')).suffix.lower()
    out=[]
    def add(v):
        try: nv=normalize_virtual_path(v)
        except Exception: return
        if nv not in out: out.append(nv)
    if '\\' in raw or '/' in raw:
        add(raw)
    else:
        if ext in ('.txt','.tab','.ini'):
            add('settings/npcres/'+raw)
        elif ext == '.spr':
            # Most player component tables resolve under ResFilePath; these are the useful common roots.
            for root in ('spr/npcres/human/','spr/npcres/style/','spr/npcres/','settings/npcres/'):
                add(root+raw)
        elif ext == '.wav':
            add('sound/'+raw)
    # also source-directory-relative for nested npcres tables
    srcdir=str(Path(source_rel).parent).replace('\\','/')
    if srcdir and srcdir != '.': add(srcdir+'/'+raw)
    return out


def copy_upload_bundle(output: Path, names, log=None):
    upload=output/'upload'
    try:
        if upload.exists():
            shutil.rmtree(upload)
        upload.mkdir(parents=True, exist_ok=True)
        copied=[]
        for name in names:
            src=output/name
            if src.exists() and src.is_file():
                shutil.copy2(src, upload/name)
                copied.append(name)
        manifest=['JX Client Scanner upload bundle', ''] + copied
        write_text_safe(upload/'UPLOAD_MANIFEST.txt', '\n'.join(manifest))
        if log: log(f"Upload bundle: {upload} ({len(copied)} files)")
        return copied
    except Exception as e:
        if log: log(f"ERROR creating upload bundle: {e}")
        return []


SPR_HEADER = struct.Struct("<4sHHHHHHHH6H")
SPR_OFFS = struct.Struct("<II")
SPR_PACK_FRAME = struct.Struct("<ii")


def ucl_nrv2b_decompress_8_py(src: bytes, expected_size: int) -> bytes:
    """Pure Python port of Engine/Src/ucl/n2b_d.c + getbit_8.
    Used so the scanner works even when 64-bit Python cannot load the legacy 32-bit ucl1.dll.
    """
    ilen = 0
    bb = 0
    out = bytearray()
    last_m_off = 1

    def getbit():
        nonlocal bb, ilen
        if bb & 0x7f:
            bb = bb * 2
        else:
            if ilen >= len(src):
                raise ValueError("UCL input overrun while reading bit")
            bb = src[ilen] * 2 + 1
            ilen += 1
        return (bb >> 8) & 1

    while True:
        while getbit():
            if ilen >= len(src):
                raise ValueError("UCL input overrun while copying literal")
            if len(out) >= expected_size:
                raise ValueError("UCL output overrun")
            out.append(src[ilen]); ilen += 1

        m_off = 1
        while True:
            m_off = m_off * 2 + getbit()
            if m_off > 0xFFFFFF + 3:
                raise ValueError("UCL lookbehind offset overflow")
            if getbit():
                break

        if m_off == 2:
            m_off = last_m_off
        else:
            if ilen >= len(src):
                raise ValueError("UCL input overrun while reading offset")
            m_off = (m_off - 3) * 256 + src[ilen]
            ilen += 1
            if m_off == 0xFFFFFFFF:
                break
            m_off += 1
            last_m_off = m_off

        m_len = getbit()
        m_len = m_len * 2 + getbit()
        if m_len == 0:
            m_len = 1
            while True:
                m_len = m_len * 2 + getbit()
                if m_len >= expected_size:
                    raise ValueError("UCL match length overflow")
                if getbit():
                    break
            m_len += 2
        if m_off > 0xD00:
            m_len += 1
        if m_off > len(out):
            raise ValueError("UCL lookbehind overrun")
        copy_count = m_len + 1
        if len(out) + copy_count > expected_size:
            raise ValueError("UCL output overrun during match")
        pos = len(out) - m_off
        for _ in range(copy_count):
            out.append(out[pos]); pos += 1

    if len(out) != expected_size:
        raise ValueError(f"UCL size mismatch: got {len(out)}, expected {expected_size}")
    return bytes(out)


def native_extract_xpack_entry(pak_path: Path, entry, virtual_path: str, dest_root: Path):
    """Extract one XPack entry according to XPackFile.cpp / KPakMake.cpp.
    Returns (status, output_rel, detail, extracted_size).
    """
    uid, off, orig_size, flag, method, frame, comp_size = entry
    method_bits = flag & TYPE_METHOD_FILTER
    try:
        with pak_path.open('rb') as f:
            f.seek(off)
            packed = f.read(comp_size)
        if len(packed) != comp_size:
            return 'READ_FAIL', '', f'short read {len(packed)}/{comp_size}', 0

        if not frame:
            if method_bits == 0:
                data = packed
                if len(data) != orig_size:
                    # Legacy update-Pak anomaly probe: never trust it unless UCL produces exact lSize.
                    try:
                        probed = ucl_nrv2b_decompress_8_py(packed, orig_size)
                        if len(probed) != orig_size:
                            return 'VERIFY_FAIL', '', f'NONE size {len(data)} != {orig_size}', len(data)
                        data = probed
                        method = 'LEGACY_UCL_PROBE'
                    except Exception as probe_e:
                        return 'VERIFY_FAIL', '', f'NONE size {len(data)} != {orig_size}; UCL probe failed: {probe_e}', len(data)
            elif method_bits in (0x01000000, 0x20000000):
                data = ucl_nrv2b_decompress_8_py(packed, orig_size)
            elif method_bits == 0x02000000:
                return 'UNSUPPORTED_BZIP2', '', 'BZIP2 branch is disabled/commented in source', 0
            else:
                return 'UNSUPPORTED_METHOD', '', f'flag=0x{flag:08X}', 0
        else:
            if method_bits not in (0x01000000, 0x20000000):
                return 'UNSUPPORTED_FRAME_METHOD', '', f'method={method}', 0
            if len(packed) < SPR_HEADER.size:
                return 'SPR_HEADER_FAIL', '', 'packed SPR shorter than header', 0
            vals = SPR_HEADER.unpack_from(packed, 0)
            comment = vals[0]; frames = vals[5]; colors = vals[6]
            if comment[:3] != b'SPR':
                return 'SPR_HEADER_FAIL', '', f'bad comment={comment!r}', 0
            prefix_len = SPR_HEADER.size + colors * 3
            table_len = frames * SPR_PACK_FRAME.size
            if prefix_len + table_len > len(packed):
                return 'SPR_TABLE_FAIL', '', f'frame table outside packed entry frames={frames}', 0
            prefix = packed[:prefix_len]
            frame_table = [SPR_PACK_FRAME.unpack_from(packed, prefix_len + i*8) for i in range(frames)]
            cursor = prefix_len + table_len
            frame_blobs=[]; offs=[]; out_off=0
            for i,(csize, usize_signed) in enumerate(frame_table):
                if csize < 0 or cursor + csize > len(packed):
                    return 'SPR_FRAME_READ_FAIL','',f'frame {i} csize={csize}',0
                chunk=packed[cursor:cursor+csize]; cursor += csize
                if usize_signed < 0:
                    expected=-usize_signed
                    if len(chunk) != expected:
                        return 'SPR_FRAME_VERIFY_FAIL','',f'raw frame {i}: {len(chunk)} != {expected}',0
                    blob=chunk
                else:
                    expected=usize_signed
                    blob=ucl_nrv2b_decompress_8_py(chunk, expected)
                offs.append((out_off,len(blob))); frame_blobs.append(blob); out_off += len(blob)
            data = prefix + b''.join(SPR_OFFS.pack(a,b) for a,b in offs) + b''.join(frame_blobs)
            if len(data) != orig_size:
                return 'SPR_REBUILD_SIZE_MISMATCH','',f'rebuilt={len(data)} expected={orig_size}',len(data)

        rel = normalize_virtual_path(virtual_path).lstrip('\\').replace('\\', os.sep)
        dst = dest_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(data)
        return 'OK', str(dst.relative_to(dest_root).as_posix()), f'method={method}; frame={int(frame)}', len(data)
    except Exception as e:
        return 'EXTRACT_ERROR', '', f'{type(e).__name__}: {e}', 0

def native_read_xpack_entry_bytes(pak_path: Path, entry):
    """Read/decompress an XPack entry directly to memory. No output file is created."""
    uid, off, orig_size, flag, method, frame, comp_size = entry
    method_bits = flag & TYPE_METHOD_FILTER
    with Path(pak_path).open('rb') as f:
        f.seek(off)
        packed = f.read(comp_size)
    if len(packed) != comp_size:
        raise ValueError(f'XPack short read {len(packed)}/{comp_size}')

    if not frame:
        if method_bits == 0:
            if len(packed) == orig_size:
                return packed, f'method=NONE; frame=0'
            # Same verified legacy probe as V4 native extractor.
            data = ucl_nrv2b_decompress_8_py(packed, orig_size)
            return data, 'method=LEGACY_UCL_PROBE; frame=0'
        if method_bits in (0x01000000, 0x20000000):
            data = ucl_nrv2b_decompress_8_py(packed, orig_size)
            return data, f'method={method}; frame=0'
        if method_bits == 0x02000000:
            raise ValueError('BZIP2 unsupported in this source branch')
        raise ValueError(f'Unsupported XPack method flag=0x{flag:08X}')

    if method_bits not in (0x01000000, 0x20000000):
        raise ValueError(f'Unsupported SPR frame method={method}')
    if len(packed) < SPR_HEADER.size:
        raise ValueError('Packed SPR shorter than SPRHEAD')
    vals = SPR_HEADER.unpack_from(packed, 0)
    comment, frames, colors = vals[0], vals[5], vals[6]
    if not comment.startswith(b'SPR'):
        raise ValueError(f'Packed frame SPR bad signature={comment!r}')
    prefix_len = SPR_HEADER.size + colors * 3
    table_len = frames * SPR_PACK_FRAME.size
    if prefix_len + table_len > len(packed):
        raise ValueError('SPR frame table outside packed entry')
    prefix = packed[:prefix_len]
    table = [SPR_PACK_FRAME.unpack_from(packed, prefix_len+i*8) for i in range(frames)]
    cursor = prefix_len + table_len
    frame_blobs, offs = [], []
    out_off = 0
    for i,(csize,usize_signed) in enumerate(table):
        if csize < 0 or cursor + csize > len(packed):
            raise ValueError(f'SPR frame {i} invalid compressed size={csize}')
        chunk = packed[cursor:cursor+csize]
        cursor += csize
        if usize_signed < 0:
            blob = chunk
            expected = -usize_signed
            if len(blob) != expected:
                raise ValueError(f'SPR raw frame {i} size {len(blob)} != {expected}')
        else:
            blob = ucl_nrv2b_decompress_8_py(chunk, usize_signed)
        offs.append((out_off, len(blob)))
        frame_blobs.append(blob)
        out_off += len(blob)
    data = prefix + b''.join(SPR_OFFS.pack(a,b) for a,b in offs) + b''.join(frame_blobs)
    if len(data) != orig_size:
        raise ValueError(f'SPR rebuild {len(data)} != original {orig_size}')
    return data, f'method={method}; frame=1'


def parse_spr_bytes(raw: bytes, source_name='<memory>'):
    if len(raw) < SPR_HEADER.size:
        raise ValueError('File quá ngắn để là SPR')
    base = 0
    vals = SPR_HEADER.unpack_from(raw,0)
    if not vals[0].startswith(b'SPR'):
        pos = raw.find(b'SPR\x00',1,4096)
        if pos < 0:
            hx=' '.join(f'{b:02X}' for b in raw[:24])
            raise ValueError(f'Signature không phải SPR. First bytes: {hx}')
        base = pos
        vals = SPR_HEADER.unpack_from(raw,base)
    comment,width,height,cx,cy,frames,colors,directions,interval,*reserved = vals
    if frames <= 0 or frames > 65535:
        raise ValueError(f'Frames không hợp lệ: {frames}')
    if colors <= 0 or colors > 256:
        raise ValueError(f'Colors không hợp lệ: {colors}')
    pal_off = base + SPR_HEADER.size
    pal_end = pal_off + colors*3
    tab_end = pal_end + frames*SPR_OFFS.size
    if tab_end > len(raw):
        raise ValueError('Palette/offset table vượt kích thước SPR')
    palette=[tuple(raw[pal_off+i*3:pal_off+i*3+3]) for i in range(colors)]
    offsets=[SPR_OFFS.unpack_from(raw,pal_end+i*8) for i in range(frames)]
    return {
        'path':Path(str(source_name)),'source_name':str(source_name),'data':raw,
        'width':width,'height':height,'center_x':cx,'center_y':cy,
        'frames':frames,'colors':colors,'directions':directions,'interval':interval,
        'palette':palette,'offsets':offsets,'frame_base':tab_end,'embedded_offset':base
    }

# ---------------- V4.4 PNG -> JX SPR builder ----------------

def png_write_rgba(path,w,h,rgba):
    raw=bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw.extend(bytes(rgba[y*w+x]))
    def chunk(typ,data):
        return struct.pack('>I',len(data))+typ+data+struct.pack('>I',binascii.crc32(typ+data)&0xffffffff)
    out=PNG_SIG+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(bytes(raw),9))+chunk(b'IEND',b'')
    Path(path).write_bytes(out)


PNG_SIG=b'\x89PNG\r\n\x1a\n'

def png_read_rgba(path: Path):
    """Minimal PNG reader: supports non-interlaced 8-bit RGB/RGBA/paletted/gray."""
    raw=Path(path).read_bytes()
    if not raw.startswith(PNG_SIG):
        raise ValueError('Không phải PNG hợp lệ')
    pos=8; chunks=[]; ihdr=None; palette=None; trns=None; idat=bytearray()
    while pos+12<=len(raw):
        ln=struct.unpack('>I',raw[pos:pos+4])[0]
        typ=raw[pos+4:pos+8]; dat=raw[pos+8:pos+8+ln]
        pos+=12+ln
        if typ==b'IHDR': ihdr=struct.unpack('>IIBBBBB',dat)
        elif typ==b'PLTE': palette=[tuple(dat[i:i+3]) for i in range(0,len(dat),3)]
        elif typ==b'tRNS': trns=dat
        elif typ==b'IDAT': idat.extend(dat)
        elif typ==b'IEND': break
    if not ihdr: raise ValueError('PNG thiếu IHDR')
    w,h,bit_depth,color_type,comp,flt,interlace=ihdr
    if bit_depth!=8 or interlace!=0:
        raise ValueError('V4.4 chỉ hỗ trợ PNG 8-bit non-interlaced')
    if color_type==6: bpp=4
    elif color_type==2: bpp=3
    elif color_type==3: bpp=1
    elif color_type==0: bpp=1
    elif color_type==4: bpp=2
    else: raise ValueError(f'PNG color type {color_type} chưa hỗ trợ')
    dec=zlib.decompress(bytes(idat))
    stride=w*bpp; prev=bytearray(stride); rows=[]; off=0
    def paeth(a,b,c):
        p=a+b-c; pa=abs(p-a); pb=abs(p-b); pc=abs(p-c)
        return a if pa<=pb and pa<=pc else b if pb<=pc else c
    for y in range(h):
        ft=dec[off]; off+=1
        scan=bytearray(dec[off:off+stride]); off+=stride
        for x in range(stride):
            a=scan[x-bpp] if x>=bpp else 0
            b=prev[x] if prev else 0
            c=prev[x-bpp] if prev and x>=bpp else 0
            if ft==1: scan[x]=(scan[x]+a)&255
            elif ft==2: scan[x]=(scan[x]+b)&255
            elif ft==3: scan[x]=(scan[x]+((a+b)//2))&255
            elif ft==4: scan[x]=(scan[x]+paeth(a,b,c))&255
            elif ft!=0: raise ValueError(f'PNG filter {ft} chưa hỗ trợ')
        rows.append(bytes(scan)); prev=scan
    rgba=[]
    for row in rows:
        if color_type==6:
            rgba.extend(tuple(row[i:i+4]) for i in range(0,len(row),4))
        elif color_type==2:
            rgba.extend((row[i],row[i+1],row[i+2],255) for i in range(0,len(row),3))
        elif color_type==3:
            if not palette: raise ValueError('PNG indexed thiếu PLTE')
            for idx in row:
                r,g,b=palette[idx]; a=trns[idx] if trns and idx<len(trns) else 255
                rgba.append((r,g,b,a))
        elif color_type==0:
            rgba.extend((g,g,g,255) for g in row)
        elif color_type==4:
            rgba.extend((row[i],row[i],row[i],row[i+1]) for i in range(0,len(row),2))
    return {'width':w,'height':h,'rgba':rgba,'path':Path(path)}

def nearest_palette_index(rgb,palette):
    r,g,b=rgb
    best=0; bd=1<<62
    for i,(pr,pg,pb) in enumerate(palette):
        d=(r-pr)*(r-pr)+(g-pg)*(g-pg)+(b-pb)*(b-pb)
        if d<bd: bd=d; best=i
    return best

def median_cut_palette(images,max_colors=256,alpha_threshold=1):
    # Collect weighted colors using coarse 5-bit bins to bound memory.
    hist={}
    for im in images:
        for r,g,b,a in im['rgba']:
            if a<alpha_threshold: continue
            key=(r>>3,g>>3,b>>3)
            cnt,sr,sg,sb=hist.get(key,(0,0,0,0))
            hist[key]=(cnt+1,sr+r,sg+g,sb+b)
    colors=[]
    for cnt,sr,sg,sb in hist.values():
        colors.append([sr//cnt,sg//cnt,sb//cnt,cnt])
    if not colors: return [(0,0,0)]
    if len(colors)<=max_colors:
        return [(c[0],c[1],c[2]) for c in sorted(colors,key=lambda x:-x[3])]
    boxes=[colors]
    while len(boxes)<max_colors:
        bi=-1; brange=-1
        for i,box in enumerate(boxes):
            if len(box)<=1: continue
            rs=[c[0] for c in box]; gs=[c[1] for c in box]; bs=[c[2] for c in box]
            rg=max(max(rs)-min(rs),max(gs)-min(gs),max(bs)-min(bs))
            if rg>brange: brange=rg; bi=i
        if bi<0: break
        box=boxes.pop(bi)
        ranges=[
            max(c[0] for c in box)-min(c[0] for c in box),
            max(c[1] for c in box)-min(c[1] for c in box),
            max(c[2] for c in box)-min(c[2] for c in box)]
        ch=max(range(3),key=lambda i:ranges[i])
        box.sort(key=lambda c:c[ch])
        total=sum(c[3] for c in box); acc=0; cut=1
        for j,c in enumerate(box):
            acc+=c[3]
            if acc>=total/2: cut=max(1,j+1); break
        boxes.append(box[:cut]); boxes.append(box[cut:])
    pal=[]
    for box in boxes:
        if not box: continue
        n=sum(c[3] for c in box)
        pal.append((
            sum(c[0]*c[3] for c in box)//n,
            sum(c[1]*c[3] for c in box)//n,
            sum(c[2]*c[3] for c in box)//n))
    return pal[:max_colors] or [(0,0,0)]

def crop_rgba(im,alpha_threshold=1):
    w,h=im['width'],im['height']; px=im['rgba']
    xs=[]; ys=[]
    for y in range(h):
        for x in range(w):
            if px[y*w+x][3]>=alpha_threshold:
                xs.append(x); ys.append(y)
    if not xs:
        return {'width':1,'height':1,'rgba':[(0,0,0,0)],'crop_x':0,'crop_y':0,'src_width':w,'src_height':h,'path':im.get('path')}
    x0,x1=min(xs),max(xs); y0,y1=min(ys),max(ys)
    nw=x1-x0+1; nh=y1-y0+1; out=[]
    for y in range(y0,y1+1):
        out.extend(px[y*w+x0:y*w+x1+1])
    return {'width':nw,'height':nh,'rgba':out,'crop_x':x0,'crop_y':y0,'src_width':w,'src_height':h,'path':im.get('path')}

def encode_jx_rle_frame(im,palette,alpha_threshold=1,offset_x=0,offset_y=0):
    w,h=im['width'],im['height']; px=im['rgba']; body=bytearray()
    cache={}
    for y in range(h):
        x=0
        while x<w:
            r,g,b,a=px[y*w+x]
            if a<alpha_threshold: a=0
            # one run = same alpha, max 255 pixels
            run=1
            while x+run<w and run<255:
                aa=px[y*w+x+run][3]
                if aa<alpha_threshold: aa=0
                if aa!=a: break
                run+=1
            body.append(run); body.append(a)
            if a:
                for k in range(run):
                    rr,gg,bb,aa=px[y*w+x+k]
                    key=(rr,gg,bb)
                    idx=cache.get(key)
                    if idx is None:
                        idx=nearest_palette_index(key,palette); cache[key]=idx
                    body.append(idx & 0xff)
            x+=run
    return struct.pack('<HHHH',w,h,offset_x & 0xffff,offset_y & 0xffff)+bytes(body)

def build_jx_spr_from_pngs(paths,output_path,interval=40,directions=1,center_x=0,center_y=0,
                           auto_crop=True,alpha_threshold=1,max_colors=256,frame_offsets=None):
    ims=[png_read_rgba(Path(p)) for p in paths]
    if not ims: raise ValueError('Chưa có frame PNG')
    canvas_w=max(i['width'] for i in ims); canvas_h=max(i['height'] for i in ims)
    palette=median_cut_palette(ims,min(256,max(1,max_colors)),alpha_threshold)
    frames=[]; frame_meta=[]
    for im in ims:
        work=crop_rgba(im,alpha_threshold) if auto_crop else dict(im,crop_x=0,crop_y=0,src_width=im['width'],src_height=im['height'])
        # offsets keep original top-left relative to common source/canvas.
        ox=int(work.get('crop_x',0)); oy=int(work.get('crop_y',0))
        if frame_offsets is not None and len(frame_offsets)>len(frames):
            dx,dy=frame_offsets[len(frames)]; ox+=int(dx); oy+=int(dy)
        blob=encode_jx_rle_frame(work,palette,alpha_threshold,ox,oy)
        frames.append(blob)
        frame_meta.append({'source':str(im['path']),'width':work['width'],'height':work['height'],'offset_x':ox,'offset_y':oy,'length':len(blob)})
    header=SPR_HEADER.pack(b'SPR\x00',canvas_w,canvas_h,int(center_x)&0xffff,int(center_y)&0xffff,
                           len(frames),len(palette),max(1,int(directions)),max(1,int(interval)),
                           0,0,0,0,0,0)
    palbytes=b''.join(bytes((r,g,b)) for r,g,b in palette)
    off=0; offs=[]
    for fr in frames:
        offs.append(SPR_OFFS.pack(off,len(fr))); off+=len(fr)
    data=header+palbytes+b''.join(offs)+b''.join(frames)
    Path(output_path).write_bytes(data)
    parsed=parse_spr_bytes(data,output_path)
    # decode every frame for round-trip structure verification
    for i in range(parsed['frames']): decode_spr_frame(parsed,i)
    return {'path':Path(output_path),'size':len(data),'frames':len(frames),'colors':len(palette),
            'width':canvas_w,'height':canvas_h,'directions':directions,'interval':interval,'frame_meta':frame_meta}


# ---------------- V4.1 exact KNpcRes path resolver ----------------
def compose_path_and_name_engine(path_value, name_value):
    """Exact KNpcResNode::ComposePathAndName behavior, normalized for hashing."""
    name=(name_value or '').strip().strip('"\'')
    path=(path_value or '').strip().strip('"\'')
    if not name:
        return ''
    if not path:
        return normalize_virtual_path(name)
    combined = path
    if not combined.startswith(('\\','/')):
        combined='\\'+combined
    if not combined.endswith(('\\','/')):
        combined+='\\'
    combined += name
    return normalize_virtual_path(combined)


def load_legacy_table(path: Path):
    text,enc=safe_read_text(path)
    if text is None:
        return None,None
    rows=[split_legacy_row(x) for x in text.splitlines()]
    while rows and not any(c.strip() for c in rows[-1]): rows.pop()
    return rows,enc


def find_npcres_exact_paths(client: Path, loose_paths, id_locations):
    """Port the SpecialNpc table chain used by KNpcResNode::Init.

    CharacterType table -> PartFileName -> section names -> section resource table
    -> positional action cells -> ComposePathAndName(ResFilePath, spr cell).
    """
    root=None
    for cand in (client/'settings'/'NpcRes', client/'settings'/'npcres'):
        if cand.exists(): root=cand; break
    if root is None:
        # case-insensitive fallback
        settings=client/'settings'
        if settings.exists():
            for d in settings.iterdir():
                if d.is_dir() and d.name.lower()=='npcres': root=d; break
    if root is None: return [],[]

    files=[p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in ('.txt','.tab','.csv')]
    by_base={}
    def filename_aliases(name):
        out=set()
        if not name:
            return out
        s=str(name)
        out.add(s.lower())
        try:
            out.add(s.encode('gbk').decode('latin-1').lower())
        except Exception:
            pass
        try:
            out.add(s.encode('latin-1').decode('gbk').lower())
        except Exception:
            pass
        try:
            out.add(s.encode('cp1252').decode('gbk').lower())
        except Exception:
            pass
        return out

    for p in files:
        for alias in filename_aliases(p.name):
            by_base.setdefault(alias,p)

    table_cache={}
    def get_table(p):
        key=str(p)
        if key not in table_cache: table_cache[key]=load_legacy_table(p)
        return table_cache[key]
    def resolve_table(name):
        if not name:
            return None
        base=Path(name.replace('\\','/')).name
        for alias in filename_aliases(base):
            p=by_base.get(alias)
            if p is not None:
                return p
        return None

    kind_candidates=[]
    for p in files:
        rows,enc=get_table(p)
        if not rows: continue
        for hi,row in enumerate(rows[:4]):
            heads=[c.strip() for c in row]
            low={c.lower() for c in heads}
            if 'charactertype' in low and 'resfilepath' in low and 'partfilename' in low:
                kind_candidates.append((p,rows,enc,hi)); break

    exact=[]; chains=[]
    for kind_path,rows,enc,hi in kind_candidates:
        headers=[c.strip() for c in rows[hi]]
        hmap={h.lower():i for i,h in enumerate(headers) if h}
        for ri in range(hi+1,len(rows)):
            row=rows[ri]
            def cell_by_header(h):
                idx=hmap.get(h.lower(),-1)
                return row[idx].strip() if 0 <= idx < len(row) else ''
            npc_name=(row[0].strip() if row else '')
            ctype=cell_by_header('CharacterType')
            res_path=cell_by_header('ResFilePath')
            part_name=cell_by_header('PartFileName')
            if not npc_name or not ctype: continue
            chains.append((kind_path.relative_to(client).as_posix(),ri+1,npc_name,ctype,res_path,part_name))
            if ctype.lower()!='specialnpc' or not part_name: continue
            part_path=resolve_table(part_name)
            if not part_path: continue
            part_rows,part_enc=get_table(part_path)
            if not part_rows: continue
            sect_names=[]
            # source: PartFile.GetString(i+2, j+3): row >=2, col >=3 (1-based)
            for pr in part_rows[1:]:
                for val in pr[2:]:
                    v=val.strip()
                    if v and v not in sect_names: sect_names.append(v)
            for part_index,sect in enumerate(sect_names):
                colidx=next((i for i,h in enumerate(headers) if h.strip().lower()==sect.lower()),-1)
                res_table_name=row[colidx].strip() if 0 <= colidx < len(row) else ''
                if not res_table_name: continue
                res_table_path=resolve_table(res_table_name)
                if not res_table_path: continue
                tab_rows,tab_enc=get_table(res_table_path)
                if not tab_rows or len(tab_rows)<2: continue
                action_headers=tab_rows[0]
                for equip_idx,data_row in enumerate(tab_rows[1:]):
                    equip_name=data_row[0].strip() if data_row else str(equip_idx)
                    for action_idx in range(1,len(data_row)):
                        raw=data_row[action_idx].strip()
                        if not raw.lower().endswith('.spr'): continue
                        vp=compose_path_and_name_engine(res_path,raw)
                        uid=jx_filename_to_id(vp)
                        locs=sorted(id_locations.get(uid,[]),key=lambda x:x[0])
                        loose=vp in loose_paths
                        first=locs[0] if locs else None
                        state='LOOSE+PAK' if loose and locs else 'LOOSE_ONLY' if loose else 'PAK_ONLY' if locs else 'UNRESOLVED'
                        action_name=action_headers[action_idx].strip() if action_idx < len(action_headers) else str(action_idx-1)
                        exact.append((npc_name,ctype,res_path,part_name,sect,part_index,res_table_name,equip_idx,equip_name,
                                      action_idx-1,action_name,raw,vp,f'0x{uid:08X}',int(loose),len(locs),
                                      ','.join(str(x[0]) for x in locs),';'.join(x[1] for x in locs),
                                      first[0] if first else '',first[1] if first else '',state,
                                      kind_path.relative_to(client).as_posix(),res_table_path.relative_to(client).as_posix()))
    return exact,chains


# ---------------- SPR viewer/parser ----------------
SPR_FRAME_HEADER = struct.Struct('<HHHH')

def parse_spr_file(path: Path):
    path=Path(path)
    return parse_spr_bytes(path.read_bytes(), path)


def decode_spr_frame(spr, frame_index):
    if frame_index<0 or frame_index>=spr['frames']: raise IndexError(frame_index)
    off,length=spr['offsets'][frame_index]
    start=spr['frame_base']+off; end=start+length
    if end>len(spr['data']): raise ValueError('Frame data vượt kích thước file')
    blob=spr['data'][start:end]
    if len(blob)<SPR_FRAME_HEADER.size: raise ValueError('Frame quá ngắn')
    fw,fh,ox,oy=SPR_FRAME_HEADER.unpack_from(blob,0)
    ptr=SPR_FRAME_HEADER.size; rgba=[(0,0,0,0)]*(fw*fh); pal=spr['palette']
    for y in range(fh):
        x=0
        while x<fw:
            if ptr+2>len(blob): raise ValueError(f'RLE thiếu block tại y={y}, x={x}')
            run=blob[ptr]; alpha=blob[ptr+1]; ptr+=2
            if run==0: raise ValueError(f'RLE run=0 tại y={y}, x={x}')
            n=min(run,fw-x)
            if alpha:
                if ptr+run>len(blob): raise ValueError('RLE thiếu palette indexes')
                for j in range(n):
                    idx=blob[ptr+j]
                    r,g,b=pal[idx] if idx<len(pal) else (255,0,255)
                    rgba[y*fw+x+j]=(r,g,b,alpha)
                ptr += run
            x += n
    return {'width':fw,'height':fh,'offset_x':ox,'offset_y':oy,'rgba':rgba,'encoded_bytes':length}


def frame_to_rgb_rows(frame, scale=1):
    w,h=frame['width'],frame['height']
    scale=max(1,int(scale))
    rows=[]
    for y in range(h):
        row=[]
        for x in range(w):
            r,g,b,a=frame['rgba'][y*w+x]
            bg=210 if ((x//8+y//8)&1)==0 else 165
            rr=(r*a+bg*(255-a))//255
            gg=(g*a+bg*(255-a))//255
            bb=(b*a+bg*(255-a))//255
            c=f'#{rr:02x}{gg:02x}{bb:02x}'
            row.extend([c]*scale)
        tkrow='{'+' '.join(row)+'}'
        for _ in range(scale):
            rows.append(tkrow)
    return rows,w*scale,h*scale


def frame_to_tk_photo(frame, scale=1):
    rows,w,h=frame_to_rgb_rows(frame,scale)
    img=tk.PhotoImage(width=w,height=h)
    for y0 in range(0,h,32):
        chunk=' '.join(rows[y0:y0+32])
        img.put(chunk,to=(0,y0,w,min(h,y0+32)))
    return img


def write_rgba_png(path: Path, width, height, rgba):
    """Write a true-alpha RGBA PNG using only Python stdlib."""
    import zlib
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    if width <= 0 or height <= 0 or len(rgba) != width*height:
        raise ValueError('Kích thước RGBA không hợp lệ')
    raw=bytearray()
    for y in range(height):
        raw.append(0)
        for x in range(width):
            r,g,b,a=rgba[y*width+x]
            raw.extend((r&255,g&255,b&255,a&255))

    def chunk(tag,data):
        return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data)&0xffffffff)

    png=(b'\x89PNG\r\n\x1a\n'+
         chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,6,0,0,0))+
         chunk(b'IDAT',zlib.compress(bytes(raw),9))+
         chunk(b'IEND',b''))
    path.write_bytes(png)


def export_spr_frames_png(spr, out_dir: Path):
    """Export all frames as tightly cropped transparent PNG files in frame order."""
    out_dir=Path(out_dir)
    out_dir.mkdir(parents=True,exist_ok=True)
    exported=[]
    for i in range(spr['frames']):
        fr=decode_spr_frame(spr,i)
        fp=out_dir/f'frame_{i:04d}.png'
        write_rgba_png(fp,fr['width'],fr['height'],fr['rgba'])
        exported.append((fp,fr))
    meta={
        'source':str(spr['path']),
        'canvas_width':spr['width'],'canvas_height':spr['height'],
        'center_x':spr['center_x'],'center_y':spr['center_y'],
        'frames':spr['frames'],'directions':spr['directions'],
        'interval':spr['interval'],'colors':spr['colors'],
        'frame_info':[
            {'frame':i,'file':fp.name,'width':fr['width'],'height':fr['height'],
             'offset_x':fr['offset_x'],'offset_y':fr['offset_y']}
            for i,(fp,fr) in enumerate(exported)
        ]
    }
    (out_dir/'frames.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    return exported




def _jx_rtui_boot_log(message):
    """Write diagnostics beside this Python file even before Tk is initialized."""
    try:
        base = Path(__file__).resolve().parent
    except Exception:
        base = Path.cwd()
    path = base / "JX_Runtime_UI_Designer.log"
    try:
        with open(str(path), "a", encoding="utf-8", errors="replace") as f:
            f.write("[%s] %s\\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), str(message)))
            f.flush()
    except Exception:
        try:
            path = Path.cwd() / "JX_Runtime_UI_Designer.log"
            with open(str(path), "a", encoding="utf-8", errors="replace") as f:
                f.write("[%s] %s\\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), str(message)))
                f.flush()
        except Exception:
            pass

_jx_rtui_boot_log("=== JX Workshop Runtime UI Designer v3.2.1.9.2 / Patch 02.2.1.9.2 boot ===")
_jx_rtui_boot_log("Script path: " + str(Path(__file__).resolve()))
_jx_rtui_boot_log("CWD: " + str(Path.cwd()))
_jx_rtui_boot_log("PID: " + str(os.getpid()))



# ============================================================================
# JX Runtime UI Designer 01.4.2 - Native Win32 Named Pipe transport
# Replaces Python file-object open/read/write because that path could deadlock
# on the full-duplex synchronous JXUIEditor pipe.
# ============================================================================
_JX_INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
_JX_GENERIC_READ  = 0x80000000
_JX_GENERIC_WRITE = 0x40000000
_JX_OPEN_EXISTING = 3
_JX_ERROR_PIPE_BUSY = 231
_JX_ERROR_BROKEN_PIPE = 109
_JX_ERROR_NO_DATA = 232
_JX_ERROR_ACCESS_DENIED = 5
_JX_ERROR_FILE_NOT_FOUND = 2

# ============================================================================
# Patch 02.2.1.9 - Portable Client Compatibility Layer
# ============================================================================
JX_PORTABLE_PROFILE_SCHEMA = 1
JX_PORTABLE_DEFAULT_PROFILE = {
    'id': 'generic-jx',
    'name': 'Generic JX / SwordOnline Client',
    'game_exe_names': ['Game.exe'],
    'resource_roots': ['data', '.'],
    'loose_spr_root': 'spr',
    'runtime_pipe': r'\\.\pipe\JXUIEditor',
    'runtime_required_caps': ['UI_ENUM', 'HITTEST', 'SETSPR', 'TESTSPR'],
    'notes': 'Generic profile. Offline resource tools remain available even without runtime bridge.'
}

def jx_portable_normalize_path(value):
    try:
        return str(Path(value).expanduser().resolve())
    except Exception:
        return str(value or '')

def jx_portable_guess_client_root(game_path):
    try:
        p=Path(game_path)
        if p.is_file() or p.suffix.lower()=='.exe':
            return p.parent
        return p
    except Exception:
        return Path('.')

def jx_portable_profile_for_game(game_path):
    profile=dict(JX_PORTABLE_DEFAULT_PROFILE)
    profile['game_path']=jx_portable_normalize_path(game_path)
    try:
        root=jx_portable_guess_client_root(game_path)
        profile['client_root']=str(root)
        # Heuristics only; never block offline tools.
        indicators=[]
        for rel in ('package.ini','data','spr'):
            try:
                if (root/rel).exists():indicators.append(rel)
            except Exception:pass
        profile['detected_indicators']=indicators
        profile['resource_compatible']=bool(indicators)
    except Exception:
        profile['client_root']=''
        profile['detected_indicators']=[]
        profile['resource_compatible']=False
    return profile

def jx_portable_caps_default():
    return {
        'bridge': False,
        'ui_enum': False,
        'hittest': False,
        'setspr': False,
        'setrender': False,
        'testsprite': False,
        'cross_client_cache': False,
    }


if os.name == 'nt':
    _jx_k32 = ctypes.WinDLL('kernel32', use_last_error=True)

    _jx_k32.CreateFileW.argtypes = [
        ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p
    ]
    _jx_k32.CreateFileW.restype = ctypes.c_void_p

    _jx_k32.WaitNamedPipeW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
    _jx_k32.WaitNamedPipeW.restype = ctypes.c_int

    _jx_k32.ReadFile.argtypes = [
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32), ctypes.c_void_p
    ]
    _jx_k32.ReadFile.restype = ctypes.c_int

    _jx_k32.WriteFile.argtypes = [
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32), ctypes.c_void_p
    ]
    _jx_k32.WriteFile.restype = ctypes.c_int

    _jx_k32.CloseHandle.argtypes = [ctypes.c_void_p]
    _jx_k32.CloseHandle.restype = ctypes.c_int

    _jx_k32.PeekNamedPipe.argtypes = [
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32),
        ctypes.POINTER(ctypes.c_uint32)
    ]
    _jx_k32.PeekNamedPipe.restype = ctypes.c_int

    try:
        _jx_k32.CancelIoEx.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        _jx_k32.CancelIoEx.restype = ctypes.c_int
    except Exception:
        pass


def _jx_win32_open_pipe(pipe_name, wait_ms=5000):
    """Open the Runtime UI named pipe using the proven JX WorldEditor order.

    WorldEditor PASS behavior is: WaitNamedPipeW -> CreateFileW.  The old
    Workshop path attempted CreateFileW first and treated ERROR_FILE_NOT_FOUND
    as a hard portable-offline result.  During Game.exe/UI startup that creates
    a race: the process is already visible but JXUIEditor has not been created
    yet.  This routine waits for the bridge for the whole attach window and only
    then opens the duplex handle.
    """
    if os.name != 'nt':
        raise OSError('JX Runtime UI Designer Named Pipe transport requires Windows.')

    deadline = time.time() + max(0.1, float(wait_ms) / 1000.0)
    last_err = _JX_ERROR_FILE_NOT_FOUND

    while time.time() < deadline:
        remain = max(1, int((deadline - time.time()) * 1000))

        # Same ordering as JX_World_Editor PipeClient.connect(): wait until the
        # server instance exists/accepts clients before CreateFileW.
        ctypes.set_last_error(0)
        ready = _jx_k32.WaitNamedPipeW(pipe_name, min(remain, 1000))
        if not ready:
            last_err = ctypes.get_last_error()
            # FILE_NOT_FOUND means Game.exe is up but bridge may still be
            # starting; PIPE_BUSY means an instance exists but is not ready.
            if last_err in (_JX_ERROR_FILE_NOT_FOUND, _JX_ERROR_PIPE_BUSY):
                time.sleep(0.05)
                continue
            raise ctypes.WinError(last_err)

        ctypes.set_last_error(0)
        h = _jx_k32.CreateFileW(
            pipe_name,
            _JX_GENERIC_READ | _JX_GENERIC_WRITE,
            0,
            None,
            _JX_OPEN_EXISTING,
            0,
            None
        )
        hv = ctypes.cast(h, ctypes.c_void_p).value
        if hv not in (None, _JX_INVALID_HANDLE_VALUE):
            return hv

        last_err = ctypes.get_last_error()
        if last_err not in (_JX_ERROR_FILE_NOT_FOUND, _JX_ERROR_PIPE_BUSY):
            raise ctypes.WinError(last_err)
        time.sleep(0.05)

    raise ctypes.WinError(last_err)


def _jx_win32_read_pipe(handle, max_bytes=4096):
    if not handle:
        return b''
    buf = ctypes.create_string_buffer(max_bytes)
    got = ctypes.c_uint32(0)
    ctypes.set_last_error(0)
    ok = _jx_k32.ReadFile(
        ctypes.c_void_p(handle),
        buf,
        max_bytes,
        ctypes.byref(got),
        None
    )
    if not ok:
        err = ctypes.get_last_error()
        if err in (_JX_ERROR_BROKEN_PIPE, _JX_ERROR_NO_DATA):
            return b''
        raise ctypes.WinError(err)
    return buf.raw[:got.value]


def _jx_win32_write_pipe(handle, data):
    if not handle:
        raise OSError('Named Pipe handle is closed.')
    if not isinstance(data, (bytes, bytearray)):
        data = bytes(data)

    total = 0
    length = len(data)
    while total < length:
        part = bytes(data[total:])
        src = ctypes.create_string_buffer(part, len(part))
        wrote = ctypes.c_uint32(0)
        ctypes.set_last_error(0)
        ok = _jx_k32.WriteFile(
            ctypes.c_void_p(handle),
            src,
            len(part),
            ctypes.byref(wrote),
            None
        )
        if not ok:
            err = ctypes.get_last_error()
            raise ctypes.WinError(err)
        if wrote.value <= 0:
            raise OSError('WriteFile returned zero bytes written.')
        total += int(wrote.value)
    return total



def _jx_win32_peek_pipe(handle):
    if not handle:
        return 0
    avail = ctypes.c_uint32(0)
    ctypes.set_last_error(0)
    ok = _jx_k32.PeekNamedPipe(
        ctypes.c_void_p(handle),
        None,
        0,
        None,
        ctypes.byref(avail),
        None
    )
    if not ok:
        err = ctypes.get_last_error()
        if err in (_JX_ERROR_BROKEN_PIPE, _JX_ERROR_NO_DATA):
            return -1
        raise ctypes.WinError(err)
    return int(avail.value)


def _jx_win32_close_pipe(handle):
    if not handle or os.name != 'nt':
        return
    try:
        cancel = getattr(_jx_k32, 'CancelIoEx', None)
        if cancel:
            cancel(ctypes.c_void_p(handle), None)
    except Exception:
        pass
    try:
        _jx_k32.CloseHandle(ctypes.c_void_p(handle))
    except Exception:
        pass


class JXClientScannerV41:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self._apply_app_icon()
        self._apply_modern_theme()
        self.root.geometry("1180x860")
        self.root.minsize(920, 700)
        self.client_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self.hash_all_var = tk.BooleanVar(value=False)
        self.scan_text_var = tk.BooleanVar(value=True)
        self.native_extract_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar(value="Sẵn sàng.")
        self.progress_var = tk.DoubleVar(value=0)

        # Patch 02.2.1.3.2 - non-blocking scanner state.
        self.scan_worker_thread = None
        self.scan_cancel_event = threading.Event()
        self.scan_ui_queue = queue.Queue()
        self.scan_started_at = 0.0
        self.scan_last_activity = 0.0
        self.scan_last_progress = 0.0
        self.scan_phase = "IDLE"
        self.scan_disk_log_path = None
        self.scan_disk_log_lock = threading.Lock()
        self.scan_poll_after = None
        self.scan_option_hash_all = False
        self.scan_option_scan_text = True
        self.scan_option_native_extract = True

        self._build_ui()
        self._scan_schedule_ui_poll()

    def _apply_app_icon(self):
        """Apply APP_ICON_PATH to the Tk window when an .ico file is available.

        A relative path is resolved next to the running script, or next to the
        bundled EXE when frozen by PyInstaller/auto-py-to-exe.
        """
        try:
            raw = str(APP_ICON_PATH or '').strip()
            if not raw:
                return
            icon = Path(raw)
            if not icon.is_absolute():
                base = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
                icon = base / icon
            if icon.exists():
                self.root.iconbitmap(default=str(icon))
        except Exception:
            pass

    def _apply_modern_theme(self):
        """Modern dark UI skin only; application behavior remains unchanged."""
        self.ui = {
            'bg': '#0b1120',
            'surface': '#111827',
            'surface2': '#172033',
            'surface3': '#1e293b',
            'border': '#2b3950',
            'text': '#e7edf7',
            'muted': '#95a3b8',
            'accent': '#4f8cff',
            'accent_hover': '#6aa0ff',
            'accent_press': '#3e74da',
            'success': '#35c58a',
            'danger': '#ef6461',
            'canvas': '#0e1628',
            'selection': '#244a82',
        }
        c = self.ui
        try:
            self.root.configure(background=c['bg'])
        except Exception:
            pass

        # Tk widgets that do not use ttk styles (Text/Listbox/etc.).
        self.root.option_add('*Font', '{Segoe UI} 10')
        self.root.option_add('*Background', c['bg'])
        self.root.option_add('*Foreground', c['text'])
        self.root.option_add('*Text.Background', c['surface'])
        self.root.option_add('*Text.Foreground', c['text'])
        self.root.option_add('*Text.InsertBackground', c['text'])
        self.root.option_add('*Text.selectBackground', c['selection'])
        self.root.option_add('*Text.selectForeground', '#ffffff')
        self.root.option_add('*Listbox.Background', c['surface'])
        self.root.option_add('*Listbox.Foreground', c['text'])
        self.root.option_add('*Listbox.selectBackground', c['selection'])
        self.root.option_add('*Listbox.selectForeground', '#ffffff')
        self.root.option_add('*Menu.Background', c['surface'])
        self.root.option_add('*Menu.Foreground', c['text'])
        self.root.option_add('*Menu.activeBackground', c['surface3'])
        self.root.option_add('*Menu.activeForeground', '#ffffff')

        style = ttk.Style(self.root)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass

        style.configure('.',
                        background=c['bg'], foreground=c['text'],
                        fieldbackground=c['surface2'],
                        bordercolor=c['border'], darkcolor=c['border'], lightcolor=c['border'],
                        troughcolor=c['surface'],
                        font=('Segoe UI', 10))
        style.configure('TFrame', background=c['bg'])
        style.configure('Card.TFrame', background=c['surface'])
        style.configure('TLabel', background=c['bg'], foreground=c['text'])
        style.configure('Muted.TLabel', background=c['bg'], foreground=c['muted'])
        style.configure('Title.TLabel', background=c['bg'], foreground='#ffffff', font=('Segoe UI Semibold', 18))
        style.configure('Section.TLabel', background=c['bg'], foreground='#ffffff', font=('Segoe UI Semibold', 12))

        style.configure('TLabelframe',
                        background=c['bg'], bordercolor=c['border'],
                        relief='solid', borderwidth=1)
        style.configure('TLabelframe.Label',
                        background=c['bg'], foreground='#d7e3f4',
                        font=('Segoe UI Semibold', 10))

        style.configure('TButton',
                        background=c['surface3'], foreground=c['text'],
                        bordercolor=c['border'], focusthickness=0, focuscolor=c['surface3'],
                        padding=(12, 7), relief='flat')
        style.map('TButton',
                  background=[('disabled', c['surface2']), ('pressed', c['accent_press']), ('active', '#26364f')],
                  foreground=[('disabled', '#65758c'), ('active', '#ffffff')],
                  bordercolor=[('active', '#3c4e68'), ('pressed', c['accent'])])
        style.configure('Accent.TButton',
                        background=c['accent'], foreground='#ffffff',
                        bordercolor=c['accent'], padding=(14, 8), relief='flat',
                        font=('Segoe UI Semibold', 10))
        style.map('Accent.TButton',
                  background=[('pressed', c['accent_press']), ('active', c['accent_hover']), ('disabled', '#34527f')],
                  foreground=[('disabled', '#9fb7dc')])

        style.configure('TEntry',
                        fieldbackground=c['surface2'], foreground=c['text'],
                        insertcolor=c['text'], bordercolor=c['border'],
                        padding=(8, 7), relief='flat')
        style.map('TEntry',
                  bordercolor=[('focus', c['accent'])],
                  fieldbackground=[('disabled', c['surface']), ('readonly', c['surface2'])],
                  foreground=[('disabled', '#687990')])
        style.configure('TCombobox',
                        fieldbackground=c['surface2'], background=c['surface2'],
                        foreground=c['text'], arrowcolor=c['muted'],
                        bordercolor=c['border'], padding=(7, 6), relief='flat')
        style.map('TCombobox',
                  bordercolor=[('focus', c['accent'])],
                  fieldbackground=[('readonly', c['surface2'])],
                  selectbackground=[('readonly', c['surface2'])],
                  selectforeground=[('readonly', c['text'])])

        style.configure('TCheckbutton', background=c['bg'], foreground=c['text'], padding=(3, 3))
        style.map('TCheckbutton', background=[('active', c['bg'])], foreground=[('active', '#ffffff')])
        style.configure('TRadiobutton', background=c['bg'], foreground=c['text'])
        style.map('TRadiobutton', background=[('active', c['bg'])], foreground=[('active', '#ffffff')])

        style.configure('TNotebook', background=c['bg'], borderwidth=0, tabmargins=(8, 8, 8, 0))
        style.configure('TNotebook.Tab',
                        background=c['surface'], foreground=c['muted'],
                        padding=(15, 9), borderwidth=0,
                        font=('Segoe UI Semibold', 10))
        style.map('TNotebook.Tab',
                  background=[('selected', c['surface3']), ('active', '#19263a')],
                  foreground=[('selected', '#ffffff'), ('active', '#dce8fa')])

        style.configure('Horizontal.TProgressbar',
                        background=c['accent'], troughcolor=c['surface'],
                        bordercolor=c['surface'], lightcolor=c['accent'], darkcolor=c['accent'],
                        thickness=8)
        style.configure('Vertical.TScrollbar',
                        background=c['surface3'], troughcolor=c['surface'],
                        arrowcolor=c['muted'], bordercolor=c['surface'])
        style.configure('Horizontal.TScrollbar',
                        background=c['surface3'], troughcolor=c['surface'],
                        arrowcolor=c['muted'], bordercolor=c['surface'])
        style.map('Vertical.TScrollbar', background=[('active', '#33455f')])
        style.map('Horizontal.TScrollbar', background=[('active', '#33455f')])

        style.configure('Treeview',
                        background=c['surface'], fieldbackground=c['surface'], foreground=c['text'],
                        bordercolor=c['border'], rowheight=27, relief='flat')
        style.map('Treeview',
                  background=[('selected', c['selection'])],
                  foreground=[('selected', '#ffffff')])
        style.configure('Treeview.Heading',
                        background=c['surface3'], foreground='#dbe7f8',
                        bordercolor=c['border'], relief='flat', padding=(8, 7),
                        font=('Segoe UI Semibold', 9))
        style.map('Treeview.Heading', background=[('active', '#2a3b55')])
        style.configure('TPanedwindow', background=c['bg'])
        style.configure('Sash', background=c['border'])

    def _build_ui(self):
        self.notebook=ttk.Notebook(self.root); self.notebook.pack(fill='both',expand=True)
        self.scan_tab=ttk.Frame(self.notebook); self.viewer_tab=ttk.Frame(self.notebook); self.resource_tab=ttk.Frame(self.notebook); self.runtime_ui_tab=ttk.Frame(self.notebook); self.ai_rt_tab=ttk.Frame(self.notebook); self.builder_tab=ttk.Frame(self.notebook)
        self.notebook.add(self.scan_tab,text='Scanner')
        self.notebook.add(self.viewer_tab,text='SPR Viewer')
        self.notebook.add(self.resource_tab,text='Resource Studio')
        self.notebook.add(self.runtime_ui_tab,text='Real-Time UI Designer')
        self.notebook.add(self.ai_rt_tab,text='SPR Builder with ChatGPT')
        self.notebook.add(self.builder_tab,text='SPR Builder Multi-Frame')
        parent=self.scan_tab; pad={'padx':10,'pady':6}
        ttk.Label(parent,text=APP_TITLE,style='Title.TLabel').pack(pady=(12,4))
        frm=ttk.Frame(parent); frm.pack(fill='x',**pad)
        ttk.Label(frm,text='Thư mục client (Game.exe/package.ini):').grid(row=0,column=0,sticky='w')
        ttk.Entry(frm,textvariable=self.client_var).grid(row=1,column=0,sticky='ew',padx=(0,8)); ttk.Button(frm,text='Chọn...',command=self.choose_client).grid(row=1,column=1)
        ttk.Label(frm,text='Mapping tự động: <Client>\\CLIENT_MAPPING').grid(row=2,column=0,sticky='w',pady=(8,0))
        ttk.Entry(frm,textvariable=self.output_var).grid(row=3,column=0,sticky='ew',padx=(0,8))
        ttk.Button(frm,text='Chọn...',command=self.choose_output).grid(row=3,column=1,padx=(0,4))
        ttk.Button(frm,text='Dùng mapping đã scan...',command=self.choose_existing_scan).grid(row=3,column=2)
        frm.columnconfigure(0,weight=1)
        opts=ttk.LabelFrame(parent,text='Tùy chọn'); opts.pack(fill='x',**pad)
        ttk.Checkbutton(opts,text='Đọc text/config để thu thập path ứng viên',variable=self.scan_text_var).pack(anchor='w',padx=10,pady=(6,2))
        ttk.Checkbutton(opts,text='SHA1 mọi file (chậm hơn)',variable=self.hash_all_var).pack(anchor='w',padx=10,pady=2)
        ttk.Checkbutton(opts,text='Native targeted extract character/NpcRes từ PAK',variable=self.native_extract_var).pack(anchor='w',padx=10,pady=(2,6))
        ctr=ttk.Frame(parent); ctr.pack(fill='x',**pad)
        self.scan_button=ttk.Button(ctr,text='Quét',command=self.scan,style='Accent.TButton'); self.scan_button.pack(side='left')
        self.scan_cancel_button=ttk.Button(ctr,text='Hủy Scan',command=self.cancel_scan,state='disabled'); self.scan_cancel_button.pack(side='left',padx=(8,0))
        ttk.Button(ctr,text='Mở thư mục kết quả',command=self.open_output).pack(side='left',padx=8)
        ttk.Progressbar(parent,variable=self.progress_var,maximum=100).pack(fill='x',padx=20,pady=(5,3))
        ttk.Label(parent,textvariable=self.status_var).pack(anchor='w',padx=20)
        self.scan_monitor_var=tk.StringVar(value='Worker: IDLE')
        ttk.Label(parent,textvariable=self.scan_monitor_var,font=('Consolas',9)).pack(anchor='w',padx=20,pady=(2,0))
        lf=ttk.LabelFrame(parent,text='Log'); lf.pack(fill='both',expand=True,padx=10,pady=8)
        self.log_text=tk.Text(lf,wrap='word',font=('Cascadia Mono',9),height=16,bg=self.ui['surface'],fg=self.ui['text'],insertbackground=self.ui['text'],selectbackground=self.ui['selection'],relief='flat',bd=0,padx=10,pady=8); self.log_text.pack(fill='both',expand=True,side='left')
        sb=ttk.Scrollbar(lf,orient='vertical',command=self.log_text.yview); sb.pack(fill='y',side='right'); self.log_text.configure(yscrollcommand=sb.set)
        self._build_spr_viewer(self.viewer_tab)
        # C1.2A.1: Runtime UI owns the shared SCREEN/WORLD placement variable,
        # so build it before initializing the detached SPR palette alias.
        self._build_runtime_ui_designer(self.runtime_ui_tab)
        self._init_spr_palette_state()
        self._build_resource_studio(self.resource_tab)
        self._build_ai_roundtrip(self.ai_rt_tab)
        self._build_spr_builder(self.builder_tab)

    # ---------------- Real-Time UI Designer ----------------
    # Protocol is intentionally UI-only. The game-side bridge exposes KWndWindow-derived
    # controls and never exposes world/player/NPC/object renderer handles.
    def _build_runtime_ui_designer(self,parent):
        self.rtui_pipe_name=r'\\.\pipe\JXUIEditor'
        self.rtui_connected=False; self.rtui_pipe=None; self.rtui_reader_thread=None

        # Patch 02.2.1.8.1 - bridge connection supervisor.
        self.rtui_want_connected=False
        self.rtui_reconnect_after=None
        self.rtui_reconnect_attempt=0
        self.rtui_connecting=False
        self.rtui_access_denied=False
        # Patch 02.2.1.9 - portable compatibility state
        self.rtui_client_profile=dict(JX_PORTABLE_DEFAULT_PROFILE)
        self.rtui_caps=jx_portable_caps_default()
        self.rtui_runtime_supported=False
        self.rtui_runtime_reason='Runtime bridge not checked yet.'
        self.rtui_bridge_version='unknown'
        self.rtui_client_signature='unknown'
        self.rtui_portable_mode='OFFLINE'
        self.rtui_writer_thread=None
        self.rtui_stop_event=threading.Event(); self.rtui_send_lock=threading.Lock()
        self.rtui_tx_queue=queue.Queue(maxsize=8192)
        self.rtui_elements={}; self.rtui_selected_id=''; self.rtui_dragging=False
        self.rtui_game_hwnd=0; self.rtui_game_pid=0
        self.rtui_last_hit_id=''; self.rtui_last_hit_type=''; self.rtui_last_hit_spr=''
        self.rtui_locked_target_id=''; self.rtui_last_hover_sent_at=0.0; self.rtui_last_hover_xy=None
        self.rtui_ghost=None; self.rtui_ghost_canvas=None; self.rtui_ghost_photo=None
        self.rtui_drag_grab_widget=None
        self.rtui_palette_native_drag=False
        self.rtui_palette_native_after=None
        self.rtui_palette_native_seen_down=False
        self.rtui_test_sprite_count=0
        # Patch 02.2.1.4 - cross-client external SPR runtime cache.
        self.rtui_external_cache_enabled=tk.BooleanVar(value=True)
        self.rtui_external_cache_map={}
        self.rtui_external_cache_dir=None
        self.rtui_highlight_windows=[]
        self.rtui_resource=None; self.rtui_preview_photo=None; self.rtui_preview_after=None
        self.rtui_preview_frame=0; self.rtui_project_changes={}
        self.rtui_status=tk.StringVar(value='DISCONNECTED — mở/attach Game.exe sau khi build Runtime UI Bridge vào S3Client.')
        self.rtui_game_status=tk.StringVar(value='Game.exe: chưa attach')
        self.rtui_resource_info=tk.StringVar(value='Chưa nhận SPR từ Resource Studio.')
        self.rtui_element_info=tk.StringVar(value='Chưa chọn runtime UI element.')
        self.rtui_target_info=tk.StringVar(value='Smart Target: chưa có')
        self.rtui_x=tk.IntVar(value=0); self.rtui_y=tk.IntVar(value=0); self.rtui_w=tk.IntVar(value=0); self.rtui_h=tk.IntVar(value=0)
        self.rtui_spr_path=tk.StringVar(value='')
        self.rtui_pick_mode=tk.BooleanVar(value=False)
        self.rtui_scale_mode=tk.StringVar(value='Fit')
        # Patch 02.2.1.9.3.8.4C1.2A - shared placement selector.
        # SCREEN = client/screen anchored test sprite.
        # WORLD  = world-placement route (WORLDTESTSPR).
        self.rtui_placement_mode=tk.StringVar(value='SCREEN')
        # Patch 02.2.1.9.3.8.4C1.3B - WORLD collision geometry.
        self.rtui_collision_enabled=tk.BooleanVar(value=True)
        self.rtui_collision_w=tk.IntVar(value=128)
        self.rtui_collision_h=tk.IntVar(value=256)
        self.rtui_collision_offset_x=tk.IntVar(value=0)
        self.rtui_collision_offset_y=tk.IntVar(value=0)
        self.rtui_collision_kind=tk.StringVar(value='NORMAL')
        # C1.3C.1 - validated physical collision preset for large tree sprites.
        self.rtui_collision_preset=tk.StringVar(value='TREE 128x256')
        # C1.3C.3 - WORLD SPR draw layer relative to character-name/UI pass.
        self.rtui_world_name_layer=tk.StringVar(value='BELOW NAME')
        self.rtui_world_character_layer=tk.StringVar(value='UNDER CHARACTER')
        self.rtui_world_select_after=None
        self.rtui_world_select_seen_up=False
        self.rtui_align_mode=tk.StringVar(value='Center')
        self.rtui_custom_w=tk.IntVar(value=48); self.rtui_custom_h=tk.IntVar(value=48)
        self.rtui_keep_aspect=tk.BooleanVar(value=True)
        self.rtui_resize_info=tk.StringVar(value='Resize: chờ target + SPR')

        head=ttk.Frame(parent); head.pack(fill='x',padx=10,pady=(10,5))
        ttk.Label(head,text='Real-Time UI Designer',style='Title.TLabel').pack(side='left')
        ttk.Label(head,textvariable=self.rtui_status).pack(side='right')

        conn=ttk.LabelFrame(parent,text='Game / Runtime Bridge'); conn.pack(fill='x',padx=10,pady=5)
        ttk.Label(conn,textvariable=self.rtui_game_status).grid(row=0,column=0,columnspan=5,sticky='w',padx=8,pady=(6,2))
        ttk.Button(conn,text='Launch Game',command=self.rtui_launch_game).grid(row=1,column=0,padx=4,pady=(2,7))
        ttk.Button(conn,text='Attach / Connect',command=self.rtui_connect).grid(row=1,column=1,padx=4,pady=(2,7))
        ttk.Button(conn,text='Disconnect',command=self.rtui_disconnect).grid(row=1,column=2,padx=4,pady=(2,7))
        ttk.Button(conn,text='Refresh UI Tree',command=lambda:self.rtui_send('LIST')).grid(row=1,column=3,padx=4,pady=(2,7))
        ttk.Checkbutton(conn,text='Pick UI From Game',variable=self.rtui_pick_mode,command=self.rtui_toggle_pick).grid(row=1,column=4,padx=10,pady=(2,7))
        ttk.Button(conn,text='Clear Test Sprites',command=self.rtui_clear_test_sprites).grid(row=1,column=5,padx=4,pady=(2,7))
        ttk.Button(conn,text='Open SPR Palette',command=self.open_spr_palette).grid(row=1,column=6,padx=4,pady=(2,7))
        ttk.Checkbutton(conn,text='Cross-Client SPR Cache',variable=self.rtui_external_cache_enabled).grid(row=1,column=7,padx=4,pady=(2,7))
        ttk.Button(conn,text='Open Cache',command=self.rtui_open_external_cache).grid(row=1,column=8,padx=4,pady=(2,7))

        body=ttk.Panedwindow(parent,orient='horizontal'); body.pack(fill='both',expand=True,padx=10,pady=5)
        left=ttk.Frame(body); right=ttk.Frame(body); body.add(left,weight=1); body.add(right,weight=2)

        src=ttk.LabelFrame(left,text='Selected Resource'); src.pack(fill='x',pady=(0,6))
        ttk.Label(src,textvariable=self.rtui_resource_info,justify='left',wraplength=330).pack(fill='x',padx=7,pady=5)
        self.rtui_preview_canvas=tk.Canvas(src,height=180,background=self.ui['canvas'],highlightthickness=0,cursor='hand2')
        self.rtui_preview_canvas.pack(fill='x',padx=7,pady=4)
        self.rtui_preview_canvas.bind('<ButtonPress-1>',self.rtui_drag_start)
        self.rtui_preview_canvas.bind('<B1-Motion>',self.rtui_drag_motion)
        self.rtui_preview_canvas.bind('<ButtonRelease-1>',self.rtui_drag_end)
        rr=ttk.Frame(src); rr.pack(fill='x',padx=7,pady=(2,7))
        ttk.Button(rr,text='Use Selected Resource',command=self.rtui_use_selected_resource).pack(side='left')
        ttk.Button(rr,text='Go Resource Studio',command=lambda:self.notebook.select(self.resource_tab)).pack(side='left',padx=5)
        ttk.Label(rr,text='Placement:').pack(side='left',padx=(12,3))
        rt_place=ttk.Combobox(rr,textvariable=self.rtui_placement_mode,state='readonly',width=9,values=('SCREEN','WORLD','FOLLOW PLAYER'))
        rt_place.pack(side='left')

        # WORLD collision controls are intentionally separate from UI sizing.
        # They only configure Core's existing runtime obstacle overlay.
        coll=ttk.LabelFrame(src,text='WORLD Collision — Runtime Only')
        coll.pack(fill='x',padx=7,pady=(0,7))
        ttk.Checkbutton(coll,text='Enabled',variable=self.rtui_collision_enabled).grid(row=0,column=0,sticky='w',padx=(7,10),pady=(5,3))
        ttk.Label(coll,text='Width:').grid(row=0,column=1,sticky='e')
        ttk.Entry(coll,textvariable=self.rtui_collision_w,width=6).grid(row=0,column=2,sticky='w',padx=(3,8))
        ttk.Label(coll,text='Height:').grid(row=0,column=3,sticky='e')
        ttk.Entry(coll,textvariable=self.rtui_collision_h,width=6).grid(row=0,column=4,sticky='w',padx=(3,8))
        ttk.Label(coll,text='Type:').grid(row=0,column=5,sticky='e')
        ttk.Combobox(coll,textvariable=self.rtui_collision_kind,state='readonly',width=10,
                     values=('NORMAL','FLY','JUMP','JUMPFLY')).grid(row=0,column=6,sticky='w',padx=(3,7))
        ttk.Label(coll,text='Screen Offset X:').grid(row=1,column=1,sticky='e',pady=(2,6))
        ttk.Entry(coll,textvariable=self.rtui_collision_offset_x,width=6).grid(row=1,column=2,sticky='w',padx=(3,8),pady=(2,6))
        ttk.Label(coll,text='Screen Offset Y:').grid(row=1,column=3,sticky='e',pady=(2,6))
        ttk.Entry(coll,textvariable=self.rtui_collision_offset_y,width=6).grid(row=1,column=4,sticky='w',padx=(3,8),pady=(2,6))
        ttk.Button(coll,text='Set For Next WORLD Drop',command=self.rtui_apply_world_collision).grid(row=1,column=5,columnspan=2,sticky='e',padx=7,pady=(2,6))
        ttk.Label(coll,text='Preset:').grid(row=2,column=0,sticky='e',padx=(7,3),pady=(0,5))
        preset_box=ttk.Combobox(coll,textvariable=self.rtui_collision_preset,state='readonly',width=18,
                               values=('TREE 128x256','CUSTOM'))
        preset_box.grid(row=2,column=1,columnspan=2,sticky='w',padx=(3,8),pady=(0,5))
        ttk.Button(coll,text='Use Preset',command=self.rtui_apply_collision_preset).grid(row=2,column=3,columnspan=2,sticky='w',padx=(3,8),pady=(0,5))
        ttk.Label(coll,text='SPR vs Name:').grid(row=3,column=0,sticky='e',padx=(7,3),pady=(0,5))
        name_layer_box=ttk.Combobox(coll,textvariable=self.rtui_world_name_layer,state='readonly',width=18,
                                    values=('BELOW NAME','ABOVE NAME'))
        name_layer_box.grid(row=3,column=1,columnspan=2,sticky='w',padx=(3,8),pady=(0,5))
        ttk.Button(coll,text='Set For Next WORLD Drop',command=self.rtui_apply_world_name_layer).grid(row=3,column=3,columnspan=3,sticky='w',padx=(3,8),pady=(0,5))
        ttk.Button(coll,text='Save World SPR',command=self.rtui_save_world_spr).grid(row=4,column=0,columnspan=2,sticky='w',padx=7,pady=(1,5))
        ttk.Button(coll,text='Select Saved WORLD SPR',command=self.rtui_select_saved_world_spr).grid(row=4,column=2,columnspan=2,sticky='w',padx=4,pady=(1,5))
        ttk.Button(coll,text='Delete Selected WORLD SPR',command=self.rtui_delete_selected_world_spr).grid(row=4,column=4,columnspan=3,sticky='w',padx=4,pady=(1,5))
        ttk.Label(coll,text='C1.3C.5: Select -> click SPR trong Game -> Delete. Chỉ xóa object đã Save, giữ file SPR nguồn.').grid(row=5,column=0,columnspan=7,sticky='w',padx=7,pady=(1,5))
        ttk.Button(coll,text='Save Follow SPR',command=self.rtui_save_follow_spr).grid(row=6,column=0,columnspan=2,sticky='w',padx=7,pady=(1,5))
        ttk.Button(coll,text='Delete Saved Follow SPR',command=self.rtui_delete_saved_follow_spr).grid(row=6,column=2,columnspan=3,sticky='w',padx=4,pady=(1,5))
        ttk.Label(coll,text='C1.3C.7.1: FOLLOW PLAYER lưu riêng, collision luôn OFF; delete xóa record nhưng giữ SPR source.').grid(row=7,column=0,columnspan=7,sticky='w',padx=7,pady=(1,5))

        treebox=ttk.LabelFrame(left,text='Runtime UI Tree — UI only'); treebox.pack(fill='both',expand=True)
        self.rtui_tree=ttk.Treeview(treebox,columns=('type','rect'),show='tree headings',selectmode='browse')
        self.rtui_tree.heading('#0',text='Element'); self.rtui_tree.heading('type',text='Type'); self.rtui_tree.heading('rect',text='Rect')
        self.rtui_tree.column('#0',width=170); self.rtui_tree.column('type',width=105); self.rtui_tree.column('rect',width=110)
        self.rtui_tree.pack(fill='both',expand=True,side='left')
        ts=ttk.Scrollbar(treebox,orient='vertical',command=self.rtui_tree.yview); ts.pack(fill='y',side='right'); self.rtui_tree.configure(yscrollcommand=ts.set)
        self.rtui_tree.bind('<<TreeviewSelect>>',self.rtui_tree_select)

        insp=ttk.LabelFrame(right,text='Live UI Inspector'); insp.pack(fill='x')
        ttk.Label(insp,textvariable=self.rtui_element_info,justify='left',wraplength=560).grid(row=0,column=0,columnspan=8,sticky='w',padx=8,pady=(6,2))
        resize=ttk.Frame(insp); resize.grid(row=4,column=0,columnspan=8,sticky='ew',padx=8,pady=(2,2))
        ttk.Label(resize,text='Scale Mode:').pack(side='left')
        sm=ttk.Combobox(resize,textvariable=self.rtui_scale_mode,state='readonly',width=10,values=('Original','Fit','Stretch','Custom'))
        sm.pack(side='left',padx=(4,10)); sm.bind('<<ComboboxSelected>>',lambda e:self.rtui_update_resize_preview())
        ttk.Label(resize,text='Align:').pack(side='left')
        am=ttk.Combobox(resize,textvariable=self.rtui_align_mode,state='readonly',width=9,values=('TopLeft','Center'))
        am.pack(side='left',padx=(4,10)); am.bind('<<ComboboxSelected>>',lambda e:self.rtui_update_resize_preview())
        ttk.Label(resize,text='Custom W:').pack(side='left'); ttk.Entry(resize,textvariable=self.rtui_custom_w,width=6).pack(side='left',padx=(3,6))
        ttk.Label(resize,text='H:').pack(side='left'); ttk.Entry(resize,textvariable=self.rtui_custom_h,width=6).pack(side='left',padx=(3,8))
        ttk.Checkbutton(resize,text='Keep aspect',variable=self.rtui_keep_aspect,command=self.rtui_update_resize_preview).pack(side='left')
        resize2=ttk.Frame(insp); resize2.grid(row=5,column=0,columnspan=8,sticky='ew',padx=8,pady=(0,2))
        ttk.Label(resize2,textvariable=self.rtui_resize_info).pack(side='left')
        ttk.Button(resize2,text='Apply Resize',command=self.rtui_apply_resize).pack(side='right')
        ttk.Button(resize2,text='Reset Render Size',command=self.rtui_reset_render_size).pack(side='right',padx=5)
        ttk.Label(insp,textvariable=self.rtui_target_info,justify='left',wraplength=560).grid(row=6,column=0,columnspan=8,sticky='w',padx=8,pady=(2,6))
        for col,(lab,var) in enumerate((('X',self.rtui_x),('Y',self.rtui_y),('W',self.rtui_w),('H',self.rtui_h))):
            ttk.Label(insp,text=lab+':').grid(row=1,column=col*2,sticky='e',padx=(5,2)); ttk.Entry(insp,textvariable=var,width=8).grid(row=1,column=col*2+1,sticky='w')
        ttk.Label(insp,text='SPR:').grid(row=2,column=0,sticky='e',padx=(5,2),pady=6)
        ttk.Entry(insp,textvariable=self.rtui_spr_path).grid(row=2,column=1,columnspan=7,sticky='ew',padx=(0,8),pady=6)
        insp.columnconfigure(7,weight=1)
        bar=ttk.Frame(insp); bar.grid(row=3,column=0,columnspan=8,sticky='ew',padx=8,pady=(0,7))
        ttk.Button(bar,text='Apply Rect',command=self.rtui_apply_rect).pack(side='left')
        ttk.Button(bar,text='Apply Selected SPR',command=self.rtui_apply_selected_spr).pack(side='left',padx=5)
        ttk.Button(bar,text='Reset Element',command=self.rtui_reset_element).pack(side='left')

        logf=ttk.LabelFrame(right,text='Runtime Events / Drag-Drop'); logf.pack(fill='both',expand=True,pady=(6,0))
        self.rtui_log=tk.Text(logf,wrap='word',font=('Cascadia Mono',9),height=15,bg=self.ui['surface'],fg=self.ui['text'],insertbackground=self.ui['text'],selectbackground=self.ui['selection'],relief='flat',bd=0,padx=10,pady=8); self.rtui_log.pack(fill='both',expand=True,side='left')
        ls=ttk.Scrollbar(logf,orient='vertical',command=self.rtui_log.yview); ls.pack(fill='y',side='right'); self.rtui_log.configure(yscrollcommand=ls.set)
        foot=ttk.Frame(right); foot.pack(fill='x',pady=6)
        ttk.Button(foot,text='Save Project',command=self.rtui_save_project).pack(side='left')
        ttk.Button(foot,text='Load Project',command=self.rtui_load_project).pack(side='left',padx=5)
        ttk.Label(foot,text='Drag SPR preview sang cửa sổ Game.exe để drop trực tiếp lên UI element.').pack(side='right')

    def rtui_log_add(self,msg):
        text=display_safe(msg)
        _jx_rtui_boot_log(text)
        if not hasattr(self,'rtui_log'):
            return
        try:
            stamp=time.strftime('%H:%M:%S')
            self.rtui_log.insert('end',f'[{stamp}] {text}\n')
            self.rtui_log.see('end')
        except Exception as e:
            _jx_rtui_boot_log('rtui_log widget write failed: '+repr(e))

    def rtui_use_selected_resource(self):
        r=self.rs_selected()
        if not r:
            messagebox.showwarning('Real-Time UI Designer','Hãy chọn một SPR trong Resource Studio trước.'); return
        try:
            pak,entry=self.rs_entry(r); raw,detail=native_read_xpack_entry_bytes(pak,entry)
            spr=parse_spr_bytes(raw,f"PAK://{r.get('pak_name')}#{r.get('elem_index')}::{r.get('virtual_path')}")
            self.rtui_resource={'row':dict(r),'raw':raw,'spr':spr,'virtual_path':normalize_virtual_path(r.get('virtual_path','')),'pak':str(pak),'runtime_virtual_path':''}
            self.rtui_preview_frame=0
            self.rtui_resource_info.set(f"{self.rtui_resource['virtual_path']}\nCanvas {spr['width']}×{spr['height']} | Frames {spr['frames']} | Directions {spr['directions']} | {detail}")
            self.rtui_spr_path.set(self.rtui_resource['virtual_path'])
            self.rtui_custom_w.set(int(spr['width'])); self.rtui_custom_h.set(int(spr['height']))
            self.rtui_render_resource_preview(); self.rtui_update_resize_preview(); self.notebook.select(self.runtime_ui_tab)
            self.rtui_log_add('Selected SPR loaded from Resource Studio: '+self.rtui_resource['virtual_path'])
        except Exception as e: messagebox.showerror('Real-Time UI Designer',str(e))

    def rtui_render_resource_preview(self,_token=None):
        # Patch 02.2.1.5: exactly ONE Runtime preview animation loop may exist.
        # Previous builds started a new after() chain on every Palette drag.
        if not self.rtui_resource:return
        if _token is None:
            old_after=getattr(self,'rtui_preview_after',None)
            if old_after:
                try:self.root.after_cancel(old_after)
                except Exception:pass
                self.rtui_preview_after=None
            self.rtui_preview_generation=getattr(self,'rtui_preview_generation',0)+1
            _token=self.rtui_preview_generation
        elif _token!=getattr(self,'rtui_preview_generation',0):
            return

        spr=self.rtui_resource['spr']; i=self.rtui_preview_frame%max(1,spr['frames']); fr=decode_spr_frame(spr,i)
        scale=max(1,min(4,int(min(300/max(1,fr['width']),160/max(1,fr['height'])))))
        self.rtui_preview_photo=frame_to_tk_photo(fr,scale); c=self.rtui_preview_canvas; c.delete('all')
        cw=max(c.winfo_width(),self.rtui_preview_photo.width()+20); ch=max(c.winfo_height(),self.rtui_preview_photo.height()+20)
        c.create_image(cw//2,ch//2,image=self.rtui_preview_photo,anchor='center'); c.configure(scrollregion=(0,0,cw,ch))
        if spr['frames']>1 and _token==getattr(self,'rtui_preview_generation',0):
            self.rtui_preview_frame=(i+1)%spr['frames']
            delay=max(40,int(spr.get('interval') or 80))
            self.rtui_preview_after=self.root.after(delay,lambda tok=_token:self.rtui_render_resource_preview(tok))

    def rtui_find_game_hwnd(self):
        if os.name!='nt': return (0,0)
        user32=ctypes.windll.user32; kernel32=ctypes.windll.kernel32
        found=[0,0]
        EnumProc=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
        def cb(hwnd,lparam):
            if not user32.IsWindowVisible(hwnd): return True
            pid=ctypes.c_ulong(0); user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
            h=kernel32.OpenProcess(0x1000,False,pid.value)
            if not h:return True
            try:
                buf=ctypes.create_unicode_buffer(1024); size=ctypes.c_ulong(len(buf))
                if kernel32.QueryFullProcessImageNameW(h,0,buf,ctypes.byref(size)) and Path(buf.value).name.lower()=='game.exe':
                    found[0]=int(hwnd); found[1]=pid.value; return False
            finally: kernel32.CloseHandle(h)
            return True
        user32.EnumWindows(EnumProc(cb),0); return tuple(found)

    def rtui_launch_game(self):
        try:
            client=self.rs_client(); exe=client/'Game.exe'
            if not exe.exists(): raise FileNotFoundError(f'Không tìm thấy {exe}')
            subprocess.Popen([str(exe)],cwd=str(client)); self.rtui_game_status.set(f'Game.exe launched: {exe}')
            self.root.after(2000,self.rtui_refresh_game_status)
        except Exception as e: messagebox.showerror('Launch Game',str(e))

    def rtui_refresh_game_status(self):
        hwnd,pid=self.rtui_find_game_hwnd()
        self.rtui_game_hwnd=int(hwnd or 0); self.rtui_game_pid=int(pid or 0)
        self.rtui_game_status.set(f'Game.exe: RUNNING | PID={pid} | HWND=0x{hwnd:08X}' if hwnd else 'Game.exe: chưa tìm thấy cửa sổ đang chạy')

    def rtui_game_client_origin(self):
        if os.name!='nt' or not self.rtui_game_hwnd:
            return (0,0)
        class POINT(ctypes.Structure):
            _fields_=[('x',ctypes.c_long),('y',ctypes.c_long)]
        pt=POINT(0,0)
        try:
            ctypes.windll.user32.ClientToScreen(ctypes.c_void_p(self.rtui_game_hwnd),ctypes.byref(pt))
            return (int(pt.x),int(pt.y))
        except Exception:
            return (0,0)

    def rtui_clear_highlight(self):
        for w in list(self.rtui_highlight_windows):
            try:w.destroy()
            except Exception:pass
        self.rtui_highlight_windows=[]

    def rtui_show_highlight(self,eid):
        self.rtui_clear_highlight()
        e=self.rtui_elements.get(str(eid))
        if not e or not self.rtui_game_hwnd:return
        ox,oy=self.rtui_game_client_origin()
        x=ox+int(e.get('x',0)); y=oy+int(e.get('y',0))
        w=max(2,int(e.get('w',0))); h=max(2,int(e.get('h',0)))
        if w<=2 or h<=2:return
        # Four thin always-on-top windows give a game-overlay rectangle without
        # changing the D3D renderer or touching GameSpace.
        rects=((x,y,w,2),(x,y+h-2,w,2),(x,y,2,h),(x+w-2,y,2,h))
        for rx,ry,rw,rh in rects:
            try:
                top=tk.Toplevel(self.root)
                top.overrideredirect(True); top.attributes('-topmost',True)
                try:top.attributes('-alpha',0.82)
                except Exception:pass
                top.configure(bg='#00ff66')
                top.geometry(f'{max(1,rw)}x{max(1,rh)}+{rx}+{ry}')
                self.rtui_highlight_windows.append(top)
            except Exception:pass

    def rtui_show_ghost(self):
        if not self.rtui_resource:return
        self.rtui_hide_ghost()
        try:
            spr=self.rtui_resource['spr']
            fr=decode_spr_frame(spr,0)
            scale=max(1,min(3,int(min(120/max(1,fr['width']),120/max(1,fr['height'])))))
            self.rtui_ghost_photo=frame_to_tk_photo(fr,scale)
            top=tk.Toplevel(self.root)
            top.overrideredirect(True); top.attributes('-topmost',True)
            try:top.attributes('-alpha',0.70)
            except Exception:pass
            key='#010203'
            top.configure(bg=key)
            try:top.wm_attributes('-transparentcolor',key)
            except Exception:pass
            c=tk.Canvas(top,width=self.rtui_ghost_photo.width(),height=self.rtui_ghost_photo.height(),
                        bg=key,highlightthickness=0)
            c.pack()
            c.create_image(0,0,image=self.rtui_ghost_photo,anchor='nw')
            self.rtui_ghost=top; self.rtui_ghost_canvas=c
            self.rtui_move_ghost()
        except Exception as e:
            self.rtui_log_add('Ghost preview unavailable: '+str(e))

    def rtui_move_ghost(self):
        if not self.rtui_ghost:return
        try:
            x,y=self.root.winfo_pointerxy()
            self.rtui_ghost.geometry(f'+{x+16}+{y+16}')
        except Exception:pass

    def rtui_hide_ghost(self):
        if self.rtui_ghost:
            try:self.rtui_ghost.destroy()
            except Exception:pass
        self.rtui_ghost=None; self.rtui_ghost_canvas=None; self.rtui_ghost_photo=None

    def rtui_portable_detect_profile(self):
        game_path=''
        try:
            hwnd=self.rtui_find_game_hwnd()
            if hwnd:
                self.rtui_game_hwnd=hwnd
                game_path=self.rtui_get_process_image_path(hwnd) or ''
        except Exception:
            game_path=''

        if not game_path:
            try:
                game_path=str(self.client_var.get() or '')
            except Exception:
                game_path=''

        self.rtui_client_profile=jx_portable_profile_for_game(game_path)
        return self.rtui_client_profile

    def rtui_portable_set_offline(self,reason):
        self.rtui_runtime_supported=False
        self.rtui_portable_mode='OFFLINE'
        self.rtui_runtime_reason=str(reason or 'Runtime adapter unavailable.')
        self.rtui_caps=jx_portable_caps_default()
        try:
            self.rtui_status.set('OFFLINE / UNSUPPORTED — resource tools still available')
        except Exception:pass
        try:
            self.rtui_target_info.set(
                'Runtime UI unavailable for this client. Scanner / SPR Viewer / '
                'Resource Studio / Builders / Palette remain available.')
        except Exception:pass

    def rtui_portable_mark_connected(self):
        self.rtui_runtime_supported=True
        self.rtui_portable_mode='RUNTIME'
        self.rtui_runtime_reason='Compatible runtime bridge connected.'
        self.rtui_caps.update({
            'bridge':True,
            'ui_enum':True,
            'hittest':True,
            'setspr':True,
            'setrender':True,
            'testsprite':True,
            'cross_client_cache':True,
        })

    def rtui_portable_summary(self):
        p=self.rtui_client_profile or {}
        caps=self.rtui_caps or {}
        yes=lambda v:'YES' if v else 'NO'
        return (
            f"Client: {p.get('name','Unknown')}\n"
            f"Game: {p.get('game_path','') or 'not detected'}\n"
            f"Mode: {self.rtui_portable_mode}\n"
            f"Runtime Bridge: {yes(caps.get('bridge'))}\n"
            f"UI Enumeration: {yes(caps.get('ui_enum'))}\n"
            f"SPR Replace: {yes(caps.get('setspr'))}\n"
            f"Free Test SPR: {yes(caps.get('testsprite'))}\n"
            f"Reason: {self.rtui_runtime_reason}"
        )

    def rtui_portable_log_summary(self):
        self.rtui_portable_detect_profile()
        p=self.rtui_client_profile
        self.rtui_log_add(
            'Portable Client Profile: '+p.get('name','Unknown')+
            ' | game='+str(p.get('game_path','') or 'not detected')+
            ' | indicators='+','.join(p.get('detected_indicators') or [])+
            ' | mode='+self.rtui_portable_mode)

    def rtui_cancel_reconnect(self):
        if self.rtui_reconnect_after:
            try:self.root.after_cancel(self.rtui_reconnect_after)
            except Exception:pass
            self.rtui_reconnect_after=None

    def rtui_schedule_reconnect(self,delay_ms=None):
        if not self.rtui_want_connected or self.rtui_stop_event.is_set():return
        if self.rtui_connected or self.rtui_connecting:return
        if self.rtui_reconnect_after:return
        if delay_ms is None:
            # 0.5s, 1s, 2s, then cap at 3s.
            delay_ms=min(3000,500*(2**min(3,self.rtui_reconnect_attempt)))
        self.rtui_reconnect_attempt+=1
        self.rtui_status.set('RECONNECTING...')
        self.rtui_reconnect_after=self.root.after(delay_ms,self.rtui_reconnect_now)

    def rtui_reconnect_now(self):
        self.rtui_reconnect_after=None
        if not self.rtui_want_connected or self.rtui_connected or self.rtui_connecting:return
        self.rtui_log_add('Bridge auto-reconnect attempt %d...' % self.rtui_reconnect_attempt)
        self.rtui_connect(_auto=True)

    def rtui_ensure_connected_for_drag(self):
        if self.rtui_connected:return True
        if self.rtui_portable_mode=='OFFLINE':
            return False
        self.rtui_want_connected=True
        self.rtui_stop_event.clear()
        self.rtui_schedule_reconnect(1)
        return False

    def rtui_connect(self,_auto=False):
        if self.rtui_connected or self.rtui_connecting:
            return

        self.rtui_portable_detect_profile()
        self.rtui_portable_mode='CONNECTING'
        self.rtui_runtime_reason='Checking runtime adapter...'
        self.rtui_want_connected=True
        self.rtui_access_denied=False
        self.rtui_cancel_reconnect()
        self.rtui_refresh_game_status()
        self.rtui_stop_event.clear()
        self.rtui_connecting=True

        # A reconnect starts with a clean TX queue. Drag/drop will resend live
        # HOVER/TESTSPR commands after the bridge is available.
        try:
            while True:self.rtui_tx_queue.get_nowait()
        except queue.Empty:
            pass

        def io_worker():
            handle = None
            try:
                _jx_rtui_boot_log('SINGLE-OWNER CONNECT: CreateFileW '+self.rtui_pipe_name)
                handle = _jx_win32_open_pipe(self.rtui_pipe_name, 5000)
                _jx_rtui_boot_log('SINGLE-OWNER CONNECT OK handle=0x%X' % int(handle))

                self.rtui_pipe = handle
                self.rtui_connected = True
                self.rtui_connecting = False
                self.rtui_access_denied = False
                self.rtui_reconnect_attempt = 0
                self.rtui_portable_mark_connected()
                self.root.after(0, lambda:self.rtui_status.set(
                    'CONNECTED — JX Runtime UI Bridge'))
                self.root.after(0, lambda:self.rtui_log_add(
                    'Named Pipe connected (single-owner I/O): '+self.rtui_pipe_name))

                # Queue handshake after the pipe belongs exclusively to this worker.
                self.rtui_send('HELLO|JX_WORKSHOP|2.0')
                self.rtui_send('LIST')

                buf = b''
                tree_batch = None
                _jx_rtui_boot_log('SINGLE-OWNER IO WORKER START')

                while not self.rtui_stop_event.is_set():
                    did_work = False

                    # ----------------------------------------------------------
                    # TX: this I/O worker is the ONLY thread that calls WriteFile.
                    # ----------------------------------------------------------
                    tx_safety = 0
                    while tx_safety < 256:
                        try:
                            line = self.rtui_tx_queue.get_nowait()
                        except queue.Empty:
                            break

                        if line is None:
                            self.rtui_stop_event.set()
                            break

                        if not line.startswith('HOVER|'):
                            _jx_rtui_boot_log('SINGLE TX > '+line)

                        data = (line.rstrip('\r\n')+'\n').encode('utf-8')
                        wrote = _jx_win32_write_pipe(handle, data)

                        if not line.startswith('HOVER|'):
                            _jx_rtui_boot_log(
                                'SINGLE TX OK bytes=%d > %s' % (wrote, line))

                        did_work = True
                        tx_safety += 1

                    if self.rtui_stop_event.is_set():
                        break

                    # ----------------------------------------------------------
                    # RX: never issue a blocking ReadFile with no data pending.
                    # PeekNamedPipe first, then ReadFile only the available bytes.
                    # ----------------------------------------------------------
                    avail = _jx_win32_peek_pipe(handle)
                    if avail < 0:
                        _jx_rtui_boot_log('SINGLE RX: peer closed')
                        break

                    if avail > 0:
                        chunk = _jx_win32_read_pipe(handle, min(4096, avail))
                        if not chunk:
                            _jx_rtui_boot_log('SINGLE RX EOF / pipe closed')
                            break

                        _jx_rtui_boot_log('SINGLE RX OK bytes='+str(len(chunk)))
                        buf += chunk
                        did_work = True

                        while b'\n' in buf:
                            raw, buf = buf.split(b'\n', 1)
                            text = raw.decode('utf-8', 'replace').rstrip('\r')

                            if text.upper() == 'TREE_BEGIN':
                                tree_batch = [text]
                            elif tree_batch is not None:
                                tree_batch.append(text)
                                if text.upper() == 'TREE_END':
                                    batch = tree_batch
                                    tree_batch = None
                                    self.root.after(
                                        0, lambda b=batch:self.rtui_handle_batch(b))
                            else:
                                self.root.after(
                                    0, lambda value=text:self.rtui_handle_line(value))

                    if not did_work:
                        # 10 ms keeps drag/pick responsive without busy spinning.
                        time.sleep(0.01)

            except Exception as e:
                _jx_rtui_boot_log('SINGLE-OWNER IO EXCEPTION: '+repr(e))
                _jx_rtui_boot_log(traceback.format_exc())
                winerr=getattr(e,'winerror',None)
                if winerr==_JX_ERROR_ACCESS_DENIED:
                    self.rtui_access_denied=True
                    self.rtui_want_connected=False
                    self.root.after(
                        0,
                        lambda err=repr(e):self.rtui_log_add(
                            'PORTABLE RUNTIME OFFLINE: Named Pipe access denied. '
                            'This client may not include a compatible JXUIEditor bridge, '
                            'or Game/Workshop integrity differs. Offline resource tabs '
                            'remain fully available. Detail: '+err))
                    self.root.after(
                        0,
                        lambda:self.rtui_portable_set_offline(
                            'Named Pipe access denied (WinError 5).'))
                elif winerr==_JX_ERROR_FILE_NOT_FOUND:
                    self.rtui_want_connected=False
                    self.root.after(
                        0,
                        lambda:self.rtui_log_add(
                            'PORTABLE RUNTIME OFFLINE: JXUIEditor did not appear during the attach window in '
                            'this client. Runtime UI Designer disabled; all offline '
                            'resource tabs remain available.'))
                    self.root.after(
                        0,
                        lambda:self.rtui_portable_set_offline(
                            'JXUIEditor pipe was not available after waiting for Game.exe bridge startup.'))
                else:
                    self.root.after(
                        0,
                        lambda err=repr(e):self.rtui_log_add(
                            'Runtime bridge unavailable: '+err+
                            ' | Portable mode keeps offline resource tools enabled.'))
                    self.root.after(
                        0,
                        lambda err=repr(e):self.rtui_portable_set_offline(
                            'Runtime bridge unavailable: '+err))
            finally:
                self.rtui_connected = False
                self.rtui_connecting = False
                if handle and self.rtui_pipe == handle:
                    self.rtui_pipe = None
                    _jx_win32_close_pipe(handle)

                def _bridge_exit_ui():
                    if self.rtui_access_denied:
                        self.rtui_portable_set_offline(
                            'Named Pipe access denied (WinError 5).')
                        return
                    if self.rtui_want_connected and not self.rtui_stop_event.is_set():
                        self.rtui_log_add('Bridge connection lost; auto-reconnect armed.')
                        self.rtui_schedule_reconnect()
                    else:
                        self.rtui_status.set('DISCONNECTED')
                try:self.root.after(0,_bridge_exit_ui)
                except Exception:pass
                _jx_rtui_boot_log('SINGLE-OWNER IO WORKER EXIT')

        # Reuse reader_thread slot, but there is now only ONE pipe I/O thread.
        self.rtui_writer_thread = None
        self.rtui_reader_thread = threading.Thread(target=io_worker, daemon=True)
        self.rtui_reader_thread.start()

    def rtui_disconnect(self):
        self.rtui_want_connected=False
        self.rtui_cancel_reconnect()
        self.rtui_stop_event.set()
        try:
            self.rtui_tx_queue.put_nowait(None)
        except Exception:
            pass

        # Do not CloseHandle from the Tk thread. The single I/O owner closes it.
        self.rtui_connected = False
        self.rtui_hide_ghost(); self.rtui_clear_highlight()
        self.rtui_status.set('DISCONNECTING...')
        self.rtui_log_add('Disconnect requested.')

    def rtui_send(self,line):
        if not self.rtui_pipe or not self.rtui_connected:
            if self.rtui_portable_mode=='OFFLINE':
                if not line.startswith('HOVER|'):
                    self.rtui_log_add(
                        'Runtime command skipped (Portable Offline): '+line)
                return False
            self.rtui_log_add('Bridge chưa connected; reconnect requested: '+line)
            self.rtui_ensure_connected_for_drag()
            return False
        try:
            self.rtui_tx_queue.put_nowait(line)
            if not line.startswith('HOVER|'):
                _jx_rtui_boot_log('TX ENQUEUE > '+line)
            return True
        except queue.Full:
            if not line.startswith('HOVER|'):
                self.rtui_log_add('TX QUEUE FULL; command dropped: '+line)
            return False

    def rtui_handle_batch(self,lines):
        for line in lines:
            self.rtui_handle_line(line)

    def rtui_handle_line(self,line):
        if not line:return
        parts=line.split('|'); op=parts[0].upper()
        if op=='TREE_BEGIN':
            self.rtui_elements={}; self.rtui_tree.delete(*self.rtui_tree.get_children())
        elif op=='ELEMENT' and len(parts)>=10:
            eid,parent,typ,name=parts[1:5]
            try:x,y,w,h=map(int,parts[5:9])
            except Exception:x=y=w=h=0
            spr='|'.join(parts[9:])
            self.rtui_elements[eid]={'id':eid,'parent':parent,'type':typ,'name':name,'x':x,'y':y,'w':w,'h':h,'spr':spr}
        elif op=='TREE_END': self.rtui_rebuild_tree(); self.rtui_log_add(f'UI tree loaded: {len(self.rtui_elements)} elements')
        elif op in ('PICKED','HIT') and len(parts)>=2:
            eid=parts[1]
            if not eid:
                self.rtui_last_hit_id=''; self.rtui_last_hit_type=''; self.rtui_last_hit_spr=''
                if self.rtui_dragging:
                    self.rtui_locked_target_id=''; self.rtui_target_info.set('READY TO DROP: no valid UI target'); self.rtui_clear_highlight()
                return
            self.rtui_last_hit_id=eid
            if len(parts)>=3:self.rtui_last_hit_type=parts[2]
            if len(parts)>=4:self.rtui_last_hit_spr='|'.join(parts[3:])
            if self.rtui_dragging:self.rtui_locked_target_id=eid
            self.rtui_select_element(eid)
            prefix='READY TO DROP' if self.rtui_dragging else 'Smart Target'
            self.rtui_target_info.set(f"{prefix}: {eid} | {self.rtui_last_hit_type or self.rtui_elements.get(eid,{}).get('type','')} | SPR={self.rtui_last_hit_spr or self.rtui_elements.get(eid,{}).get('spr','')}")
            self.rtui_show_highlight(eid); self.rtui_update_resize_preview()
        elif op=='APPLIED':
            self.rtui_log_add('Runtime apply PASS: '+'|'.join(parts[1:]))
            if len(parts)>=3 and parts[1].upper() in ('DROP','DROPLOCK'):
                self.rtui_last_hit_id=parts[2]
                self.rtui_log_add('Live SPR replace PASS on '+parts[2]+' | '+self.rtui_resize_info.get())
            self.rtui_send('LIST')
        elif op=='ERROR':
            msg='|'.join(parts[1:])
            self.rtui_log_add('Runtime ERROR: '+msg)
            if 'SPR_LOAD_FAIL' in msg or 'SETSPR_FAIL' in msg:
                self.rtui_target_info.set('LIVE REPLACE FAILED — '+msg)
        elif op=='TESTSPR' and len(parts)>=2:
            self.rtui_test_sprite_count+=1
            self.rtui_log_add('Free Test Sprite created: '+'|'.join(parts[1:]))
            self.rtui_target_info.set('FREE TEST SPRITE — không apply vào UI')
        elif op=='INFO': self.rtui_log_add('Runtime: '+'|'.join(parts[1:]))
        else:self.rtui_log_add('< '+line)

    def rtui_rebuild_tree(self):
        self.rtui_tree.delete(*self.rtui_tree.get_children()); pending=dict(self.rtui_elements); made=set()
        for _ in range(len(pending)+2):
            progress=False
            for eid,e in list(pending.items()):
                parent=e['parent'] if e['parent'] in made else ''
                if e['parent'] and e['parent'] not in made and e['parent'] in pending: continue
                try:self.rtui_tree.insert(parent,'end',iid=eid,text=e['name'] or eid,values=(e['type'],f"{e['x']},{e['y']} {e['w']}x{e['h']}"))
                except Exception:self.rtui_tree.insert('','end',iid=eid,text=e['name'] or eid,values=(e['type'],f"{e['x']},{e['y']} {e['w']}x{e['h']}"))
                made.add(eid); pending.pop(eid,None); progress=True
            if not progress:break
        for eid,e in pending.items():
            self.rtui_tree.insert('','end',iid=eid,text=e['name'] or eid,values=(e['type'],f"{e['x']},{e['y']} {e['w']}x{e['h']}"))

    def rtui_tree_select(self,event=None):
        sel=self.rtui_tree.selection()
        if sel:self.rtui_select_element(sel[0],tree_sync=False)

    def rtui_select_element(self,eid,tree_sync=True):
        e=self.rtui_elements.get(str(eid));
        if not e:return
        self.rtui_selected_id=str(eid); self.rtui_x.set(e['x']); self.rtui_y.set(e['y']); self.rtui_w.set(e['w']); self.rtui_h.set(e['h']); self.rtui_spr_path.set(e.get('spr',''))
        self.rtui_element_info.set(f"ID={eid} | {e['type']} | {e['name']} | Rect=({e['x']},{e['y']},{e['w']},{e['h']})")
        self.rtui_target_info.set(f"Selected: {eid} | {e['type']} | SPR={e.get('spr','')}")
        self.rtui_show_highlight(eid); self.rtui_update_resize_preview()
        if tree_sync and self.rtui_tree.exists(str(eid)):
            self.rtui_tree.selection_set(str(eid)); self.rtui_tree.see(str(eid))

    def rtui_toggle_pick(self):
        self.rtui_send('PICK|'+('1' if self.rtui_pick_mode.get() else '0'))

    def rtui_point_in_game_client(self, sx, sy):
        if os.name!='nt' or not self.rtui_game_hwnd:return False
        class POINT(ctypes.Structure):_fields_=[('x',ctypes.c_long),('y',ctypes.c_long)]
        class RECT(ctypes.Structure):_fields_=[('left',ctypes.c_long),('top',ctypes.c_long),('right',ctypes.c_long),('bottom',ctypes.c_long)]
        try:
            pt=POINT(int(sx),int(sy)); rc=RECT()
            if not ctypes.windll.user32.ScreenToClient(ctypes.c_void_p(self.rtui_game_hwnd),ctypes.byref(pt)):return False
            if not ctypes.windll.user32.GetClientRect(ctypes.c_void_p(self.rtui_game_hwnd),ctypes.byref(rc)):return False
            return pt.x>=rc.left and pt.y>=rc.top and pt.x<rc.right and pt.y<rc.bottom
        except Exception:return False

    def rtui_compute_free_test_size(self):
        if not self.rtui_resource:return (0,0)
        try:
            sw=max(1,int(self.rtui_resource['spr'].get('width',1))); sh=max(1,int(self.rtui_resource['spr'].get('height',1)))
        except Exception:return (0,0)
        if self.rtui_scale_mode.get()=='Custom':
            rw=max(1,int(self.rtui_custom_w.get() or sw)); rh=max(1,int(self.rtui_custom_h.get() or sh))
            if self.rtui_keep_aspect.get():rh=max(1,int(round(rw*sh/float(sw))))
            return (rw,rh)
        return (sw,sh)

    def rtui_clear_test_sprites(self):
        if self.rtui_send('TESTCLEAR'):
            self.rtui_test_sprite_count=0
            self.rtui_log_add('Free Test Sprites: clear requested.')

    def rtui_compute_render_size(self, eid=None):
        eid=str(eid or self.rtui_locked_target_id or self.rtui_selected_id or '')
        e=self.rtui_elements.get(eid,{})
        tw=max(1,int(e.get('w',0) or self.rtui_w.get() or 1)); th=max(1,int(e.get('h',0) or self.rtui_h.get() or 1))
        sw=sh=0
        if self.rtui_resource:
            try:
                sw=max(1,int(self.rtui_resource['spr'].get('width',0))); sh=max(1,int(self.rtui_resource['spr'].get('height',0)))
            except Exception: pass
        if not sw or not sh:return (0,0,0,tw,th,sw,sh)
        mode=self.rtui_scale_mode.get()
        if mode=='Original': rw=rh=0
        elif mode=='Stretch': rw,rh=tw,th
        elif mode=='Custom':
            rw=max(1,int(self.rtui_custom_w.get() or 1)); rh=max(1,int(self.rtui_custom_h.get() or 1))
            if self.rtui_keep_aspect.get(): rh=max(1,int(round(rw*sh/float(sw))))
        else:
            scale=min(tw/float(sw),th/float(sh)); rw=max(1,int(round(sw*scale))); rh=max(1,int(round(sh*scale)))
        return (rw,rh,1 if self.rtui_align_mode.get()=='Center' else 0,tw,th,sw,sh)

    def rtui_update_resize_preview(self):
        try:
            rw,rh,align,tw,th,sw,sh=self.rtui_compute_render_size()
            render='native' if rw<=0 or rh<=0 else f'{rw}x{rh}'
            self.rtui_resize_info.set(f'Resize: Native {sw}x{sh} | Target {tw}x{th} | {self.rtui_scale_mode.get()} -> {render} | {self.rtui_align_mode.get()}')
        except Exception as e:self.rtui_resize_info.set('Resize: '+str(e))

    def rtui_apply_resize(self):
        eid=self.rtui_locked_target_id or self.rtui_selected_id
        if not eid:return
        rw,rh,align,tw,th,sw,sh=self.rtui_compute_render_size(eid)
        self.rtui_send(f'SETRENDER|{eid}|{rw}|{rh}|{align}')
        self.rtui_log_add(f'Render resize requested: {eid} mode={self.rtui_scale_mode.get()} size={rw}x{rh} align={align}')

    def rtui_reset_render_size(self):
        eid=self.rtui_locked_target_id or self.rtui_selected_id
        if not eid:return
        self.rtui_send(f'SETRENDER|{eid}|0|0|0'); self.rtui_log_add('Render size reset to native: '+eid)

    def rtui_apply_rect(self):
        if not self.rtui_selected_id:return
        cmd=f"SETRECT|{self.rtui_selected_id}|{int(self.rtui_x.get())}|{int(self.rtui_y.get())}|{int(self.rtui_w.get())}|{int(self.rtui_h.get())}"
        if self.rtui_send(cmd): self.rtui_project_changes.setdefault(self.rtui_selected_id,{})['rect']=[int(self.rtui_x.get()),int(self.rtui_y.get()),int(self.rtui_w.get()),int(self.rtui_h.get())]

    def rtui_apply_selected_spr(self):
        eid=self.rtui_locked_target_id or self.rtui_selected_id
        if not eid or not self.rtui_resource:
            messagebox.showwarning('Real-Time UI Designer','Cần chọn runtime element và Use Selected Resource.'); return
        vp=self.rtui_resource['virtual_path']
        rw,rh,align,tw,th,sw,sh=self.rtui_compute_render_size(eid)
        if self.rtui_send(f'DROPLOCK|{eid}|{rw}|{rh}|{align}|{vp}'):
            ch=self.rtui_project_changes.setdefault(eid,{})
            ch['spr']=vp; ch['render']={'mode':self.rtui_scale_mode.get(),'w':rw,'h':rh,'align':align}

    def rtui_reset_element(self):
        if self.rtui_selected_id:self.rtui_send('RESET|'+self.rtui_selected_id)

    def rtui_get_native_mouse_state(self):
        # Native Win32 mouse state is used for detached Palette drags because
        # Tk/Toplevel ButtonRelease events are not reliable after the cursor
        # crosses into another native HWND (Game.exe).
        if os.name!='nt':
            try:
                x,y=self.root.winfo_pointerxy()
                return int(x),int(y),True
            except Exception:
                return 0,0,False
        class POINT(ctypes.Structure):
            _fields_=[('x',ctypes.c_long),('y',ctypes.c_long)]
        try:
            pt=POINT()
            if not ctypes.windll.user32.GetCursorPos(ctypes.byref(pt)):
                return 0,0,False
            down=(ctypes.windll.user32.GetAsyncKeyState(0x01) & 0x8000)!=0
            return int(pt.x),int(pt.y),bool(down)
        except Exception:
            return 0,0,False

    def rtui_palette_native_drag_begin(self):
        self.rtui_palette_native_drag=True
        # This method is called from WM/Tk ButtonPress, therefore LMB is
        # already physically down. Mark it immediately so a fast release
        # between polling ticks is still recognized.
        self.rtui_palette_native_seen_down=True
        if self.rtui_palette_native_after is not None:
            try:self.root.after_cancel(self.rtui_palette_native_after)
            except Exception:pass
        self.rtui_palette_native_after=self.root.after(8,self.rtui_palette_native_drag_tick)
        self.rtui_log_add('Palette native drag tracker START')

    def rtui_palette_native_drag_stop(self):
        self.rtui_palette_native_drag=False
        self.rtui_palette_native_seen_down=False
        self.pal_drag_candidate=-1
        self.pal_drag_start_xy=None
        if self.rtui_palette_native_after is not None:
            try:self.root.after_cancel(self.rtui_palette_native_after)
            except Exception:pass
        self.rtui_palette_native_after=None

    def rtui_palette_native_drag_tick(self):
        self.rtui_palette_native_after=None
        if not self.rtui_palette_native_drag or not self.rtui_dragging:
            self.rtui_palette_native_drag_stop()
            return
        x,y,down=self.rtui_get_native_mouse_state()
        try:
            self.rtui_move_ghost()
            now=time.time(); xy=(int(x),int(y))
            if (now-self.rtui_last_hover_sent_at)>=0.04 and xy!=self.rtui_last_hover_xy:
                self.rtui_last_hover_sent_at=now
                self.rtui_last_hover_xy=xy
                self.rtui_send(f'HOVER|{x}|{y}')
        except Exception:
            pass

        if down:
            self.rtui_palette_native_seen_down=True
        elif self.rtui_palette_native_seen_down:
            # Physical LMB release detected even if Tk never receives
            # <ButtonRelease-1> because pointer is over Game.exe.
            self.rtui_log_add(f'Palette native mouse RELEASE at ({x},{y})')
            self.rtui_palette_native_drag_stop()
            self.rtui_drag_end(None)
            return

        self.rtui_palette_native_after=self.root.after(8,self.rtui_palette_native_drag_tick)

    def rtui_get_game_exe_path(self):
        if os.name!='nt':
            return None
        try:
            hwnd,pid=self.rtui_find_game_hwnd()
            if not pid:return None
            kernel32=ctypes.windll.kernel32
            PROCESS_QUERY_LIMITED_INFORMATION=0x1000
            h=kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,False,int(pid))
            if not h:return None
            try:
                buf=ctypes.create_unicode_buffer(32768)
                size=ctypes.c_ulong(len(buf))
                if kernel32.QueryFullProcessImageNameW(h,0,buf,ctypes.byref(size)):
                    return Path(buf.value)
            finally:
                kernel32.CloseHandle(h)
        except Exception as e:
            self.rtui_log_add('Cross-client cache: cannot query Game.exe path: '+repr(e))
        return None

    def rtui_resource_raw_bytes(self,res):
        if not res:
            raise ValueError('No runtime SPR resource selected.')
        raw=res.get('raw')
        if isinstance(raw,(bytes,bytearray)) and raw:
            return bytes(raw)

        row=res.get('row')
        if not row:
            raise ValueError('Selected SPR has no Resource Studio row/raw bytes.')

        # Palette resources intentionally cache parsed SPR only; recover the
        # authoritative raw payload from its source PAK on demand.
        try:
            pak,entry=self.pal_entry(row)
        except Exception:
            pak,entry=self.rs_entry(row)
        raw,detail=native_read_xpack_entry_bytes(pak,entry)
        if not raw:
            raise ValueError('Source PAK returned empty SPR payload.')
        res['raw']=raw
        res['source_pak']=str(pak)
        return raw

    def rtui_prepare_external_spr(self,res,force=False):
        if not res:
            return ''
        original=normalize_virtual_path(res.get('virtual_path',''))
        if not original:
            return ''

        # Disabled means exact legacy behavior.
        try:
            enabled=bool(self.rtui_external_cache_enabled.get())
        except Exception:
            enabled=True
        if not enabled and not force:
            res['runtime_virtual_path']=original
            return original

        game_exe=self.rtui_get_game_exe_path()
        if not game_exe:
            self.rtui_log_add('Cross-client cache: Game.exe path unavailable; using original virtual path.')
            res['runtime_virtual_path']=original
            return original

        try:
            raw=self.rtui_resource_raw_bytes(res)
        except Exception as e:
            self.rtui_log_add('Cross-client cache READ FAIL: '+original+' | '+repr(e))
            res['runtime_virtual_path']=original
            return original

        # ASCII hash filename also solves legacy ANSI issues for Unicode SPR names.
        digest=hashlib.sha1(raw).hexdigest()
        short=digest[:20]
        game_dir=game_exe.parent
        cache_dir=game_dir/'spr'/'__jxruntimecache'
        cache_file=cache_dir/('jx_'+short+'.spr')
        runtime_vp='\\spr\\__jxruntimecache\\jx_'+short+'.spr'

        try:
            cache_dir.mkdir(parents=True,exist_ok=True)
            need_write=True
            if cache_file.exists():
                try:
                    need_write=(cache_file.stat().st_size!=len(raw) or
                                hashlib.sha1(cache_file.read_bytes()).hexdigest()!=digest)
                except Exception:
                    need_write=True
            if need_write:
                tmp=cache_file.with_suffix('.spr.tmp')
                tmp.write_bytes(raw)
                try:
                    with tmp.open('rb') as f: os.fsync(f.fileno())
                except Exception:
                    pass
                if cache_file.exists():
                    try:cache_file.unlink()
                    except Exception:pass
                tmp.replace(cache_file)

            self.rtui_external_cache_dir=cache_dir
            self.rtui_external_cache_map[original]={
                'runtime_virtual_path':runtime_vp,
                'file':str(cache_file),
                'sha1':digest,
                'bytes':len(raw),
            }
            res['runtime_virtual_path']=runtime_vp
            res['runtime_cache_file']=str(cache_file)
            res['runtime_cache_sha1']=digest
            self.rtui_log_add(
                f'Cross-client SPR CACHE READY: source={original} -> runtime={runtime_vp} '
                f'bytes={len(raw)} game={game_exe}'
            )
            return runtime_vp
        except Exception as e:
            self.rtui_log_add(
                f'Cross-client SPR CACHE WRITE FAIL: source={original} game={game_exe} | {repr(e)}'
            )
            res['runtime_virtual_path']=original
            return original

    def rtui_runtime_virtual_path(self):
        if not self.rtui_resource:
            return ''
        original=normalize_virtual_path(self.rtui_resource.get('virtual_path',''))
        runtime=self.rtui_resource.get('runtime_virtual_path','')
        return normalize_virtual_path(runtime or original)

    def rtui_open_external_cache(self):
        if self.rtui_external_cache_dir and Path(self.rtui_external_cache_dir).exists():
            try:os.startfile(str(self.rtui_external_cache_dir)); return
            except Exception as e:
                messagebox.showerror('Cross-Client SPR Cache',str(e)); return
        game_exe=self.rtui_get_game_exe_path()
        if not game_exe:
            messagebox.showinfo('Cross-Client SPR Cache','Chưa tìm thấy Game.exe đang chạy.')
            return
        p=game_exe.parent/'spr'/'__jxruntimecache'
        try:
            p.mkdir(parents=True,exist_ok=True)
            self.rtui_external_cache_dir=p
            os.startfile(str(p))
        except Exception as e:
            messagebox.showerror('Cross-Client SPR Cache',str(e))

    def rtui_drag_start(self,event):
        if not self.rtui_resource:return
        # Make the selected SPR visible to the running Game client before the
        # pointer leaves Workshop. For same-client SPRs this is harmless; for
        # cross-client/Unicode resources the renderer receives an ASCII loose path.
        runtime_vp=self.rtui_prepare_external_spr(self.rtui_resource)
        self.rtui_dragging=True; self.rtui_locked_target_id=''; self.rtui_last_hit_id=''; self.rtui_last_hover_sent_at=0.0; self.rtui_last_hover_xy=None
        self.rtui_drag_grab_widget=getattr(event,'widget',None) or self.rtui_preview_canvas
        # Detached Palette uses native Win32 polling and must not rely on a Tk
        # global grab crossing into Game.exe. Runtime preview drag keeps the
        # legacy grab path.
        is_palette_event=False
        try:
            is_palette_event=(self.pal_window is not None and
                              str(self.rtui_drag_grab_widget).startswith(str(self.pal_window)))
        except Exception:
            is_palette_event=False
        if not is_palette_event:
            try:self.rtui_drag_grab_widget.grab_set_global()
            except Exception:
                try:self.rtui_preview_canvas.grab_set_global(); self.rtui_drag_grab_widget=self.rtui_preview_canvas
                except Exception:self.rtui_drag_grab_widget=None
        else:
            self.rtui_drag_grab_widget=None
        self.rtui_show_ghost(); self.rtui_target_info.set('READY TO DROP: move over a UI image')
        src_vp=self.rtui_resource['virtual_path']
        run_vp=self.rtui_runtime_virtual_path()
        if run_vp!=src_vp:
            self.rtui_ensure_connected_for_drag()
            self.rtui_log_add(f'Drag started: {src_vp} | runtime cache={run_vp}')
        else:
            self.rtui_log_add('Drag started: '+src_vp)

    def rtui_drag_motion(self,event):
        if not self.rtui_dragging:return
        try:
            self.rtui_move_ghost(); x,y=self.root.winfo_pointerxy(); now=time.time(); xy=(int(x),int(y))
            if (now-self.rtui_last_hover_sent_at)>=0.04 and xy!=self.rtui_last_hover_xy:
                self.rtui_last_hover_sent_at=now; self.rtui_last_hover_xy=xy; self.rtui_send(f'HOVER|{x}|{y}')
        except Exception:pass

    def rtui_apply_collision_preset(self):
        """C1.3C.1: Apply only validated collision geometry; does not move the SPR."""
        try:
            preset=str(self.rtui_collision_preset.get() or 'CUSTOM').upper()
            if preset == 'TREE 128X256':
                self.rtui_collision_enabled.set(True)
                self.rtui_collision_w.set(128)
                self.rtui_collision_h.set(256)
                self.rtui_collision_kind.set('NORMAL')
                self.rtui_log_add('Collision preset: TREE 128x256 (NORMAL). Offsets preserved.')
            else:
                self.rtui_log_add('Collision preset: CUSTOM (manual values preserved).')
            return True
        except Exception as e:
            self.rtui_log_add('Collision preset failed: '+str(e))
            return False

    def rtui_world_collision_kind_value(self):
        name=str(self.rtui_collision_kind.get() or 'NORMAL').upper()
        return {'NORMAL':1,'FLY':2,'JUMP':3,'JUMPFLY':4}.get(name,1)

    def rtui_apply_world_character_layer(self):
        try:
            mode=str(self.rtui_world_character_layer.get() or 'UNDER CHARACTER').upper()
            layer=1 if mode.startswith('OVER') else 0
            self.rtui_send(f'WORLDCHARLAYER|{layer}')
            self.rtui_log_add(f'WORLD character layer template: {mode} (next WORLD drop only)')
            return True
        except Exception as e:
            self.rtui_log_add('WORLD character layer template failed: '+str(e))
            return False

    def rtui_apply_world_name_layer(self):
        try:
            mode=str(self.rtui_world_name_layer.get() or 'BELOW NAME').upper()
            layer=1 if mode=='ABOVE NAME' else 0
            self.rtui_send(f'WORLDLAYER|{layer}')
            self.rtui_log_add(f'WORLD layer template: {mode} (next WORLD drop only)')
            return True
        except Exception as e:
            self.rtui_log_add('WORLD layer template failed: '+str(e))
            return False

    def rtui_apply_world_collision(self):
        try:
            enabled=1 if bool(self.rtui_collision_enabled.get()) else 0
            w=max(1,min(4096,int(self.rtui_collision_w.get())))
            h=max(1,min(4096,int(self.rtui_collision_h.get())))
            ox=max(-4096,min(4096,int(self.rtui_collision_offset_x.get())))
            oy=max(-4096,min(4096,int(self.rtui_collision_offset_y.get())))
            kind=self.rtui_world_collision_kind_value()
            # Write normalized values back so the UI always matches runtime.
            self.rtui_collision_w.set(w); self.rtui_collision_h.set(h)
            self.rtui_collision_offset_x.set(ox); self.rtui_collision_offset_y.set(oy)
            self.rtui_send(f'WORLDCOLLISION|{enabled}|{w}|{h}|{ox}|{oy}|{kind}')
            self.rtui_log_add(
                f'WORLD collision template: enabled={enabled} size={w}x{h} '
                f'offset={ox},{oy} type={self.rtui_collision_kind.get()}'
            )
            return True
        except Exception as e:
            self.rtui_log_add('WORLD collision apply failed: '+str(e))
            try:messagebox.showerror('WORLD Collision','Width/Height/Offset phải là số nguyên.')
            except Exception:pass
            return False

    def rtui_save_world_spr(self):
        try:
            if str(self.rtui_placement_mode.get() or '').upper()=='FOLLOW PLAYER':
                self.rtui_log_add('Save World SPR skipped: FOLLOW PLAYER là runtime attachment, không phải fixed world object.')
                try:messagebox.showinfo('Save World SPR','FOLLOW PLAYER hiện là runtime-only và không lưu thành fixed WORLD object.')
                except Exception:pass
                return False
            if not self.rtui_connected:
                self.rtui_log_add('Save World SPR failed: Runtime Bridge chưa kết nối.')
                return False
            self.rtui_send('SAVEWORLDSPR')
            self.rtui_log_add('Save World SPR requested: WORLD SPR cuối cùng.')
            return True
        except Exception as e:
            self.rtui_log_add('Save World SPR failed: '+str(e))
            return False


    def rtui_save_follow_spr(self):
        try:
            if not self.rtui_connected:
                self.rtui_log_add('Save Follow SPR failed: Runtime Bridge chưa kết nối.')
                return False
            self.rtui_send('SAVEFOLLOWSPR')
            self.rtui_log_add('Save Follow SPR requested: FOLLOW PLAYER SPR cuối cùng.')
            return True
        except Exception as e:
            self.rtui_log_add('Save Follow SPR failed: '+str(e)); return False

    def rtui_delete_saved_follow_spr(self):
        try:
            if not self.rtui_connected:
                self.rtui_log_add('Delete Saved Follow SPR failed: Runtime Bridge chưa kết nối.')
                return False
            if not messagebox.askyesno('Delete Saved Follow SPR','Xóa FOLLOW PLAYER SPR đã Save gần nhất?\n\nSPR resource/source sẽ KHÔNG bị xóa.'):
                return False
            self.rtui_send('DELETEFOLLOWSPR')
            self.rtui_log_add('Delete Saved Follow SPR requested.')
            return True
        except Exception as e:
            self.rtui_log_add('Delete Saved Follow SPR failed: '+str(e)); return False

    def rtui_select_saved_world_spr(self):
        try:
            if not self.rtui_connected:
                self.rtui_log_add('Select Saved WORLD SPR failed: Runtime Bridge chưa kết nối.')
                return False
            if self.rtui_world_select_after is not None:
                try:self.root.after_cancel(self.rtui_world_select_after)
                except Exception:pass
            self.rtui_world_select_seen_up=False
            self.rtui_log_add('SELECT MODE: click chuột trái lên Saved WORLD SPR trong Game.exe.')
            self.rtui_world_select_after=self.root.after(25,self.rtui_select_saved_world_spr_tick)
            return True
        except Exception as e:
            self.rtui_log_add('Select Saved WORLD SPR failed: '+str(e)); return False

    def rtui_select_saved_world_spr_tick(self):
        self.rtui_world_select_after=None
        try:
            x,y,down=self.rtui_get_native_mouse_state()
            if not down:
                self.rtui_world_select_seen_up=True
            elif self.rtui_world_select_seen_up:
                if self.rtui_point_in_game_client(x,y):
                    self.rtui_send(f'WORLDSELECT|{int(x)}|{int(y)}')
                    self.rtui_log_add(f'WORLD SELECT requested at screen=({int(x)},{int(y)}).')
                    self.rtui_world_select_seen_up=False
                    return
            self.rtui_world_select_after=self.root.after(25,self.rtui_select_saved_world_spr_tick)
        except Exception as e:
            self.rtui_log_add('WORLD SELECT tracker failed: '+str(e))

    def rtui_delete_selected_world_spr(self):
        try:
            if not self.rtui_connected:
                self.rtui_log_add('Delete Selected WORLD SPR failed: Runtime Bridge chưa kết nối.'); return False
            if not messagebox.askyesno('Delete Saved WORLD SPR','Xóa WORLD SPR đang được chọn khỏi world?\n\nSPR resource/source sẽ KHÔNG bị xóa.'):
                return False
            self.rtui_send('DELETEWORLDSPR')
            self.rtui_log_add('Delete Selected WORLD SPR requested.')
            return True
        except Exception as e:
            self.rtui_log_add('Delete Selected WORLD SPR failed: '+str(e)); return False

    def rtui_drag_end(self,event):
        if not self.rtui_dragging:return
        self.rtui_dragging=False
        if self.rtui_palette_native_drag:
            self.rtui_palette_native_drag_stop()
        try:
            if self.rtui_drag_grab_widget:self.rtui_drag_grab_widget.grab_release()
            else:self.rtui_preview_canvas.grab_release()
        except Exception:pass
        self.rtui_drag_grab_widget=None
        self.rtui_hide_ghost()
        source_vp=self.rtui_resource['virtual_path'] if self.rtui_resource else ''
        vp=self.rtui_runtime_virtual_path()
        try:
            sx,sy,_native_down=self.rtui_get_native_mouse_state()
            if not sx and not sy:sx,sy=self.root.winfo_pointerxy()
        except Exception:sx=sy=0

        eid=self.rtui_locked_target_id or self.rtui_last_hit_id
        if eid:
            rw,rh,align,tw,th,sw,sh=self.rtui_compute_render_size(eid)
            self.rtui_send(f'DROPLOCK|{eid}|{rw}|{rh}|{align}|{vp}')
            ch=self.rtui_project_changes.setdefault(eid,{})
            ch['spr']=source_vp
            if vp!=source_vp:ch['runtime_spr']=vp
            ch['render']={'mode':self.rtui_scale_mode.get(),'w':rw,'h':rh,'align':align}
            self.rtui_log_add(
                f'Drop locked: {eid} | source={source_vp} | runtime={vp} | '
                f'mode={self.rtui_scale_mode.get()} render={rw}x{rh} target={tw}x{th}'
            )
            return

        if self.rtui_point_in_game_client(sx,sy):
            rw,rh=self.rtui_compute_free_test_size()
            placement=str(self.rtui_placement_mode.get() or 'SCREEN').upper()
            if placement in ('WORLD','FOLLOW PLAYER'):
                # C1.3C.6/C1.3C.7: explicit ordering below/above character body.
                # Character names remain above both modes.
                self.rtui_world_name_layer.set('BELOW NAME')
                if not self.rtui_apply_world_name_layer():
                    return
                if not self.rtui_apply_world_character_layer():
                    return
                if placement=='FOLLOW PLAYER':
                    # Follow-player effects are visual attachments only. Runtime
                    # forcibly keeps collision OFF regardless of the current WORLD preset.
                    self.rtui_send(f'FOLLOWTESTSPR|{int(sx)}|{int(sy)}|{rw}|{rh}|{vp}')
                    self.rtui_log_add(f'FOLLOW PLAYER DROP requested anchor={int(sx)},{int(sy)} size={rw}x{rh} path={vp} collision=FORCED_OFF')
                else:
                    if not self.rtui_apply_world_collision():
                        return
                    self.rtui_send(f'WORLDTESTSPR|{int(sx)}|{int(sy)}|{rw}|{rh}|{vp}')
                    self.rtui_log_add(f'WORLD DROP requested screen={int(sx)},{int(sy)} size={rw}x{rh} path={vp}')
            else:
                self.rtui_send(f'TESTSPR|{int(sx)}|{int(sy)}|{rw}|{rh}|{vp}')
            self.rtui_log_add(
                f'Free test requested at screen ({sx},{sy}): source={source_vp} '
                f'runtime={vp} size={rw}x{rh}'
            )
            self.rtui_target_info.set('FREE TEST SPRITE — release outside green target')
        else:
            self.rtui_log_add('Drop cancelled: pointer is outside Game.exe and no UI target is locked.')
            self.rtui_target_info.set('DROP CANCELLED — outside Game.exe')


    def rtui_save_project(self):
        default='JX_UI_PROJECT.json'; out=filedialog.asksaveasfilename(title='Save Runtime UI Project',initialfile=default,defaultextension='.json',filetypes=[('JSON','*.json')])
        if not out:return
        data={'format':'JX_RUNTIME_UI_PROJECT_V1','client':str(self.rs_client()),'changes':self.rtui_project_changes,'saved_at':datetime.now().isoformat(timespec='seconds')}
        Path(out).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8'); self.rtui_log_add('Project saved: '+out)

    def rtui_load_project(self):
        p=filedialog.askopenfilename(title='Load Runtime UI Project',filetypes=[('JSON','*.json')])
        if not p:return
        try:
            data=json.loads(Path(p).read_text(encoding='utf-8')); changes=data.get('changes',{})
            for eid,ch in changes.items():
                if 'rect' in ch:
                    x,y,w,h=ch['rect']; self.rtui_send(f'SETRECT|{eid}|{x}|{y}|{w}|{h}')
                if ch.get('spr'):self.rtui_send(f"SETSPR|{eid}|{ch['spr']}")
            self.rtui_project_changes=changes; self.rtui_log_add(f'Project loaded/applied: {p} ({len(changes)} elements)')
        except Exception as e:messagebox.showerror('Load Runtime UI Project',str(e))

    def _build_spr_viewer(self,parent):
        self.viewer_path_var=tk.StringVar(); self.viewer_info_var=tk.StringVar(value='Chưa mở SPR.')
        self.viewer_frame_var=tk.IntVar(value=0); self.viewer_scale_var=tk.IntVar(value=1); self.viewer_speed_var=tk.StringVar(value='1.0x')
        self.viewer_playing=False; self.viewer_spr=None; self.viewer_photo=None
        self.viewer_decoded_cache={}; self.viewer_photo_cache={}; self.viewer_after_id=None
        top=ttk.Frame(parent); top.pack(fill='x',padx=10,pady=10)
        ttk.Label(top,text='SPR Viewer',style='Title.TLabel').grid(row=0,column=0,columnspan=4,sticky='w')
        ttk.Entry(top,textvariable=self.viewer_path_var).grid(row=1,column=0,sticky='ew',pady=(8,0)); ttk.Button(top,text='Mở SPR...',command=self.viewer_choose_file).grid(row=1,column=1,padx=6,pady=(8,0))
        ttk.Button(top,text='SPR extracted...',command=self.viewer_choose_extracted).grid(row=1,column=2,pady=(8,0)); top.columnconfigure(0,weight=1)
        ttk.Label(parent,textvariable=self.viewer_info_var,justify='left').pack(fill='x',padx=12)
        ctl=ttk.Frame(parent); ctl.pack(fill='x',padx=10,pady=7)
        ttk.Button(ctl,text='◀',width=4,command=lambda:self.viewer_step(-1)).pack(side='left'); ttk.Button(ctl,text='▶',width=4,command=lambda:self.viewer_step(1)).pack(side='left',padx=3)
        self.viewer_play_btn=ttk.Button(ctl,text='Play',command=self.viewer_toggle_play); self.viewer_play_btn.pack(side='left',padx=(6,12))
        ttk.Label(ctl,text='Frame:').pack(side='left'); self.viewer_spin=ttk.Spinbox(ctl,from_=0,to=0,width=7,textvariable=self.viewer_frame_var,command=self.viewer_render); self.viewer_spin.pack(side='left',padx=4)
        self.viewer_spin.bind('<Return>',lambda e:self.viewer_render()); self.viewer_spin.bind('<FocusOut>',lambda e:self.viewer_render())
        ttk.Label(ctl,text='Zoom:').pack(side='left',padx=(12,2)); sc=ttk.Combobox(ctl,width=5,state='readonly',values=[1,2,3,4],textvariable=self.viewer_scale_var); sc.pack(side='left'); sc.bind('<<ComboboxSelected>>',lambda e:self.viewer_zoom_changed())
        ttk.Label(ctl,text='Speed:').pack(side='left',padx=(12,2)); spd=ttk.Combobox(ctl,width=6,state='readonly',values=['0.25x','0.5x','1.0x','1.5x','2.0x','4.0x'],textvariable=self.viewer_speed_var); spd.pack(side='left')
        ttk.Button(ctl,text='Export PNG Frames',command=self.viewer_export_png).pack(side='left',padx=(14,0))
        canvas_fr=ttk.Frame(parent); canvas_fr.pack(fill='both',expand=True,padx=10,pady=(0,10))
        self.viewer_canvas=tk.Canvas(canvas_fr,background=self.ui['canvas'],highlightthickness=0); self.viewer_canvas.grid(row=0,column=0,sticky='nsew')
        xs=ttk.Scrollbar(canvas_fr,orient='horizontal',command=self.viewer_canvas.xview); ys=ttk.Scrollbar(canvas_fr,orient='vertical',command=self.viewer_canvas.yview); xs.grid(row=1,column=0,sticky='ew'); ys.grid(row=0,column=1,sticky='ns')
        self.viewer_canvas.configure(xscrollcommand=xs.set,yscrollcommand=ys.set); canvas_fr.rowconfigure(0,weight=1); canvas_fr.columnconfigure(0,weight=1)

    def viewer_choose_file(self):
        p=filedialog.askopenfilename(title='Chọn file SPR',filetypes=[('JX Sprite','*.spr'),('All files','*.*')])
        if p: self.viewer_load(Path(p))

    def viewer_choose_extracted(self):
        base=Path(self.output_var.get().strip())/'extracted_character'
        p=filedialog.askopenfilename(title='Chọn SPR đã extract',initialdir=str(base) if base.exists() else None,filetypes=[('JX Sprite','*.spr'),('All files','*.*')])
        if p: self.viewer_load(Path(p))

    def viewer_load(self,path):
        try:
            self.viewer_stop_play()
            self.viewer_spr=parse_spr_file(Path(path)); self.viewer_path_var.set(str(path)); self.viewer_frame_var.set(0)
            self.viewer_decoded_cache={}; self.viewer_photo_cache={}
            self.viewer_spin.configure(to=max(0,self.viewer_spr['frames']-1)); self.viewer_render()
        except Exception as e: messagebox.showerror('SPR Viewer',f'Không đọc được SPR:\n{e}')

    def viewer_step(self,delta):
        if not self.viewer_spr:return
        self.viewer_frame_var.set((self.viewer_frame_var.get()+delta)%max(1,self.viewer_spr['frames']))
        self.viewer_render()

    def viewer_get_decoded(self,i):
        fr=self.viewer_decoded_cache.get(i)
        if fr is None:
            fr=decode_spr_frame(self.viewer_spr,i)
            self.viewer_decoded_cache[i]=fr
        return fr

    def viewer_get_photo(self,i):
        scale=max(1,int(self.viewer_scale_var.get()))
        key=(i,scale)
        img=self.viewer_photo_cache.get(key)
        if img is None:
            fr=self.viewer_get_decoded(i)
            img=frame_to_tk_photo(fr,scale)
            self.viewer_photo_cache[key]=img
        return img

    def viewer_render(self):
        if not self.viewer_spr:return
        try:
            i=max(0,min(self.viewer_spr['frames']-1,int(self.viewer_frame_var.get()))); self.viewer_frame_var.set(i)
            fr=self.viewer_get_decoded(i)
            self.viewer_photo=self.viewer_get_photo(i)
            self.viewer_canvas.delete('all'); self.viewer_canvas.create_image(10,10,image=self.viewer_photo,anchor='nw'); self.viewer_canvas.configure(scrollregion=(0,0,self.viewer_photo.width()+20,self.viewer_photo.height()+20))
            spr=self.viewer_spr
            prefix=(f" | SPR@+{spr.get('embedded_offset',0)}" if spr.get('embedded_offset',0) else "")
            scale=max(1,int(self.viewer_scale_var.get()))
            cached=sum(1 for k in self.viewer_photo_cache if k[1]==scale)
            self.viewer_info_var.set(f"{Path(spr['path']).name} | Canvas {spr['width']}×{spr['height']} | Frames {spr['frames']} | Directions {spr['directions']} | Interval {spr['interval']} ms | Colors {spr['colors']}{prefix}\nFrame {i}: {fr['width']}×{fr['height']} offset=({fr['offset_x']},{fr['offset_y']}) encoded={fr['encoded_bytes']} bytes | Cached {cached}/{spr['frames']}")
        except Exception as e:
            self.viewer_info_var.set(f'Frame decode error: {e}')

    def viewer_zoom_changed(self):
        self.viewer_stop_play()
        self.viewer_render()

    def viewer_speed_multiplier(self):
        try:return float(self.viewer_speed_var.get().lower().replace('x',''))
        except Exception:return 1.0

    def viewer_prepare_animation(self):
        if not self.viewer_spr:return False
        try:
            scale=max(1,int(self.viewer_scale_var.get()))
            missing=[i for i in range(self.viewer_spr['frames']) if (i,scale) not in self.viewer_photo_cache]
            if missing:
                for n,i in enumerate(missing,1):
                    self.viewer_get_photo(i)
                    self.viewer_info_var.set(f'Đang cache animation... {n}/{len(missing)} frame (zoom {scale}x)')
                    self.root.update_idletasks()
            return True
        except Exception as e:
            messagebox.showerror('SPR Viewer',f'Không thể chuẩn bị animation:\n{e}')
            return False

    def viewer_toggle_play(self):
        if self.viewer_playing:
            self.viewer_stop_play(); return
        if not self.viewer_spr:return
        if not self.viewer_prepare_animation():return
        self.viewer_playing=True; self.viewer_play_btn.configure(text='Stop')
        self.viewer_schedule_next(immediate=True)

    def viewer_stop_play(self):
        self.viewer_playing=False
        if hasattr(self,'viewer_play_btn'):self.viewer_play_btn.configure(text='Play')
        if self.viewer_after_id is not None:
            try:self.root.after_cancel(self.viewer_after_id)
            except Exception:pass
            self.viewer_after_id=None

    def viewer_schedule_next(self,immediate=False):
        if not self.viewer_playing or not self.viewer_spr:return
        base_ms=max(1,int(self.viewer_spr.get('interval',40) or 40))
        delay=1 if immediate else max(10,int(base_ms/max(0.01,self.viewer_speed_multiplier())))
        self.viewer_after_id=self.root.after(delay,self.viewer_tick)

    def viewer_tick(self):
        self.viewer_after_id=None
        if not self.viewer_playing or not self.viewer_spr:return
        self.viewer_frame_var.set((int(self.viewer_frame_var.get())+1)%max(1,self.viewer_spr['frames']))
        self.viewer_render(); self.viewer_schedule_next()

    def viewer_export_png(self):
        if not self.viewer_spr:
            messagebox.showwarning('SPR Viewer','Hãy mở một file SPR trước.'); return
        src=Path(self.viewer_spr['path'])
        parent=filedialog.askdirectory(title='Chọn thư mục chứa PNG frames',initialdir=str(src.parent))
        if not parent:return
        out=Path(parent)/(src.stem+'_frames')
        try:
            exported=export_spr_frames_png(self.viewer_spr,out)
            messagebox.showinfo('SPR Viewer',f'Đã xuất {len(exported)} PNG frame nền trong suốt.\n\n{out}\n\nCó thêm frames.json để giữ offset/timing.')
            try:os.startfile(out)
            except Exception:pass
        except Exception as e:
            messagebox.showerror('SPR Viewer',f'Export PNG thất bại:\n{e}')

    def _build_spr_builder(self,parent):
        self.builder_frames=[]
        self.builder_frame_offsets=[]  # per-frame user drag offsets (dx,dy)
        self.builder_drag_state=None
        self.builder_preview_spr=None
        self.builder_preview_photo=None
        self.builder_preview_cache={}
        self.builder_playing=False
        self.builder_after=None
        self.builder_frame=0
        self.builder_status=tk.StringVar(value='Import PNG để bắt đầu.')
        self.builder_interval=tk.IntVar(value=40)
        self.builder_directions=tk.IntVar(value=1)
        self.builder_center_x=tk.IntVar(value=0)
        self.builder_center_y=tk.IntVar(value=0)
        self.builder_colors=tk.IntVar(value=256)
        self.builder_alpha=tk.IntVar(value=1)
        self.builder_crop=tk.BooleanVar(value=True)
        self.builder_reference=None
        self.builder_ref_label=tk.StringVar(value='Reference: none')
        self.builder_transform_scale=tk.DoubleVar(value=100.0)
        self.builder_transform_rotation=tk.DoubleVar(value=0.0)
        self.builder_transform_x=tk.IntVar(value=0)
        self.builder_transform_y=tk.IntVar(value=0)
        self.builder_lock_canvas=tk.BooleanVar(value=True)
        self.builder_lock_offset=tk.BooleanVar(value=True)
        self.builder_flip_h=tk.BooleanVar(value=False)
        self.builder_flip_v=tk.BooleanVar(value=False)
        self.builder_zoom=tk.DoubleVar(value=4.0)
        self.builder_zoom_label=tk.StringVar(value='400%')
        self.builder_deploy_status=tk.StringVar(value='Deploy: no reference')
        self.builder_last_deploy=None
        self.builder_loop=tk.BooleanVar(value=True)
        self.builder_sheet_cols=tk.IntVar(value=5)
        self.builder_sheet_rows=tk.IntVar(value=3)
        self.builder_fps=tk.DoubleVar(value=25.0)
        self.builder_sheet_smart=tk.BooleanVar(value=True)
        self.builder_sheet_ref_resize=tk.BooleanVar(value=True)
        self.builder_ground_preview=tk.BooleanVar(value=True)
        self.builder_ground_anchor_x=tk.IntVar(value=72)
        self.builder_ground_anchor_y=tk.IntVar(value=78)
        self.builder_ground_ellipse_w=tk.IntVar(value=120)
        self.builder_ground_ellipse_h=tk.IntVar(value=52)
        self.builder_ground_show_body=tk.BooleanVar(value=True)

        top=ttk.Frame(parent); top.pack(fill='x',padx=10,pady=10)
        ttk.Label(top,text='SPR Builder Multi-Frame',style='Title.TLabel').grid(row=0,column=0,columnspan=10,sticky='w')
        ttk.Label(top,textvariable=self.builder_ref_label).grid(row=0,column=2,columnspan=8,sticky='e')
        ttk.Button(top,text='Add PNG',command=self.builder_add_png).grid(row=1,column=0,padx=(0,4),pady=(8,0))
        ttk.Button(top,text='Add Folder',command=self.builder_add_folder).grid(row=1,column=1,padx=4,pady=(8,0))
        ttk.Button(top,text='Import Sprite Sheet',command=self.builder_import_sheet).grid(row=1,column=2,padx=4,pady=(8,0))
        ttk.Button(top,text='Remove',command=self.builder_remove).grid(row=1,column=3,padx=4,pady=(8,0))
        ttk.Button(top,text='Clear',command=self.builder_clear).grid(row=1,column=4,padx=4,pady=(8,0))
        ttk.Button(top,text='Preview Build',command=self.builder_preview_build).grid(row=1,column=5,padx=(12,4),pady=(8,0))
        ttk.Button(top,text='BUILD SPR',command=self.builder_build).grid(row=1,column=6,padx=4,pady=(8,0))
        ttk.Button(top,text='BUILD + DEPLOY',command=self.builder_build_deploy).grid(row=1,column=7,padx=(12,4),pady=(8,0))
        ttk.Button(top,text='CLONE PAK + DEPLOY',command=self.builder_clone_pak_deploy).grid(row=1,column=8,padx=4,pady=(8,0))
        ttk.Button(top,text='RESTORE LAST',command=self.builder_restore_last).grid(row=1,column=9,padx=4,pady=(8,0))
        ttk.Label(top,textvariable=self.builder_deploy_status).grid(row=2,column=0,columnspan=10,sticky='w',pady=(6,0))

        body=ttk.Panedwindow(parent,orient='horizontal'); body.pack(fill='both',expand=True,padx=10,pady=(0,8))
        left=ttk.Frame(body); right=ttk.Frame(body); body.add(left,weight=2); body.add(right,weight=3)

        self.builder_list=tk.Listbox(left,selectmode='extended',font=('Consolas',9))
        self.builder_list.pack(fill='both',expand=True)
        self.builder_list.bind('<<ListboxSelect>>',lambda e:self.builder_select_list_frame())
        ttk.Label(left,text='Frame order = list order. Folder import sorts filenames naturally.',wraplength=330,justify='left').pack(fill='x',pady=4)
        tl=ttk.Frame(left); tl.pack(fill='x',pady=(2,4))
        ttk.Button(tl,text='↑ Move Up',command=lambda:self.builder_move_frame(-1)).pack(side='left')
        ttk.Button(tl,text='↓ Move Down',command=lambda:self.builder_move_frame(1)).pack(side='left',padx=3)
        ttk.Button(tl,text='Duplicate',command=self.builder_duplicate_frame).pack(side='left',padx=3)
        ttk.Button(tl,text='Delete',command=self.builder_remove).pack(side='left')

        opts=ttk.LabelFrame(left,text='SPR Settings'); opts.pack(fill='x',pady=(6,0))
        def row(label,var,r,frm=1,to=9999):
            ttk.Label(opts,text=label).grid(row=r,column=0,sticky='w',padx=6,pady=3)
            ttk.Spinbox(opts,textvariable=var,from_=frm,to=to,width=9).grid(row=r,column=1,sticky='w',padx=4,pady=3)
        row('Interval (ms)',self.builder_interval,0,1,5000)
        row('FPS',self.builder_fps,1,1,120)
        row('Directions',self.builder_directions,2,1,32)
        row('Center X',self.builder_center_x,3,-32768,32767)
        row('Center Y',self.builder_center_y,4,-32768,32767)
        row('Palette colors',self.builder_colors,5,2,256)
        row('Alpha threshold',self.builder_alpha,6,0,255)
        ttk.Checkbutton(opts,text='Auto crop transparent border',variable=self.builder_crop).grid(row=7,column=0,columnspan=2,sticky='w',padx=6,pady=4)
        ttk.Separator(opts,orient='horizontal').grid(row=8,column=0,columnspan=2,sticky='ew',padx=4,pady=4)
        ttk.Label(opts,text='Reference Transform',font=('Segoe UI',9,'bold')).grid(row=9,column=0,columnspan=2,sticky='w',padx=6)
        row('Scale %',self.builder_transform_scale,10,1,1000)
        row('Rotation °',self.builder_transform_rotation,11,-360,360)
        row('Position X',self.builder_transform_x,12,-4096,4096)
        row('Position Y',self.builder_transform_y,13,-4096,4096)
        ttk.Checkbutton(opts,text='Lock reference canvas',variable=self.builder_lock_canvas).grid(row=14,column=0,columnspan=2,sticky='w',padx=6)
        ttk.Checkbutton(opts,text='Lock reference offset',variable=self.builder_lock_offset).grid(row=15,column=0,columnspan=2,sticky='w',padx=6)
        af=ttk.Frame(opts); af.grid(row=16,column=0,columnspan=2,sticky='w',padx=4,pady=5)
        ttk.Button(af,text='Auto Fit',command=self.builder_auto_fit).pack(side='left')
        ttk.Button(af,text='Fit Height',command=lambda:self.builder_fit_mode('height')).pack(side='left',padx=3)
        ttk.Button(af,text='Fit Width',command=lambda:self.builder_fit_mode('width')).pack(side='left')
        ff=ttk.Frame(opts); ff.grid(row=17,column=0,columnspan=2,sticky='w',padx=4,pady=(0,5))
        ss=ttk.LabelFrame(opts,text='Sprite Sheet')
        ss.grid(row=18,column=0,columnspan=2,sticky='ew',padx=4,pady=(4,6))
        ttk.Label(ss,text='Columns').grid(row=0,column=0,padx=4,pady=3)
        ttk.Spinbox(ss,textvariable=self.builder_sheet_cols,from_=1,to=64,width=5).grid(row=0,column=1,padx=3)
        ttk.Label(ss,text='Rows').grid(row=0,column=2,padx=4,pady=3)
        ttk.Spinbox(ss,textvariable=self.builder_sheet_rows,from_=1,to=64,width=5).grid(row=0,column=3,padx=3)
        ttk.Checkbutton(ss,text='Smart Split',variable=self.builder_sheet_smart).grid(row=1,column=0,columnspan=2,sticky='w',padx=4,pady=3)
        ttk.Checkbutton(ss,text='Resize to Reference',variable=self.builder_sheet_ref_resize).grid(row=1,column=2,columnspan=2,sticky='w',padx=4,pady=3)
        gp=ttk.LabelFrame(opts,text='Ground Aura Perspective Preview')
        gp.grid(row=19,column=0,columnspan=2,sticky='ew',padx=4,pady=(4,8))
        ttk.Checkbutton(gp,text='Enable Ground Preview (Anchor Guide)',variable=self.builder_ground_preview,command=self.builder_preview_render_safe).grid(row=0,column=0,columnspan=4,sticky='w',padx=4,pady=3)
        ttk.Checkbutton(gp,text='Show Player Guide',variable=self.builder_ground_show_body,command=self.builder_preview_render_safe).grid(row=1,column=0,columnspan=4,sticky='w',padx=4,pady=3)
        ttk.Label(gp,text='Anchor X').grid(row=2,column=0,padx=4,pady=2)
        ttk.Spinbox(gp,textvariable=self.builder_ground_anchor_x,from_=0,to=4096,width=6,command=self.builder_preview_render_safe).grid(row=2,column=1,padx=3,pady=2)
        ttk.Label(gp,text='Anchor Y').grid(row=2,column=2,padx=4,pady=2)
        ttk.Spinbox(gp,textvariable=self.builder_ground_anchor_y,from_=0,to=4096,width=6,command=self.builder_preview_render_safe).grid(row=2,column=3,padx=3,pady=2)
        ttk.Label(gp,text='Ellipse W').grid(row=3,column=0,padx=4,pady=2)
        ttk.Spinbox(gp,textvariable=self.builder_ground_ellipse_w,from_=1,to=4096,width=6,command=self.builder_preview_render_safe).grid(row=3,column=1,padx=3,pady=2)
        ttk.Label(gp,text='Ellipse H').grid(row=3,column=2,padx=4,pady=2)
        ttk.Spinbox(gp,textvariable=self.builder_ground_ellipse_h,from_=1,to=4096,width=6,command=self.builder_preview_render_safe).grid(row=3,column=3,padx=3,pady=2)
        ttk.Button(gp,text='Use Reference Center',command=self.builder_ground_from_reference).grid(row=4,column=0,columnspan=2,sticky='ew',padx=4,pady=4)
        ttk.Button(gp,text='Aura Preset 2.3:1',command=self.builder_ground_aura_preset).grid(row=4,column=2,columnspan=2,sticky='ew',padx=4,pady=4)
        ttk.Checkbutton(ff,text='Flip H',variable=self.builder_flip_h,command=self.builder_preview_build_if_ready).pack(side='left')
        ttk.Checkbutton(ff,text='Flip V',variable=self.builder_flip_v,command=self.builder_preview_build_if_ready).pack(side='left',padx=5)
        ttk.Button(ff,text='Match Orientation',command=self.builder_match_orientation).pack(side='left')

        ttk.Label(right,text='Build Preview',font=('Segoe UI',12,'bold')).pack(anchor='w')
        ctr=ttk.Frame(right); ctr.pack(fill='x',pady=4)
        ttk.Button(ctr,text='◀',width=3,command=lambda:self.builder_preview_step(-1)).pack(side='left')
        ttk.Button(ctr,text='▶',width=3,command=lambda:self.builder_preview_step(1)).pack(side='left',padx=(4,0))
        self.builder_play_btn=ttk.Button(ctr,text='Play',width=7,command=self.builder_preview_toggle); self.builder_play_btn.pack(side='left',padx=8)
        ttk.Separator(ctr,orient='vertical').pack(side='left',fill='y',padx=5)
        ttk.Button(ctr,text='−',width=3,command=self.builder_zoom_out).pack(side='left')
        ttk.Button(ctr,text='+',width=3,command=self.builder_zoom_in).pack(side='left',padx=(3,0))
        ttk.Button(ctr,text='Fit',width=4,command=self.builder_zoom_fit).pack(side='left',padx=(6,0))
        ttk.Button(ctr,text='1:1',width=4,command=self.builder_zoom_1to1).pack(side='left',padx=(3,0))
        ttk.Label(ctr,textvariable=self.builder_zoom_label,width=7,anchor='center').pack(side='left',padx=(4,8))
        ttk.Checkbutton(ctr,text='Loop',variable=self.builder_loop).pack(side='left',padx=(3,8))
        self.builder_frame_var=tk.IntVar(value=0)
        ttk.Label(ctr,text='Frame:').pack(side='left')
        self.builder_spin=ttk.Spinbox(ctr,from_=0,to=0,width=6,textvariable=self.builder_frame_var,command=self.builder_preview_render)
        self.builder_spin.pack(side='left',padx=4)
        self.builder_frame_var.trace_add('write',lambda *_:self.builder_preview_render_safe())
        self.builder_offset_label=tk.StringVar(value='Offset: X=0 Y=0')
        ttk.Label(ctr,textvariable=self.builder_offset_label).pack(side='left',padx=(8,4))
        ttk.Button(ctr,text='Reset Offset',command=self.builder_reset_frame_offset).pack(side='left',padx=3)
        ttk.Button(ctr,text='Apply Offset to All',command=self.builder_apply_current_offset_to_all).pack(side='left',padx=3)
        ttk.Button(ctr,text='Align to Original SPR',command=self.builder_align_to_original_spr).pack(side='left',padx=3)

        cw=ttk.Frame(right); cw.pack(fill='both',expand=True)
        self.builder_canvas=tk.Canvas(cw,bg=self.ui['canvas'],highlightthickness=0)
        self.builder_canvas.grid(row=0,column=0,sticky='nsew')
        sy=ttk.Scrollbar(cw,orient='vertical',command=self.builder_canvas.yview); sy.grid(row=0,column=1,sticky='ns')
        sx=ttk.Scrollbar(cw,orient='horizontal',command=self.builder_canvas.xview); sx.grid(row=1,column=0,sticky='ew')
        self.builder_canvas.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        self.builder_canvas.bind('<ButtonPress-1>',self.builder_drag_start)
        self.builder_canvas.bind('<B1-Motion>',self.builder_drag_motion)
        self.builder_canvas.bind('<ButtonRelease-1>',self.builder_drag_end)
        self.builder_canvas.bind('<Left>',lambda e:self.builder_nudge_frame(-1,0))
        self.builder_canvas.bind('<Right>',lambda e:self.builder_nudge_frame(1,0))
        self.builder_canvas.bind('<Up>',lambda e:self.builder_nudge_frame(0,-1))
        self.builder_canvas.bind('<Down>',lambda e:self.builder_nudge_frame(0,1))
        self.builder_canvas.bind('<Shift-Left>',lambda e:self.builder_nudge_frame(-5,0))
        self.builder_canvas.bind('<Shift-Right>',lambda e:self.builder_nudge_frame(5,0))
        self.builder_canvas.bind('<Shift-Up>',lambda e:self.builder_nudge_frame(0,-5))
        self.builder_canvas.bind('<Shift-Down>',lambda e:self.builder_nudge_frame(0,5))
        cw.rowconfigure(0,weight=1); cw.columnconfigure(0,weight=1)
        ttk.Label(right,textvariable=self.builder_status,justify='left',wraplength=620).pack(fill='x',pady=6)


    def builder_select_list_frame(self):
        inds=list(self.builder_list.curselection())
        if len(inds)==1 and self.builder_preview_spr:
            self.builder_frame_var.set(inds[0])


    def builder_sync_frame_offsets(self):
        """Keep per-frame offset storage exactly aligned with builder_frames.

        This helper is intentionally side-effect free for the UI. It is used by
        drag/apply-all/build paths that need valid offset entries without
        rebuilding the frame list or changing status text.
        """
        while len(self.builder_frame_offsets) < len(self.builder_frames):
            self.builder_frame_offsets.append((0, 0))
        if len(self.builder_frame_offsets) > len(self.builder_frames):
            self.builder_frame_offsets = self.builder_frame_offsets[:len(self.builder_frames)]

    def builder_refresh(self):
        self.builder_sync_frame_offsets()
        self.builder_list.delete(0,'end')
        for i,p in enumerate(self.builder_frames):
            self.builder_list.insert('end',f'{i:04d}  {Path(p).name}')
        self.builder_status.set(f'{len(self.builder_frames)} PNG frame(s).')


    def builder_sync_fps_from_interval(self):
        try:
            iv=max(1,float(self.builder_interval.get()))
            self.builder_fps.set(round(1000.0/iv,3))
        except Exception:
            pass

    def builder_sync_interval_from_fps(self):
        try:
            fps=max(.1,float(self.builder_fps.get()))
            self.builder_interval.set(max(1,int(round(1000.0/fps))))
        except Exception:
            pass

    def builder_move_frame(self,d):
        inds=list(self.builder_list.curselection())
        if len(inds)!=1:return
        i=inds[0]; j=i+d
        if j<0 or j>=len(self.builder_frames):return
        self.builder_frames[i],self.builder_frames[j]=self.builder_frames[j],self.builder_frames[i]
        self.builder_frame_offsets[i],self.builder_frame_offsets[j]=self.builder_frame_offsets[j],self.builder_frame_offsets[i]
        self.builder_refresh()
        self.builder_list.selection_set(j); self.builder_list.see(j)

    def builder_duplicate_frame(self):
        inds=list(self.builder_list.curselection())
        if len(inds)!=1:return
        i=inds[0]
        self.builder_frames.insert(i+1,self.builder_frames[i])
        self.builder_frame_offsets.insert(i+1,self.builder_frame_offsets[i] if i<len(self.builder_frame_offsets) else (0,0))
        self.builder_refresh()
        self.builder_list.selection_set(i+1); self.builder_list.see(i+1)

    def builder_resize_rgba_nn(self,rgba,sw,sh,dw,dh):
        if sw==dw and sh==dh:
            return list(rgba)
        out=[]
        for y in range(dh):
            sy=min(sh-1,int(y*sh/max(1,dh)))
            for x in range(dw):
                sx=min(sw-1,int(x*sw/max(1,dw)))
                out.append(rgba[sy*sw+sx])
        return out

    def builder_import_sheet(self):
        f=filedialog.askopenfilename(title='Chọn Sprite Sheet PNG',filetypes=[('PNG','*.png')])
        if not f:return
        try:
            im=png_read_rgba(Path(f))
            cols=max(1,int(self.builder_sheet_cols.get()))
            rows=max(1,int(self.builder_sheet_rows.get()))
            total=cols*rows

            # Reference frame count is authoritative when available.
            if self.builder_reference and self.builder_reference.get('frames'):
                ref_frames=int(self.builder_reference['frames'])
                if total!=ref_frames:
                    raise ValueError(
                        f"Grid {cols}×{rows} = {total} frame nhưng Reference yêu cầu {ref_frames} frame."
                    )

            exact=(im['width']%cols==0 and im['height']%rows==0)
            if not exact and not self.builder_sheet_smart.get():
                raise ValueError(
                    f"Sprite sheet {im['width']}×{im['height']} không chia hết cho {cols}×{rows}. "
                    "Bật Smart Split để cắt theo tỷ lệ."
                )

            outdir=self.builder_deploy_output_dir()/'sheet_import'/Path(f).stem
            outdir.mkdir(parents=True,exist_ok=True)
            made=[]
            report=[]

            # Smart split uses proportional integer boundaries:
            # x0=floor(c*W/cols), x1=floor((c+1)*W/cols)
            # y0=floor(r*H/rows), y1=floor((r+1)*H/rows)
            # This guarantees full coverage even when dimensions are not divisible.
            for r in range(rows):
                y0=(r*im['height'])//rows
                y1=((r+1)*im['height'])//rows
                for c in range(cols):
                    x0=(c*im['width'])//cols
                    x1=((c+1)*im['width'])//cols
                    fw=max(1,x1-x0)
                    fh=max(1,y1-y0)

                    rgba=[]
                    for y in range(y0,y1):
                        start=y*im['width']+x0
                        rgba.extend(im['rgba'][start:start+fw])

                    ow,oh=fw,fh
                    if self.builder_reference and self.builder_sheet_ref_resize.get():
                        tw=int(self.builder_reference['canvas_w'])
                        th=int(self.builder_reference['canvas_h'])
                        rgba=self.builder_resize_rgba_nn(rgba,fw,fh,tw,th)
                        ow,oh=tw,th

                    idx=r*cols+c
                    p=outdir/f"frame_{idx:04d}.png"
                    png_write_rgba(p,ow,oh,rgba)
                    made.append(str(p))
                    report.append((idx,x0,y0,x1,y1,fw,fh,ow,oh))

            self.builder_frames.extend(made)
            self.builder_refresh()

            mode='Smart proportional split' if not exact else 'Exact grid split'
            resize_txt=''
            if self.builder_reference and self.builder_sheet_ref_resize.get():
                resize_txt=f" → normalized to {self.builder_reference['canvas_w']}×{self.builder_reference['canvas_h']}"

            self.builder_status.set(
                f'Import Sprite Sheet PASS | {mode} | Source={im["width"]}×{im["height"]} | '
                f'Grid={cols}×{rows} = {len(made)} frames{resize_txt} | '
                f'Order: trái→phải, rồi trên→dưới.'
            )

            # Save split report for debugging/reproducibility.
            rpt=outdir/'SHEET_SPLIT_REPORT.txt'
            lines=[
                'JX Client Scanner V4.6.8 Smart Sprite Sheet Import',
                f'Source={f}',
                f'SourceSize={im["width"]}x{im["height"]}',
                f'Grid={cols}x{rows}',
                f'Mode={mode}',
                f'ResizeToReference={bool(self.builder_reference and self.builder_sheet_ref_resize.get())}',
                ''
            ]
            for idx,x0,y0,x1,y1,fw,fh,ow,oh in report:
                lines.append(
                    f'Frame {idx:04d}: src=({x0},{y0})-({x1},{y1}) '
                    f'{fw}x{fh} -> {ow}x{oh}'
                )
            write_text_safe(rpt,'\n'.join(lines))

        except Exception as e:
            messagebox.showerror('Import Sprite Sheet',str(e))


    def builder_add_png(self):
        files=filedialog.askopenfilenames(title='Chọn PNG frame(s)',filetypes=[('PNG','*.png')])
        if files:self.builder_frames.extend(files); self.builder_refresh()

    def builder_add_folder(self):
        d=filedialog.askdirectory(title='Chọn folder PNG frames')
        if not d:return
        def natkey(p): return [int(x) if x.isdigit() else x.lower() for x in re.split(r'(\d+)',Path(p).name)]
        files=sorted([str(p) for p in Path(d).glob('*.png')],key=natkey)
        self.builder_frames.extend(files); self.builder_refresh()

    def builder_remove(self):
        inds=list(self.builder_list.curselection())
        for i in reversed(inds):
            del self.builder_frames[i]
            if i<len(self.builder_frame_offsets): del self.builder_frame_offsets[i]
        self.builder_refresh()

    def builder_clear(self):
        self.builder_preview_stop(); self.builder_frames=[]; self.builder_frame_offsets=[]; self.builder_preview_spr=None
        self.builder_canvas.delete('all'); self.builder_refresh()

    def rs_build_replacement(self):
        try:
            # Reuse the exact selected row + direct-PAK read path already used by Live Preview.
            r=self.rs_selected()
            if not r: raise ValueError('Hãy chọn một SPR trong Resource Studio.')
            pak,entry=self.rs_entry(r)
            data,detail=native_read_xpack_entry_bytes(pak,entry)
            vpath=r.get('virtual_path','reference.spr')
            spr=parse_spr_bytes(data,f"PAK://{r.get('pak_name')}#{r.get('elem_index')}::{vpath}")
            fr0=decode_spr_frame(spr,0)
            self.builder_reference={
                'row':r,'spr':spr,'virtual_path':vpath,
                'canvas_w':spr['width'],'canvas_h':spr['height'],
                'frames':spr['frames'],'directions':spr['directions'],
                'colors':spr['colors'],'interval':spr['interval'],
                'offset_x':fr0['offset_x'],'offset_y':fr0['offset_y']
            }
            self.builder_ref_label.set(
                f"Reference: {Path(vpath).name} | {spr['width']}×{spr['height']} | "
                f"F={spr['frames']} D={spr['directions']} Off={fr0['offset_x']},{fr0['offset_y']}")
            self.builder_interval.set(max(1,spr['interval'] or 40))
            self.builder_sync_fps_from_interval()
            self.builder_directions.set(max(1,spr['directions']))
            self.builder_colors.set(min(256,max(2,spr['colors'] or 256)))
            # Tiny game sprites need magnification in the builder; this affects preview only.
            target_zoom=min(16.0,max(1.0,min(320.0/max(1,spr['width']),420.0/max(1,spr['height']))))
            self.builder_zoom.set(target_zoom)
            self.builder_zoom_label.set(f'{int(round(target_zoom*100))}%')
            self.builder_ground_anchor_x.set(int(spr['width']//2))
            self.builder_ground_anchor_y.set(int(round(spr['height']*0.61)))
            ew=max(8,int(round(spr['width']*0.83)))
            self.builder_ground_ellipse_w.set(ew)
            self.builder_ground_ellipse_h.set(max(6,int(round(ew/2.3))))
            self.notebook.select(self.builder_tab)
            self.builder_status.set(
                f"Reference loaded từ {r.get('pak_name')} entry={r.get('elem_index')}. "
                "Add PNG → Auto Fit → Preview Build.")
            try:
                loose=self.builder_reference_loose_path()
                exists=loose.exists()
                self.builder_deploy_status.set(
                    f"Deploy target: {loose} | PAK={r.get('pak_name')} | Loose={'FOUND' if exists else 'NOT FOUND'}")
            except Exception:
                self.builder_deploy_status.set('Deploy target: unresolved')
        except Exception as e:
            messagebox.showerror('Build Replacement',f'Không load được Reference SPR:\n{e}')


    def builder_transform_image(self,im):
        ref=self.builder_reference
        if not ref:return im
        # v4.6.8 FIX: when Lock reference canvas is enabled, preserve the full
        # per-frame source canvas instead of cropping each frame independently.
        # Independent crop+recenter changes the apparent origin whenever wisps/
        # particles alter the alpha bounds, which makes animation frames drift
        # even if every user offset is numerically identical.
        if self.builder_lock_canvas.get():
            base=dict(im)
            base.setdefault('crop_x',0); base.setdefault('crop_y',0)
            base.setdefault('src_width',im['width']); base.setdefault('src_height',im['height'])
        else:
            base=crop_rgba(im,self.builder_alpha.get())
        w,h=base['width'],base['height']; px=base['rgba']
        scale=max(.001,float(self.builder_transform_scale.get())/100.0)
        nw=max(1,int(round(w*scale))); nh=max(1,int(round(h*scale)))
        scaled=[px[min(h-1,int(y/scale))*w+min(w-1,int(x/scale))] for y in range(nh) for x in range(nw)]
        if self.builder_flip_h.get():
            scaled=[scaled[y*nw+(nw-1-x)] for y in range(nh) for x in range(nw)]
        if self.builder_flip_v.get():
            scaled=[scaled[(nh-1-y)*nw+x] for y in range(nh) for x in range(nw)]
        ang=math.radians(float(self.builder_transform_rotation.get())); ca,sa=math.cos(ang),math.sin(ang)
        rw=max(1,int(math.ceil(abs(nw*ca)+abs(nh*sa)))); rh=max(1,int(math.ceil(abs(nw*sa)+abs(nh*ca))))
        rot=[(0,0,0,0)]*(rw*rh); cx=(nw-1)/2; cy=(nh-1)/2; rcx=(rw-1)/2; rcy=(rh-1)/2
        for y in range(rh):
            for x in range(rw):
                dx=x-rcx; dy=y-rcy; sx=ca*dx+sa*dy+cx; sy=-sa*dx+ca*dy+cy
                ix=int(round(sx)); iy=int(round(sy))
                if 0<=ix<nw and 0<=iy<nh: rot[y*rw+x]=scaled[iy*nw+ix]
        cw,ch=int(ref['canvas_w']),int(ref['canvas_h']); canvas=[(0,0,0,0)]*(cw*ch)
        x0=(cw-rw)//2+int(self.builder_transform_x.get()); y0=(ch-rh)//2+int(self.builder_transform_y.get())
        for y in range(rh):
            yy=y0+y
            if 0<=yy<ch:
                for x in range(rw):
                    xx=x0+x
                    if 0<=xx<cw and rot[y*rw+x][3]: canvas[yy*cw+xx]=rot[y*rw+x]
        return {'width':cw,'height':ch,'rgba':canvas,'path':im.get('path'),'crop_x':0,'crop_y':0,'src_width':cw,'src_height':ch}


    def builder_preview_build_if_ready(self):
        if self.builder_reference and self.builder_frames:
            self.builder_preview_build()

    def builder_zoom_set(self,z):
        z=max(0.25,min(32.0,float(z)))
        self.builder_zoom.set(z)
        self.builder_zoom_label.set(f'{int(round(z*100))}%')
        # image cache is zoom-dependent
        self.builder_preview_cache={}
        self.builder_preview_render()

    def builder_zoom_in(self):
        self.builder_zoom_set(self.builder_zoom.get()*1.5)

    def builder_zoom_out(self):
        self.builder_zoom_set(self.builder_zoom.get()/1.5)

    def builder_zoom_1to1(self):
        self.builder_zoom_set(1.0)

    def builder_zoom_fit(self):
        s=self.builder_preview_spr
        if not s:return
        c=self.builder_canvas
        aw=max(40,c.winfo_width()-40); ah=max(40,c.winfo_height()-40)
        if s['width']<=0 or s['height']<=0:return
        self.builder_zoom_set(max(.25,min(32.0,min(aw/s['width'],ah/s['height']))))

    def builder_reference_mask_score(self,candidate):
        """Compare alpha silhouettes on the locked reference canvas."""
        if not self.builder_reference:return -1
        try:
            ref_fr=decode_spr_frame(self.builder_reference['spr'],0)
            rw,rh=self.builder_reference['canvas_w'],self.builder_reference['canvas_h']
            # ref decoded frame may be cropped; place using its frame offset.
            refmask=[0]*(rw*rh)
            fw,fh=ref_fr['width'],ref_fr['height']
            ox,oy=ref_fr['offset_x'],ref_fr['offset_y']
            rgba=ref_fr['rgba']
            for y in range(fh):
                yy=y+oy
                if 0<=yy<rh:
                    for x in range(fw):
                        xx=x+ox
                        if 0<=xx<rw and rgba[y*fw+x][3]>=self.builder_alpha.get():
                            refmask[yy*rw+xx]=1
            cmask=[1 if p[3]>=self.builder_alpha.get() else 0 for p in candidate['rgba']]
            inter=sum(1 for a,b in zip(refmask,cmask) if a and b)
            union=sum(1 for a,b in zip(refmask,cmask) if a or b)
            if union==0:return 0
            return inter/union
        except Exception:
            return -1

    def builder_match_orientation(self):
        if not self.builder_reference or not self.builder_frames:
            messagebox.showwarning('Match Orientation','Cần Reference SPR và ít nhất 1 PNG.'); return
        try:
            # Preserve position; Auto Fit scale first if source is still large.
            im=png_read_rgba(Path(self.builder_frames[0]))
            base=crop_rgba(im,self.builder_alpha.get())
            rw,rh=self.builder_reference['canvas_w'],self.builder_reference['canvas_h']
            best=None
            old=(self.builder_transform_rotation.get(),self.builder_flip_h.get(),self.builder_flip_v.get(),
                 self.builder_transform_scale.get())
            # Try cardinal rotations + H/V flips. Refit scale for each orientation.
            for rot in (0,90,180,270):
                for fh in (False,True):
                    for fv in (False,True):
                        self.builder_transform_rotation.set(rot)
                        self.builder_flip_h.set(fh); self.builder_flip_v.set(fv)
                        # Fit based on rotated bounds.
                        if rot in (90,270):
                            sw,sh=base['height'],base['width']
                        else:
                            sw,sh=base['width'],base['height']
                        sc=min(rw/max(1,sw),rh/max(1,sh))*100.0
                        self.builder_transform_scale.set(sc)
                        cand=self.builder_transform_image(im)
                        score=self.builder_reference_mask_score(cand)
                        if best is None or score>best[0]:
                            best=(score,rot,fh,fv,sc)
            if best:
                score,rot,fh,fv,sc=best
                self.builder_transform_rotation.set(rot)
                self.builder_flip_h.set(fh); self.builder_flip_v.set(fv)
                self.builder_transform_scale.set(round(sc,3))
                self.builder_transform_x.set(0); self.builder_transform_y.set(0)
                self.builder_status.set(
                    f'Match Orientation: rotation={rot}°, FlipH={fh}, FlipV={fv}, '
                    f'scale={sc:.3f}%, silhouette score={score:.3f}')
                self.builder_preview_build()
            else:
                self.builder_transform_rotation.set(old[0]); self.builder_flip_h.set(old[1])
                self.builder_flip_v.set(old[2]); self.builder_transform_scale.set(old[3])
        except Exception as e:
            messagebox.showerror('Match Orientation',str(e))


    def builder_fit_mode(self,mode='auto'):
        if not self.builder_reference or not self.builder_frames:
            messagebox.showwarning('Reference Fit','Cần Build Replacement từ Resource Studio và Add PNG trước.'); return
        try:
            base=crop_rgba(png_read_rgba(Path(self.builder_frames[0])),self.builder_alpha.get())
            rw,rh=self.builder_reference['canvas_w'],self.builder_reference['canvas_h']
            s=rw/base['width'] if mode=='width' else rh/base['height'] if mode=='height' else min(rw/base['width'],rh/base['height'])
            self.builder_transform_scale.set(round(s*100,3)); self.builder_transform_x.set(0); self.builder_transform_y.set(0)
            self.builder_preview_build()
        except Exception as e: messagebox.showerror('Reference Fit',str(e))

    def builder_auto_fit(self): self.builder_fit_mode('auto')

    def builder_build_reference_spr(self,paths,output_path):
        """Build locked-reference SPR with per-frame drag applied to PIXELS, not SPR header offsets.

        v4.7.1 FIX:
        JX frame offsets are stored as unsigned 16-bit fields in this tool.  A user drag such
        as X=-2 was previously encoded as 65534, so the decoded preview placed the whole frame
        far outside the 145x128 canvas and the effect appeared to vanish.

        For a locked reference canvas, the correct editing model is to move the RGBA artwork
        inside the fixed canvas and leave the SPR frame origin/offset at the reference value.
        This also makes negative drag values safe and keeps Preview == final BUILD SPR.
        """
        ref=self.builder_reference
        self.builder_sync_frame_offsets()
        base_ims=[self.builder_transform_image(png_read_rgba(Path(p))) for p in paths]
        if len(base_ims)!=ref['frames']:
            raise ValueError(f"Reference yêu cầu {ref['frames']} frame, hiện có {len(base_ims)} PNG.")

        def shift_pixels(im,dx,dy):
            w,h=int(im['width']),int(im['height'])
            src=im['rgba']; dst=[(0,0,0,0)]*(w*h)
            dx=int(dx); dy=int(dy)
            # Destination coordinate = source + user drag. Pixels outside fixed canvas are clipped.
            for sy in range(h):
                ty=sy+dy
                if ty<0 or ty>=h:
                    continue
                sx0=max(0,-dx); sx1=min(w,w-dx)
                if sx1<=sx0:
                    continue
                for sx in range(sx0,sx1):
                    tx=sx+dx
                    p=src[sy*w+sx]
                    if p[3]:
                        dst[ty*w+tx]=p
            return {'width':w,'height':h,'rgba':dst,'path':im.get('path'),
                    'crop_x':0,'crop_y':0,'src_width':w,'src_height':h}

        ims=[]
        for i,im in enumerate(base_ims):
            dx,dy=self.builder_frame_offsets[i] if i<len(self.builder_frame_offsets) else (0,0)
            ims.append(shift_pixels(im,dx,dy))

        palette=median_cut_palette(ims,min(256,max(2,self.builder_colors.get())),self.builder_alpha.get())
        frames=[]; meta=[]
        base_ox=int(ref['offset_x']) if self.builder_lock_offset.get() else 0
        base_oy=int(ref['offset_y']) if self.builder_lock_offset.get() else 0
        for i,im in enumerate(ims):
            # IMPORTANT: per-frame user drag is already baked into im['rgba']; never add it here.
            ox,oy=base_ox,base_oy
            b=encode_jx_rle_frame(im,palette,self.builder_alpha.get(),ox,oy); frames.append(b)
            dx,dy=self.builder_frame_offsets[i] if i<len(self.builder_frame_offsets) else (0,0)
            meta.append({'source':str(paths[i]),'width':im['width'],'height':im['height'],
                         'offset_x':ox,'offset_y':oy,'user_shift_x':int(dx),'user_shift_y':int(dy),'length':len(b)})
        cw,ch=ref['canvas_w'],ref['canvas_h']; dirs=ref['directions']; interval=max(1,ref['interval'] or self.builder_interval.get())
        header=SPR_HEADER.pack(b'SPR\x00',cw,ch,0,0,len(frames),len(palette),dirs,interval,0,0,0,0,0,0)
        pal=b''.join(bytes(c) for c in palette); off=0; offs=[]
        for fr in frames: offs.append(SPR_OFFS.pack(off,len(fr))); off+=len(fr)
        data=header+pal+b''.join(offs)+b''.join(frames); Path(output_path).write_bytes(data)
        parsed=parse_spr_bytes(data,output_path)
        for i in range(parsed['frames']): decode_spr_frame(parsed,i)
        return {'path':Path(output_path),'size':len(data),'frames':len(frames),'colors':len(palette),'width':cw,'height':ch,'directions':dirs,'interval':interval,'frame_meta':meta}


    def builder_make_temp(self):
        if not self.builder_frames: raise ValueError('Chưa có PNG frame')
        self.builder_sync_interval_from_fps()
        tmp=self.rs_output()/'_builder_preview.spr'
        tmp.parent.mkdir(parents=True,exist_ok=True)
        if self.builder_reference:
            meta=self.builder_build_reference_spr(self.builder_frames,tmp)
        else:
            meta=build_jx_spr_from_pngs(
                self.builder_frames,tmp,
                interval=self.builder_interval.get(),directions=self.builder_directions.get(),
                center_x=self.builder_center_x.get(),center_y=self.builder_center_y.get(),
                auto_crop=self.builder_crop.get(),alpha_threshold=self.builder_alpha.get(),
                max_colors=self.builder_colors.get(),frame_offsets=self.builder_frame_offsets)
        return tmp,meta

    def builder_preview_build(self):
        try:
            self.builder_preview_stop()
            tmp,meta=self.builder_make_temp()
            self.builder_preview_spr=parse_spr_file(tmp)
            self.builder_preview_cache={}; self.builder_frame=0; self.builder_frame_var.set(0)
            self.builder_spin.configure(to=max(0,self.builder_preview_spr['frames']-1))
            self.builder_preview_render()
            self.builder_status.set(
                f"Preview PASS | {meta['width']}×{meta['height']} | Frames={meta['frames']} | "
                f"Directions={meta['directions']} | Colors={meta['colors']} | Size={meta['size']} bytes")
        except Exception as e:
            messagebox.showerror('SPR Builder',f'Preview build thất bại:\n{e}')

    def builder_preview_render_safe(self):
        try:self.builder_preview_render()
        except Exception:pass


    def builder_ground_from_reference(self):
        s=self.builder_preview_spr or (self.builder_reference.get('spr') if self.builder_reference else None)
        if not s:return
        self.builder_ground_anchor_x.set(int(s['width']//2))
        self.builder_ground_anchor_y.set(int(round(s['height']*0.61)))
        self.builder_ground_ellipse_w.set(max(8,int(round(s['width']*0.83))))
        self.builder_ground_ellipse_h.set(max(6,int(round(self.builder_ground_ellipse_w.get()/2.3))))
        self.builder_preview_render_safe()

    def builder_ground_aura_preset(self):
        s=self.builder_preview_spr or (self.builder_reference.get('spr') if self.builder_reference else None)
        if s:
            w=int(s['width']); h=int(s['height'])
            self.builder_ground_anchor_x.set(w//2)
            self.builder_ground_anchor_y.set(int(round(h*0.61)))
            ew=max(8,int(round(w*0.83)))
            self.builder_ground_ellipse_w.set(ew)
            self.builder_ground_ellipse_h.set(max(6,int(round(ew/2.3))))
        self.builder_ground_preview.set(True)
        self.builder_ground_show_body.set(True)
        self.builder_preview_render_safe()

    def builder_draw_ground_overlay(self,c,x,y,z,s):
        if not self.builder_ground_preview.get(): return
        try:
            ax=float(self.builder_ground_anchor_x.get())*z
            ay=float(self.builder_ground_anchor_y.get())*z
            ew=max(1,float(self.builder_ground_ellipse_w.get())*z)
            eh=max(1,float(self.builder_ground_ellipse_h.get())*z)
        except Exception:
            return
        cx=x+ax; cy=y+ay
        # Ground ellipse + center crosshair.
        c.create_oval(cx-ew/2,cy-eh/2,cx+ew/2,cy+eh/2,outline='#ffd54f',width=2,dash=(5,3))
        c.create_line(cx-10,cy,cx+10,cy,fill='#ffca28',width=2)
        c.create_line(cx,cy-10,cx,cy+10,fill='#ffca28',width=2)
        c.create_text(cx+8,cy+8,text='GROUND ANCHOR',anchor='nw',fill='#ffe082')
        if self.builder_ground_show_body.get():
            # Simple isometric player guide: feet at anchor, torso extends upward.
            body_h=max(40,58*z)
            head_r=max(4,5*z)
            shoulder_y=cy-body_h*0.62
            head_y=cy-body_h
            c.create_line(cx,cy,cx,shoulder_y,fill='#ffffff',width=2)
            c.create_line(cx-12*z,shoulder_y,cx+12*z,shoulder_y,fill='#ffffff',width=2)
            c.create_line(cx,shoulder_y,cx-head_r*0.8,head_y+head_r*2,fill='#ffffff',width=2)
            c.create_line(cx,shoulder_y,cx+head_r*0.8,head_y+head_r*2,fill='#ffffff',width=2)
            c.create_oval(cx-head_r,head_y-head_r,cx+head_r,head_y+head_r,outline='#ffffff',width=2)
            # feet
            c.create_line(cx-7*z,cy,cx-2*z,cy,fill='#ffffff',width=3)
            c.create_line(cx+2*z,cy,cx+7*z,cy,fill='#ffffff',width=3)
            c.create_text(cx+10*z,head_y,text='PLAYER GUIDE',anchor='w',fill='#ffffff')


    def builder_preview_render(self):
        s=self.builder_preview_spr
        if not s:return
        try:i=int(self.builder_frame_var.get())
        except Exception:i=0
        i=max(0,min(i,s['frames']-1)); self.builder_frame=i
        z=max(.25,min(32.0,float(self.builder_zoom.get())))
        key=(i,round(z,4))
        if key not in self.builder_preview_cache:
            fr=decode_spr_frame(s,i)
            # Integer nearest-neighbor zoom is handled by frame_to_tk_photo for integer factors.
            # For fractional factors, create a 1x image then use Tk zoom/subsample approximation.
            base=frame_to_tk_photo(fr,1)
            if abs(z-1.0)<1e-6:
                img=base
            elif z>=1:
                zi=max(1,int(round(z)))
                img=base.zoom(zi,zi)
            else:
                sub=max(1,int(round(1.0/z)))
                img=base.subsample(sub,sub)
            self.builder_preview_cache[key]=(fr,img)
        fr,img=self.builder_preview_cache[key]; self.builder_preview_photo=img
        c=self.builder_canvas; c.delete('all')
        dw=img.width(); dh=img.height()
        canvas_dw=max(1,int(round(s['width']*z))); canvas_dh=max(1,int(round(s['height']*z)))
        cw=max(c.winfo_width(),canvas_dw+40); ch=max(c.winfo_height(),canvas_dh+40)
        x=max(20,(cw-canvas_dw)//2); y=max(20,(ch-canvas_dh)//2)
        # guide rectangle is the true SPR canvas; decoded frame is placed by its encoded offset.
        c.create_rectangle(x-1,y-1,x+canvas_dw,y+canvas_dh,outline='#777777',tags=('canvas_guide',))
        ix=x+int(round(fr['offset_x']*z)); iy=y+int(round(fr['offset_y']*z))
        c.create_image(ix,iy,image=img,anchor='nw',tags=('sprite',))
        self.builder_draw_ground_overlay(c,x,y,z,s)
        c.configure(scrollregion=(0,0,max(cw,x+dw+20),max(ch,y+dh+20)))
        self.builder_zoom_label.set(f'{int(round(z*100))}%')
        dx,dy=self.builder_frame_offsets[i] if i<len(self.builder_frame_offsets) else (0,0)
        self.builder_offset_label.set(f'Offset: X={dx:+d} Y={dy:+d}')
        self.builder_status.set(
            f"Frame {i}/{s['frames']-1}: {fr['width']}×{fr['height']} offset=({fr['offset_x']},{fr['offset_y']}) | "
            f"Canvas={s['width']}×{s['height']} Colors={s['colors']} Interval={s['interval']}ms | "
            f"Preview Zoom={int(round(z*100))}%")


    def builder_reset_frame_offset(self):
        if not self.builder_frames:return
        i=max(0,min(int(self.builder_frame_var.get()),len(self.builder_frames)-1))
        self.builder_frame_offsets[i]=(0,0)
        self.builder_preview_build_keep_frame(i)

    def builder_ground_visual_anchor(self, frame_index):
        """Estimate the *ground-ring* anchor of one source frame on the locked canvas.

        This intentionally does NOT use the centroid of every visible pixel. Ground-aura
        sheets often contain tall wisps/particles above the ring; those can move a normal
        alpha centroid by many pixels even when the ring itself has not moved.  Instead we
        detect the broad horizontal rows belonging to the ellipse and derive a stable
        anchor from that dense ring body.

        Returned coordinates are BEFORE the per-frame user offset is applied.
        """
        im=png_read_rgba(Path(self.builder_frames[frame_index]))
        if self.builder_reference:
            im=self.builder_transform_image(im)
        w,h=im['width'],im['height']; px=im['rgba']
        thr=max(12,int(self.builder_alpha.get()))

        # Per-row statistics.  Wisps are usually narrow; the ground ellipse is broad.
        rows=[]
        max_span=0
        for y in range(h):
            xs=[]; mass=0.0
            row=y*w
            for x in range(w):
                r,g,b,a=px[row+x]
                if a < thr:
                    continue
                # Alpha dominates, with a small brightness term so the luminous ring
                # outweighs very faint haze without requiring a hard RGB threshold.
                lum=(int(r)+int(g)+int(b))/3.0
                wt=float(a)*(0.35+0.65*(lum/255.0))
                if wt <= 0:
                    continue
                xs.append(x); mass += wt
            if xs:
                span=xs[-1]-xs[0]+1
                max_span=max(max_span,span)
                rows.append((y,span,mass,xs[0],xs[-1]))

        if not rows or max_span <= 0:
            return (w*0.5,h*0.5)

        # Keep broad rows from the main ellipse.  52% is permissive enough for thin
        # animated arcs, but rejects almost all vertical flames and isolated particles.
        broad=[r for r in rows if r[1] >= max(8,int(round(max_span*0.52)))]
        if not broad:
            broad=rows

        # Robust Y: median-ish weighted center of the broad ring rows.  Clip to the
        # central 80% of the broad-row Y range to reduce one-frame particle bridges.
        ys=[r[0] for r in broad]
        ylo,yhi=min(ys),max(ys)
        clip_lo=ylo + int(round((yhi-ylo)*0.10))
        clip_hi=yhi - int(round((yhi-ylo)*0.10))
        use=[r for r in broad if clip_lo <= r[0] <= clip_hi] or broad
        total=sum(r[2] for r in use)
        ay=sum((r[0]+0.5)*r[2] for r in use)/total if total>0 else (ylo+yhi+1)/2.0

        # X from the same broad-ring band, using weighted visible pixels.
        sx=sw=0.0
        band_y0=max(0,int(round(ay))-max(4,int(round(h*0.16))))
        band_y1=min(h-1,int(round(ay))+max(4,int(round(h*0.16))))
        for y in range(band_y0,band_y1+1):
            row=y*w
            # Only accept a row if its visible span is reasonably broad.
            xs=[x for x in range(w) if px[row+x][3] >= thr]
            if not xs or (xs[-1]-xs[0]+1) < max(8,int(round(max_span*0.45))):
                continue
            for x in xs:
                r,g,b,a=px[row+x]
                lum=(int(r)+int(g)+int(b))/3.0
                wt=float(a)*(0.35+0.65*(lum/255.0))
                sx += (x+0.5)*wt; sw += wt
        ax=sx/sw if sw>0 else w*0.5
        return (ax,ay)

    def builder_align_to_original_spr(self):
        # Align each generated frame to the visual ground-ring anchor of the original SPR.
        if not self.builder_reference or not self.builder_frames:
            messagebox.showwarning('Align to Original SPR','Cần Build Replacement từ Resource Studio và import PNG/sprite sheet mới trước.')
            return
        self.builder_sync_frame_offsets()
        try:
            rspr=self.builder_reference['spr']; new_offsets=[]; rows=[]
            for i,p in enumerate(self.builder_frames):
                sax,say=self.builder_ground_visual_anchor(i)
                rf=decode_spr_frame(rspr,min(i,rspr['frames']-1))
                # Temporarily measure reference frame with the same broad-row ellipse logic.
                w,h=rf['width'],rf['height']; px=rf['rgba']; thr=max(12,int(self.builder_alpha.get()))
                stats=[]; maxspan=0
                for y in range(h):
                    xs=[]; mass=0.0
                    for x in range(w):
                        r,g,b,a=px[y*w+x]
                        if a<thr: continue
                        lum=(r+g+b)/3.0; wt=a*(0.35+0.65*lum/255.0); xs.append(x); mass+=wt
                    if xs:
                        span=xs[-1]-xs[0]+1; maxspan=max(maxspan,span); stats.append((y,span,mass,xs[0],xs[-1]))
                broad=[q for q in stats if q[1]>=max(8,int(round(maxspan*0.52)))] or stats
                if broad:
                    total=sum(q[2] for q in broad); ray=sum((q[0]+0.5)*q[2] for q in broad)/max(1,total)
                    rax=sum(((q[3]+q[4]+1)/2.0)*q[2] for q in broad)/max(1,total)
                else: rax,ray=w/2.0,h/2.0
                dx=int(round(rax-sax)); dy=int(round(ray-say)); new_offsets.append((dx,dy)); rows.append((i,dx,dy))
            sample='\n'.join(f'Frame {i:02d}: X={dx:+d} Y={dy:+d}' for i,dx,dy in rows[:8])
            if len(rows)>8: sample+='\n...'
            if not messagebox.askyesno('Align to Original SPR','Căn SPR mới theo vị trí visual của SPR gốc?\n\n'+sample+'\n\nMỗi frame sẽ có offset riêng và vẫn có thể kéo tay sau đó.'):
                return
            self.builder_frame_offsets=new_offsets
            cur=max(0,min(int(self.builder_frame_var.get()),len(new_offsets)-1)); self.builder_offset_label.set(f'Offset: X={new_offsets[cur][0]:+d} Y={new_offsets[cur][1]:+d}')
            self.builder_status.set(f'Align to Original SPR PASS | aligned {len(new_offsets)} frame(s)'); self.builder_preview_build_keep_frame(cur)
        except Exception as e: messagebox.showerror('Align to Original SPR',f'Không thể căn theo SPR gốc:\n{e}')

    def builder_apply_current_offset_to_all(self):
        """Align every frame's ground ring to the selected frame's *visual* position.

        Important distinction: equal numeric offsets do not imply equal visual positions
        when the generated PNGs contain the aura at different intrinsic coordinates.
        The selected frame becomes the reference.  For every other frame we measure the
        ground-ring anchor and calculate the individual X/Y offset needed to place that
        anchor at exactly the selected frame's final position.
        """
        if not self.builder_frames:
            return
        self.builder_sync_frame_offsets()
        i=max(0,min(int(self.builder_frame_var.get()),len(self.builder_frames)-1))
        ref_dx,ref_dy=self.builder_frame_offsets[i]
        try:
            ref_ax,ref_ay=self.builder_ground_visual_anchor(i)
            target_x=ref_ax+ref_dx
            target_y=ref_ay+ref_dy
            detected=[]; new_offsets=[]
            for j in range(len(self.builder_frames)):
                ax,ay=self.builder_ground_visual_anchor(j)
                dx=int(round(target_x-ax))
                dy=int(round(target_y-ay))
                if j==i:
                    # Preserve the selected frame EXACTLY; rounding in the detector must
                    # never modify the reference frame the user positioned by hand.
                    dx,dy=int(ref_dx),int(ref_dy)
                detected.append((ax,ay))
                new_offsets.append((dx,dy))
        except Exception as e:
            messagebox.showerror('Apply Offset to All',f'Không đo được ground-ring anchor:\n{e}')
            return

        if len(self.builder_frames)>1:
            sample='\n'.join(
                f'Frame {j:02d}: anchor=({detected[j][0]:.1f},{detected[j][1]:.1f}) -> offset=({new_offsets[j][0]:+d},{new_offsets[j][1]:+d})'
                for j in range(min(6,len(self.builder_frames))))
            if len(self.builder_frames)>6:
                sample += '\n...'
            ok=messagebox.askyesno(
                'Apply Offset to All — Ground Align',
                f'Use Frame {i:02d} as the visual ground-anchor reference?\n\n'
                f'Reference final anchor = ({target_x:.1f}, {target_y:.1f})\n\n'
                f'{sample}\n\n'
                'Each frame will receive its OWN corrective X/Y offset so the aura ring lands at the same position.')
            if not ok:
                return

        self.builder_frame_offsets=new_offsets
        self.builder_offset_label.set(f'Offset: X={new_offsets[i][0]:+d} Y={new_offsets[i][1]:+d}')
        self.builder_status.set(
            f'Ground Align PASS | reference Frame {i:02d} | target=({target_x:.1f},{target_y:.1f}) | '
            f'aligned {len(self.builder_frames)} frames')
        self.builder_preview_build_keep_frame(i)

    def builder_preview_build_keep_frame(self,i):
        try:
            self.builder_preview_stop(); tmp,meta=self.builder_make_temp()
            self.builder_preview_spr=parse_spr_file(tmp); self.builder_preview_cache={}
            i=max(0,min(i,self.builder_preview_spr['frames']-1)); self.builder_frame=i; self.builder_frame_var.set(i)
            self.builder_spin.configure(to=max(0,self.builder_preview_spr['frames']-1)); self.builder_preview_render()
        except Exception as e:
            messagebox.showerror('SPR Builder',f'Không cập nhật được preview:\n{e}')

    def builder_nudge_frame(self,dx,dy):
        if not self.builder_frames:return 'break'
        i=max(0,min(int(self.builder_frame_var.get()),len(self.builder_frames)-1))
        ox,oy=self.builder_frame_offsets[i]; self.builder_frame_offsets[i]=(ox+dx,oy+dy)
        self.builder_preview_build_keep_frame(i); self.builder_canvas.focus_set(); return 'break'

    def builder_drag_start(self,e):
        if not self.builder_preview_spr or not self.builder_frames:return
        ids=self.builder_canvas.find_withtag('sprite')
        if not ids:return
        # Drag starts only when clicking the visible sprite bounding box.
        bb=self.builder_canvas.bbox(ids[0]); x=self.builder_canvas.canvasx(e.x); y=self.builder_canvas.canvasy(e.y)
        if not bb or not (bb[0]<=x<=bb[2] and bb[1]<=y<=bb[3]):return
        i=max(0,min(int(self.builder_frame_var.get()),len(self.builder_frames)-1))
        self.builder_drag_state=(i,x,y,self.builder_frame_offsets[i][0],self.builder_frame_offsets[i][1])
        self.builder_canvas.focus_set(); self.builder_preview_stop()

    def builder_drag_motion(self,e):
        if not self.builder_drag_state:return
        i,sx,sy,ox,oy=self.builder_drag_state; x=self.builder_canvas.canvasx(e.x); y=self.builder_canvas.canvasy(e.y)
        z=max(.25,min(32.0,float(self.builder_zoom.get())))
        dx=int(round((x-sx)/z)); dy=int(round((y-sy)/z))
        ndx,ndy=ox+dx,oy+dy
        curx,cury=self.builder_frame_offsets[i]
        self.builder_canvas.move('sprite',(ndx-curx)*z,(ndy-cury)*z)
        self.builder_frame_offsets[i]=(ndx,ndy); self.builder_offset_label.set(f'Offset: X={ndx:+d} Y={ndy:+d}')

    def builder_drag_end(self,e):
        if not self.builder_drag_state:return
        i=self.builder_drag_state[0]; self.builder_drag_state=None
        self.builder_preview_build_keep_frame(i)


    def builder_preview_step(self,d):
        if not self.builder_preview_spr:return
        self.builder_preview_stop()
        self.builder_frame_var.set((self.builder_frame+d)%self.builder_preview_spr['frames'])

    def builder_preview_stop(self):
        self.builder_playing=False
        try:self.builder_play_btn.configure(text='Play')
        except Exception:pass
        if self.builder_after:
            try:self.root.after_cancel(self.builder_after)
            except Exception:pass
            self.builder_after=None

    def builder_preview_toggle(self):
        if not self.builder_preview_spr:
            self.builder_preview_build()
            if not self.builder_preview_spr:return
        if self.builder_playing:self.builder_preview_stop(); return
        self.builder_playing=True; self.builder_play_btn.configure(text='Stop')
        try:
            for i in range(self.builder_preview_spr['frames']):
                if i not in self.builder_preview_cache:
                    fr=decode_spr_frame(self.builder_preview_spr,i)
                    self.builder_preview_cache[i]=(fr,frame_to_tk_photo(fr,1))
        except Exception as e:
            self.builder_preview_stop(); messagebox.showerror('SPR Builder',str(e)); return
        self.builder_preview_tick()

    def builder_preview_tick(self):
        if not self.builder_playing or not self.builder_preview_spr:return
        n=self.builder_preview_spr['frames']
        nxt=self.builder_frame+1
        if nxt>=n:
            if self.builder_loop.get(): nxt=0
            else:
                self.builder_preview_stop(); return
        self.builder_frame_var.set(nxt)
        self.builder_after=self.root.after(max(1,int(self.builder_preview_spr.get('interval') or 40)),self.builder_preview_tick)


    def builder_reference_loose_path(self):
        if not self.builder_reference:
            raise ValueError('Chưa load Reference SPR.')
        v=self.builder_reference.get('virtual_path','')
        if not v:
            raise ValueError('Reference không có virtual path.')
        root=getattr(self,'client_root',None)
        if not root:
            # scanner stores client root in root_var in current branch
            rv=getattr(self,'root_var',None)
            if rv is not None:
                try: root=Path(rv.get())
                except Exception: root=None
        if not root:
            raise ValueError('Không xác định được Client Root.')
        root=Path(root)
        rel=v.replace('/','\\').lstrip('\\')
        return root / Path(rel.replace('\\',os.sep))

    def builder_deploy_output_dir(self):
        root=getattr(self,'out_dir',None)
        if root:
            try:return Path(root)
            except Exception:pass
        rv=getattr(self,'root_var',None)
        if rv is not None:
            try:
                cr=Path(rv.get())
                return cr/'JX_CLIENT_MAPPING'
            except Exception:pass
        return Path.cwd()/'JX_CLIENT_MAPPING'

    def builder_make_deploy_build(self):
        if not self.builder_reference:
            raise ValueError('BUILD + DEPLOY chỉ dùng sau Build Replacement từ Resource Studio.')
        if not self.builder_frames:
            raise ValueError('Chưa Add PNG.')
        outdir=self.builder_deploy_output_dir()/'deploy_builds'
        outdir.mkdir(parents=True,exist_ok=True)
        name=Path(self.builder_reference['virtual_path'].replace('\\','/')).name or 'replacement.spr'
        built=outdir/name
        meta=self.builder_build_reference_spr(self.builder_frames,built)
        parsed=parse_spr_file(built)
        # strict reference compatibility checks
        ref=self.builder_reference
        problems=[]
        if parsed['width']!=ref['canvas_w'] or parsed['height']!=ref['canvas_h']:
            problems.append(f"canvas {parsed['width']}x{parsed['height']} != {ref['canvas_w']}x{ref['canvas_h']}")
        if parsed['frames']!=ref['frames']: problems.append(f"frames {parsed['frames']} != {ref['frames']}")
        if parsed['directions']!=ref['directions']: problems.append(f"directions {parsed['directions']} != {ref['directions']}")
        if problems: raise ValueError('Reference compatibility FAIL: '+ '; '.join(problems))
        for i in range(parsed['frames']): decode_spr_frame(parsed,i)
        return built,meta,parsed

    def builder_build_deploy(self):
        try:
            self.builder_sync_interval_from_fps()
            built,meta,parsed=self.builder_make_deploy_build()
            target=self.builder_reference_loose_path()
            target.parent.mkdir(parents=True,exist_ok=True)

            stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_root=self.builder_deploy_output_dir()/'resource_backups'/stamp
            backup=None
            if target.exists():
                rel=Path(self.builder_reference['virtual_path'].replace('\\','/').lstrip('/'))
                backup=backup_root/rel
                backup.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(target,backup)

            shutil.copy2(built,target)

            # Verify deployed bytes can be parsed and decoded.
            dep=parse_spr_file(target)
            for i in range(dep['frames']): decode_spr_frame(dep,i)

            report={
                'Tool':'JX Client Scanner V4.5',
                'Time':stamp,
                'VirtualPath':self.builder_reference['virtual_path'],
                'PakSource':self.builder_reference['row'].get('pak_name',''),
                'PakEntry':self.builder_reference['row'].get('elem_index',''),
                'BuiltFile':str(built),
                'DeployTarget':str(target),
                'Backup':str(backup) if backup else '',
                'Reference':{
                    'Canvas':[self.builder_reference['canvas_w'],self.builder_reference['canvas_h']],
                    'Frames':self.builder_reference['frames'],
                    'Directions':self.builder_reference['directions'],
                    'Offset':[self.builder_reference['offset_x'],self.builder_reference['offset_y']]
                },
                'Verification':'PASS parse+decode deployed SPR'
            }
            report_path=self.builder_deploy_output_dir()/'DEPLOY_LAST_REPORT.txt'
            write_text_safe(report_path,json.dumps(report,ensure_ascii=False,indent=2))
            self.builder_last_deploy={'target':target,'backup':backup,'report':report_path}
            self.builder_deploy_status.set(
                f"DEPLOY PASS → {target} | backup={'YES' if backup else 'NO existing loose file'}")
            messagebox.showinfo(
                'Build + Deploy',
                f"DEPLOY PASS\n\nTarget:\n{target}\n\n"
                f"Backup:\n{backup if backup else '(không có file loose cũ)'}\n\n"
                f"Report:\n{report_path}\n\nHãy restart Game.exe để test.")
        except Exception as e:
            messagebox.showerror('Build + Deploy',f'DEPLOY FAIL:\n{e}')


    def _package_ini_insert_before_source(self, clone_name, source_name):
        """Insert clone before source in [Package] numeric order; first PAK wins in this client branch.
        Returns (ini_path, backup_path, new_order).
        """
        root=getattr(self,'client_root',None)
        if not root:
            rv=getattr(self,'root_var',None)
            if rv is not None:
                try: root=Path(rv.get())
                except Exception: root=None
        if not root:
            cv=getattr(self,'client_var',None)
            if cv is not None:
                try: root=Path(cv.get())
                except Exception: root=None
        if not root:
            raise ValueError('Không xác định được Client Root để sửa package.ini.')
        root=Path(root)
        ini_path=next((p for p in (root/'package.ini',root/'Package.ini',root/'PACKAGE.INI') if p.exists()),None)
        if not ini_path:
            raise ValueError('Không tìm thấy package.ini trong Client Root.')
        text,enc=safe_read_text(ini_path)
        if text is None:
            raise ValueError('Không đọc được package.ini.')
        lines=text.splitlines()
        sec_start=None; sec_end=len(lines)
        for i,line in enumerate(lines):
            st=line.strip()
            if st.lower()=='[package]':
                sec_start=i; continue
            if sec_start is not None and i>sec_start and st.startswith('[') and st.endswith(']'):
                sec_end=i; break
        if sec_start is None:
            raise ValueError('package.ini thiếu section [Package].')
        numeric=[]
        for i in range(sec_start+1,sec_end):
            m=re.match(r'^(\s*)(\d+)(\s*=\s*)(.*?)(\s*)$',lines[i])
            if m:
                val=m.group(4).strip().strip('\"\'')
                numeric.append((i,int(m.group(2)),val,m.group(1),m.group(3),m.group(5)))
        numeric.sort(key=lambda x:x[1])
        vals=[x[2] for x in numeric]
        # Avoid duplicate declaration. If clone is already present, just report its order.
        low=[v.lower() for v in vals]
        if clone_name.lower() in low:
            return ini_path,None,low.index(clone_name.lower())
        src_idx=next((i for i,v in enumerate(vals) if Path(v.replace('\\','/')).name.lower()==Path(source_name).name.lower()),None)
        if src_idx is None:
            # Conservative fallback: put clone first so it has precedence over its source copy.
            insert_idx=0
        else:
            insert_idx=src_idx
        vals.insert(insert_idx,clone_name)
        # Preserve non-numeric lines in section; replace the numeric block at the first numeric line.
        if numeric:
            first=numeric[0][0]; numeric_lines={x[0] for x in numeric}
            new_section=[]
            inserted=False
            for i in range(sec_start+1,sec_end):
                if i in numeric_lines:
                    if not inserted:
                        for n,v in enumerate(vals): new_section.append(f'{n}={v}')
                        inserted=True
                    continue
                new_section.append(lines[i])
            lines=lines[:sec_start+1]+new_section+lines[sec_end:]
        else:
            new_section=[f'{n}={v}' for n,v in enumerate(vals)]
            lines=lines[:sec_start+1]+new_section+lines[sec_start+1:]
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        backup=ini_path.with_name(ini_path.name+f'.bak_{stamp}')
        shutil.copy2(ini_path,backup)
        newline='\r\n' if '\r\n' in text else '\n'
        ini_path.write_text(newline.join(lines)+newline,encoding=enc or 'utf-8',errors='backslashreplace')
        return ini_path,backup,insert_idx

    def builder_clone_pak_deploy(self):
        """Clone the reference PAK, replace only the selected entry by appending a new raw SPR payload,
        update that entry's index record, verify it, then insert clone before source in package.ini.
        No new PAK entry is created; PAK structure/count/order stay unchanged.
        """
        try:
            self.builder_sync_interval_from_fps()
            built,meta,parsed=self.builder_make_deploy_build()
            if not self.builder_reference or not self.builder_reference.get('row'):
                raise ValueError('Chưa có Reference từ Resource Studio.')
            row=self.builder_reference['row']
            src_pak,src_entry=self.rs_entry(row)
            src_pak=Path(src_pak)
            if not src_pak.exists(): raise ValueError(f'Không tìm thấy source PAK: {src_pak}')
            default_name=src_pak.stem+'_mod'+src_pak.suffix
            clone_path=filedialog.asksaveasfilename(
                title='Clone PAK mới',initialdir=str(src_pak.parent),initialfile=default_name,
                defaultextension='.pak',filetypes=[('JX XPack','*.pak'),('All files','*.*')])
            if not clone_path: return
            clone_path=Path(clone_path)
            if clone_path.resolve()==src_pak.resolve():
                raise ValueError('PAK clone phải có tên khác source PAK.')
            if clone_path.parent.resolve()!=src_pak.parent.resolve():
                raise ValueError('Hãy lưu PAK clone cùng thư mục với source PAK để package.ini có thể khai báo an toàn.')
            if clone_path.exists():
                if not messagebox.askyesno('Clone PAK',f'{clone_path.name} đã tồn tại. Ghi đè file này?'):
                    return
            shutil.copy2(src_pak,clone_path)
            xp=parse_xpack(clone_path)
            if not xp.get('valid'): raise ValueError(f'Clone PAK parse FAIL: {xp.get("error")}')
            elem=int(row.get('elem_index',-1))
            if elem<0 or elem>=len(xp['entries']):
                raise ValueError(f'elem_index không hợp lệ: {elem}')
            old=xp['entries'][elem]
            uid=old[0]
            payload=Path(built).read_bytes()
            if len(payload)>0x00FFFFFF:
                raise ValueError('SPR quá lớn cho compressed-size field 24-bit của XPack.')
            # Append replacement payload. Keep entry count and all other index entries untouched.
            with clone_path.open('r+b') as f:
                f.seek(0,os.SEEK_END)
                new_off=f.tell()
                f.write(payload)
                new_flag=len(payload) & 0x00FFFFFF  # METHOD NONE, FRAME=0, raw payload
                idx_pos=xp['index_offset'] + elem*XPACK_INDEX.size
                f.seek(idx_pos)
                f.write(XPACK_INDEX.pack(uid,new_off,len(payload),new_flag))
                f.flush(); os.fsync(f.fileno())
            # Full structural + exact entry verification.
            chk=parse_xpack(clone_path)
            if not chk.get('valid'): raise ValueError(f'Patched clone parse FAIL: {chk.get("error")}')
            if len(chk['entries'])!=len(xp['entries']): raise ValueError('PAK entry count changed unexpectedly.')
            ent=chk['entries'][elem]
            if ent[0]!=uid or ent[1]!=new_off or ent[2]!=len(payload):
                raise ValueError('Patched index verification mismatch.')
            rb,detail=native_read_xpack_entry_bytes(clone_path,ent)
            if rb!=payload: raise ValueError('Read-back bytes khác SPR vừa build.')
            sp=parse_spr_bytes(rb,f'PAK://{clone_path.name}#{elem}')
            for i in range(sp['frames']): decode_spr_frame(sp,i)
            # Put clone BEFORE source because this branch resolves first matching PAK.
            ini_path,ini_backup,new_order=self._package_ini_insert_before_source(clone_path.name,src_pak.name)
            stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
            report={
                'Tool':f'JX Client Scanner v{VERSION}','Time':stamp,'Mode':'CLONE_PAK_REPLACE_EXISTING_ENTRY',
                'SourcePak':str(src_pak),'ClonePak':str(clone_path),'VirtualPath':self.builder_reference['virtual_path'],
                'PakEntry':elem,'uId':f'0x{uid:08X}','OldOffset':old[1],'NewOffset':new_off,
                'OldOriginalSize':old[2],'NewOriginalSize':len(payload),'Storage':'RAW/NONE appended at EOF',
                'PackageIni':str(ini_path),'PackageIniBackup':str(ini_backup) if ini_backup else '',
                'ClonePackageOrder':new_order,'Verification':'PASS XPack parse + exact readback + SPR decode'
            }
            report_path=self.builder_deploy_output_dir()/'CLONE_PAK_LAST_REPORT.txt'
            write_text_safe(report_path,json.dumps(report,ensure_ascii=False,indent=2))
            self.builder_deploy_status.set(f'CLONE PAK PASS → {clone_path.name} | package order={new_order}')
            messagebox.showinfo('Clone PAK + Deploy',
                'PASS\n\n'
                f'Source PAK giữ nguyên:\n{src_pak}\n\n'
                f'Clone đã patch:\n{clone_path}\n\n'
                f'Resource:\n{self.builder_reference["virtual_path"]}\nEntry #{elem}\n\n'
                f'package.ini đã thêm clone ở order {new_order} (trước source).\n'
                f'Backup package.ini:\n{ini_backup if ini_backup else "(clone đã được khai báo trước đó)"}\n\n'
                'Hãy restart Game.exe để test.')
        except Exception as e:
            messagebox.showerror('Clone PAK + Deploy',f'FAIL:\n{e}')

    def builder_restore_last(self):
        try:
            # Prefer in-memory last deploy, fallback to report.
            info=self.builder_last_deploy
            if not info:
                rp=self.builder_deploy_output_dir()/'DEPLOY_LAST_REPORT.txt'
                if not rp.exists(): raise ValueError('Chưa có deploy report để restore.')
                d=json.loads(rp.read_text(encoding='utf-8'))
                info={'target':Path(d['DeployTarget']),
                      'backup':Path(d['Backup']) if d.get('Backup') else None,
                      'report':rp}
            target=Path(info['target']); backup=info.get('backup')
            if backup and Path(backup).exists():
                target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(backup,target)
                msg=f'RESTORE PASS\n\n{backup}\n→\n{target}'
            else:
                # If no old loose file existed, restoring means remove deployed loose override.
                if target.exists(): target.unlink()
                msg=f'RESTORE PASS\n\nĐã xóa loose override:\n{target}\nGame sẽ quay lại resource PAK (nếu runtime cho phép).'
            self.builder_deploy_status.set('RESTORE LAST: PASS')
            messagebox.showinfo('Restore Last',msg)
        except Exception as e:
            messagebox.showerror('Restore Last',f'RESTORE FAIL:\n{e}')


    def builder_build(self):
        self.builder_sync_interval_from_fps()
        if not self.builder_frames:
            messagebox.showwarning('SPR Builder','Chưa có PNG frame.'); return
        out=filedialog.asksaveasfilename(title='Build JX SPR',defaultextension='.spr',filetypes=[('JX Sprite','*.spr')])
        if not out:return
        try:
            if self.builder_reference:
                meta=self.builder_build_reference_spr(self.builder_frames,Path(out))
            else:
                meta=build_jx_spr_from_pngs(
                    self.builder_frames,Path(out),
                    interval=self.builder_interval.get(),directions=self.builder_directions.get(),
                    center_x=self.builder_center_x.get(),center_y=self.builder_center_y.get(),
                    auto_crop=self.builder_crop.get(),alpha_threshold=self.builder_alpha.get(),
                    max_colors=self.builder_colors.get(),frame_offsets=self.builder_frame_offsets)
            side=Path(out).with_suffix('.spr.txt')
            info={
                'Builder':'JX Client Scanner V4.6.7',
                'Output':str(out),'Width':meta['width'],'Height':meta['height'],'Frames':meta['frames'],
                'Directions':meta['directions'],'Interval':meta['interval'],'Colors':meta['colors'],'Size':meta['size'],
                'AutoCrop':self.builder_crop.get(),'AlphaThreshold':self.builder_alpha.get(),
                'SourceFrames':[str(x) for x in self.builder_frames],
                'PerFrameUserOffsets':[{'frame':i,'x':o[0],'y':o[1]} for i,o in enumerate(self.builder_frame_offsets)],
                'Frames':meta['frame_meta'],'Verification':'PASS: parsed+decoded all frames'
            }
            write_text_safe(side,json.dumps(info,ensure_ascii=False,indent=2))
            self.builder_preview_spr=parse_spr_file(Path(out)); self.builder_preview_cache={}; self.builder_frame_var.set(0); self.builder_preview_render()
            messagebox.showinfo('SPR Builder',f'BUILD SPR: PASS\n\n{out}\n{side}\n\nĐã verify parse + decode toàn bộ frame.')
        except Exception as e:
            messagebox.showerror('SPR Builder',f'BUILD SPR thất bại:\n{e}')


    # ---------------- V4.8 SPR AI ROUND-TRIP ----------------
    def _build_ai_roundtrip(self,parent):
        """Single-resource AI editing workflow: PAK SPR -> enlarged PNG -> edited PNG -> SPR -> clone PAK."""
        self.ai_rt_reference=None
        self.ai_rt_workspace=None
        self.ai_rt_edited=[]
        self.ai_rt_original_canvas=[]
        self.ai_rt_edited_canvas=[]
        self.ai_rt_frame=tk.IntVar(value=0)
        self.ai_rt_scale=tk.IntVar(value=8)
        self.ai_rt_alpha=tk.IntVar(value=1)
        self.ai_rt_zoom=tk.IntVar(value=4)
        self.ai_rt_info=tk.StringVar(value='Chọn SPR trong Resource Studio rồi bấm "Use Selected Resource".')
        self.ai_rt_ref_label=tk.StringVar(value='Reference: none')
        self.ai_rt_edit_label=tk.StringVar(value='Edited: none')
        # V4.8.2 AI prompt generator. User may override the auto-detected garment class.
        self.ai_rt_prompt_type=tk.StringVar(value='Auto detect')
        self.ai_rt_prompt_mode=tk.StringVar(value='Strict Remaster')
        self.ai_rt_prompt_extra=tk.StringVar(value='')
        # V4.8.2: preserve intentional source asymmetry instead of letting AI
        # beautify/straighten/symmetrize the low-resolution sprite. Enabled by default.
        self.ai_rt_preserve_asymmetry=tk.BooleanVar(value=True)
        self.ai_rt_photo_orig=None; self.ai_rt_photo_edit=None

        top=ttk.Frame(parent); top.pack(fill='x',padx=10,pady=10)
        ttk.Label(top,text='SPR Builder with ChatGPT',style='Title.TLabel').grid(row=0,column=0,columnspan=10,sticky='w')
        ttk.Label(top,text='PAK → SPR → AI PNG → SPR → Clone PAK',foreground=self.ui['muted']).grid(row=0,column=3,columnspan=7,sticky='e')
        ttk.Button(top,text='1. Use Selected Resource',command=self.ai_rt_use_selected).grid(row=1,column=0,padx=(0,4),pady=(8,0))
        ttk.Button(top,text='2. Export AI Workspace',command=self.ai_rt_export_workspace).grid(row=1,column=1,padx=4,pady=(8,0))
        ttk.Button(top,text='3. Import Edited PNG/Folder',command=self.ai_rt_import_edited).grid(row=1,column=2,padx=4,pady=(8,0))
        ttk.Button(top,text='4. BUILD SPR',command=self.ai_rt_build_dialog).grid(row=1,column=3,padx=(12,4),pady=(8,0))
        ttk.Button(top,text='5. BUILD + CLONE PAK',command=self.ai_rt_clone_pak).grid(row=1,column=4,padx=4,pady=(8,0))
        ttk.Button(top,text='Open Workspace',command=self.ai_rt_open_workspace).grid(row=1,column=5,padx=(12,4),pady=(8,0))
        ttk.Label(top,textvariable=self.ai_rt_ref_label).grid(row=2,column=0,columnspan=10,sticky='w',pady=(7,0))
        ttk.Label(top,textvariable=self.ai_rt_edit_label).grid(row=3,column=0,columnspan=10,sticky='w')

        opts=ttk.LabelFrame(parent,text='AI Working Settings'); opts.pack(fill='x',padx=10,pady=(0,8))
        ttk.Label(opts,text='AI Working Scale:').pack(side='left',padx=(8,3),pady=6)
        ttk.Spinbox(opts,textvariable=self.ai_rt_scale,from_=1,to=16,width=5).pack(side='left')
        ttk.Label(opts,text='×   (8× recommended for tiny JX sprites)').pack(side='left',padx=(2,12))
        ttk.Label(opts,text='Alpha threshold:').pack(side='left',padx=(8,3))
        ttk.Spinbox(opts,textvariable=self.ai_rt_alpha,from_=0,to=255,width=5).pack(side='left')
        ttk.Label(opts,text='Preview zoom:').pack(side='left',padx=(14,3))
        z=ttk.Combobox(opts,textvariable=self.ai_rt_zoom,state='readonly',width=4,values=[1,2,3,4,6,8,10,12,16]); z.pack(side='left')
        z.bind('<<ComboboxSelected>>',lambda e:self.ai_rt_render())
        ttk.Button(opts,text='◀',width=3,command=lambda:self.ai_rt_step(-1)).pack(side='left',padx=(16,2))
        ttk.Button(opts,text='▶',width=3,command=lambda:self.ai_rt_step(1)).pack(side='left',padx=2)
        ttk.Label(opts,text='Frame:').pack(side='left',padx=(8,2))
        self.ai_rt_spin=ttk.Spinbox(opts,textvariable=self.ai_rt_frame,from_=0,to=0,width=6,command=self.ai_rt_render); self.ai_rt_spin.pack(side='left')
        self.ai_rt_spin.bind('<Return>',lambda e:self.ai_rt_render())

        # V4.8.2 — Prompt generator kept inside the Round-Trip tab so the AI
        # instructions always travel with the selected JX resource.
        pg=ttk.LabelFrame(parent,text='AI Prompt Generator — source-preserving JX remaster')
        pg.pack(fill='x',padx=10,pady=(0,8))
        pgbar=ttk.Frame(pg); pgbar.pack(fill='x',padx=8,pady=(6,4))
        ttk.Label(pgbar,text='Garment type:').pack(side='left')
        self.ai_rt_prompt_type_combo=ttk.Combobox(
            pgbar,textvariable=self.ai_rt_prompt_type,state='readonly',width=20,
            values=['Auto detect','Robe / Long Cloth','Shirt / Jacket','Dress / Skirt','Light Armor','Heavy Armor',
                    'Headgear / Hat','Cape / Cloak','Gloves / Bracers','Boots / Shoes','Belt / Waist Accessory','Generic Clothing'])
        self.ai_rt_prompt_type_combo.pack(side='left',padx=(4,10))
        ttk.Label(pgbar,text='Edit mode:').pack(side='left')
        self.ai_rt_prompt_mode_combo=ttk.Combobox(
            pgbar,textvariable=self.ai_rt_prompt_mode,state='readonly',width=20,
            values=['Strict Remaster','Material Change','Controlled Redesign'])
        self.ai_rt_prompt_mode_combo.pack(side='left',padx=(4,10))
        ttk.Label(pgbar,text='Extra request:').pack(side='left')
        ttk.Entry(pgbar,textvariable=self.ai_rt_prompt_extra,width=38).pack(side='left',fill='x',expand=True,padx=(4,8))
        ttk.Button(pgbar,text='Generate Prompt',command=self.ai_rt_generate_prompt).pack(side='left',padx=2)
        ttk.Button(pgbar,text='Copy Prompt',command=self.ai_rt_copy_prompt).pack(side='left',padx=2)
        ttk.Button(pgbar,text='Save .txt',command=self.ai_rt_save_prompt).pack(side='left',padx=(2,0))
        pglock=ttk.Frame(pg); pglock.pack(fill='x',padx=8,pady=(0,4))
        ttk.Checkbutton(
            pglock,
            text='Preserve source asymmetry — do NOT straighten, beautify, mirror or symmetrize the sprite',
            variable=self.ai_rt_preserve_asymmetry,
            command=self.ai_rt_generate_prompt
        ).pack(side='left')
        ttk.Label(
            pglock,
            text='Keeps original uneven sleeves, collar angle, drape, tilt and source-implied irregularities.',
            foreground=self.ui['muted']
        ).pack(side='left',padx=(10,0))
        promptfr=ttk.Frame(pg); promptfr.pack(fill='x',padx=8,pady=(0,7))
        self.ai_rt_prompt_text=tk.Text(promptfr,height=9,wrap='word',font=('Consolas',9),undo=True)
        self.ai_rt_prompt_text.pack(side='left',fill='x',expand=True)
        pgsb=ttk.Scrollbar(promptfr,orient='vertical',command=self.ai_rt_prompt_text.yview)
        pgsb.pack(side='right',fill='y'); self.ai_rt_prompt_text.configure(yscrollcommand=pgsb.set)
        self.ai_rt_prompt_type_combo.bind('<<ComboboxSelected>>',lambda e:self.ai_rt_generate_prompt())
        self.ai_rt_prompt_mode_combo.bind('<<ComboboxSelected>>',lambda e:self.ai_rt_generate_prompt())

        pane=ttk.Panedwindow(parent,orient='horizontal'); pane.pack(fill='both',expand=True,padx=10,pady=(0,8))
        a=ttk.Frame(pane); b=ttk.Frame(pane); pane.add(a,weight=1); pane.add(b,weight=1)
        ttk.Label(a,text='ORIGINAL — full SPR canvas',font=('Segoe UI',11,'bold')).pack(anchor='w',pady=(0,4))
        ttk.Label(b,text='EDITED — normalized back to SPR canvas',font=('Segoe UI',11,'bold')).pack(anchor='w',pady=(0,4))
        self.ai_rt_canvas_orig=tk.Canvas(a,bg=self.ui['canvas'],highlightthickness=0); self.ai_rt_canvas_orig.pack(fill='both',expand=True)
        self.ai_rt_canvas_edit=tk.Canvas(b,bg=self.ui['canvas'],highlightthickness=0); self.ai_rt_canvas_edit.pack(fill='both',expand=True)
        ttk.Label(parent,textvariable=self.ai_rt_info,justify='left',wraplength=1400).pack(fill='x',padx=12,pady=(0,10))

    def ai_rt_detect_garment_type(self):
        """Conservative filename/path classifier; the user can always override it."""
        if not self.ai_rt_reference:
            return 'Generic Clothing'
        vp=str(self.ai_rt_reference.get('virtual_path','')).lower().replace('/','\\')
        name=Path(vp.replace('\\','/')).name.lower()
        t=' '+vp+' '+name+' '
        checks=[
            (('helmet','helm','head','hat','cap','hood','tou','mao'), 'Headgear / Hat'),
            (('boot','shoe','shoes','feet','foot','xie'), 'Boots / Shoes'),
            (('glove','hand','bracer','wrist','wan'), 'Gloves / Bracers'),
            (('cape','cloak','mantle','pifeng'), 'Cape / Cloak'),
            (('belt','waist','yaodai'), 'Belt / Waist Accessory'),
            (('heavy','plate','mail','cuirass'), 'Heavy Armor'),
            (('armor','armour','equip\\armor'), 'Light Armor'),
            (('dress','skirt','qun'), 'Dress / Skirt'),
            (('shirt','jacket','coat','top'), 'Shirt / Jacket'),
            (('robe','cloth','clothes','garment','yi'), 'Robe / Long Cloth'),
        ]
        for keys,label in checks:
            if any(k in t for k in keys): return label
        return 'Generic Clothing'

    def ai_rt_garment_constraints(self,kind):
        data={
            'Robe / Long Cloth': (
                'Preserve robe length, hem width, collar opening, sleeve length, sleeve volume, front overlap/seam, and the vertical drape of the garment. ',
                'Refine broad cloth folds, hem/cuff/collar trim, woven fabric separation and restrained wuxia cloth shading. Avoid turning soft cloth into rigid armor.'),
            'Shirt / Jacket': (
                'Preserve torso width, shoulder line, sleeve openings, front closure, collar and cropped/waist length. ',
                'Improve cloth/leather panel readability, seams, cuffs and medium-scale folds without changing the fitted silhouette.'),
            'Dress / Skirt': (
                'Preserve bodice-to-skirt transition, waist position, skirt flare, hem, sleeve/strap geometry and any visible layered panels. ',
                'Refine fabric layers and readable folds while keeping the original skirt volume and symmetry/asymmetry.'),
            'Light Armor': (
                'Preserve every major armor plate/panel boundary, shoulder width, torso silhouette, sleeves, straps and exposed cloth sections. ',
                'Clarify leather/metal/cloth material separation, edges, rivets or trim only where implied by the source. Keep the armor agile and not bulkier.'),
            'Heavy Armor': (
                'Preserve plate silhouette, pauldrons, chest/waist segmentation, gauntlet/leg coverage and all major hard-surface boundaries. ',
                'Improve metal edge definition, layered plates, restrained specular highlights and material separation. Do not slim, enlarge or redesign plates.'),
            'Headgear / Hat': (
                'Preserve headgear outline, brim/crown/hood shape, openings, ornaments and exact orientation. ',
                'Refine fabric, leather or metal definition while keeping all attachment points and transparent openings unchanged.'),
            'Cape / Cloak': (
                'Preserve cape length, shoulder attachment, outer contour, split/openings and drape direction. ',
                'Improve large cloth folds and edge trim; do not add wind motion or change the hanging silhouette.'),
            'Gloves / Bracers': (
                'Preserve cuff length, hand/wrist silhouette, armor/cloth segmentation and orientation. ',
                'Refine leather/metal/cloth detail at medium scale; do not add fingers, hands or anatomy not visible in the source.'),
            'Boots / Shoes': (
                'Preserve sole/heel/toe shape, shaft height, openings, straps and exact perspective. ',
                'Refine leather/cloth/metal material separation and readable seams without changing footwear proportions.'),
            'Belt / Waist Accessory': (
                'Preserve belt width, buckle/fastener placement, hanging pieces, pouches/ornaments and exact canvas position. ',
                'Refine material definition and edges while keeping every attachment point stable.'),
            'Generic Clothing': (
                'Preserve every major silhouette boundary, opening, sleeve/panel/trim position and exact perspective. ',
                'Recover only conservative, plausible garment detail that is strongly implied by the source.'),
        }
        return data.get(kind,data['Generic Clothing'])

    def ai_rt_generate_prompt(self):
        kind=self.ai_rt_prompt_type.get().strip() or 'Auto detect'
        detected=self.ai_rt_detect_garment_type()
        use_kind=detected if kind=='Auto detect' else kind
        mode=self.ai_rt_prompt_mode.get().strip() or 'Strict Remaster'
        extra=self.ai_rt_prompt_extra.get().strip()
        if self.ai_rt_reference:
            spr=self.ai_rt_reference['spr']; vp=self.ai_rt_reference.get('virtual_path','')
            canvas=f"{spr['width']} x {spr['height']}"; frames=int(spr['frames']); dirs=int(spr['directions']); scale=max(1,min(16,int(self.ai_rt_scale.get())))
            ai_canvas=f"{spr['width']*scale} x {spr['height']*scale}"
        else:
            vp='(select a resource in Resource Studio first)'; canvas='unknown'; frames=1; dirs=1; scale=max(1,min(16,int(self.ai_rt_scale.get()))); ai_canvas='unknown'
        geo,detail=self.ai_rt_garment_constraints(use_kind)
        if mode=='Strict Remaster':
            edit_goal='Remaster the SAME asset. Do not redesign it. Only restore clarity, material readability, edges, medium-scale folds and source-implied details.'
            design_lock='Do NOT add new ornaments, new garment parts, new openings, new straps, new symbols, or a new color scheme.'
        elif mode=='Material Change':
            edit_goal='Keep geometry and silhouette locked, but allow the requested material/color treatment only. Structural design must remain unchanged.'
            design_lock='Do NOT change cut, proportions, pose, camera, silhouette, garment construction or attachment points. Change only material/color/surface treatment requested below.'
        else:
            edit_goal='Perform a controlled redesign while preserving the original game-asset geometry, pose, perspective, silhouette footprint and canvas placement.'
            design_lock='New surface decoration/material details are allowed, but do NOT change the main silhouette, cut, length, openings, pose, camera or canvas-relative position.'
        extra_line=extra if extra else 'No additional redesign request; remain maximally faithful to the source.'
        asymmetry_enabled=bool(self.ai_rt_preserve_asymmetry.get()) if hasattr(self,'ai_rt_preserve_asymmetry') else True
        if asymmetry_enabled:
            asymmetry_block='''SOURCE ASYMMETRY LOCK — CRITICAL
Preserve the source sprite's existing asymmetry exactly where it is visible or strongly implied.
- Do NOT straighten the garment into a cleaner or more upright pose.
- Do NOT make the left and right sides artificially symmetrical.
- Do NOT mirror one sleeve, cuff, shoulder, collar side, hem side or fold pattern onto the other.
- Do NOT center or level an intentionally off-center collar, overlap, opening, seam, drape or silhouette.
- Do NOT equalize sleeve length/width, shoulder height, hem contour or fold placement merely for visual neatness.
- Do NOT apply beauty cleanup that changes the source geometry.
- Preserve natural source irregularities, tilt, uneven drape, perspective distortion and hand-authored pixel-era asymmetry.
- If a source feature is ambiguous because of low resolution, choose the interpretation that changes the original silhouette and geometry the LEAST.

The goal is restoration, not geometric correction. The remaster may be cleaner, but it must not become more symmetric, straighter, more centered or more idealized than the source.'''
        else:
            asymmetry_block='SOURCE ASYMMETRY LOCK\nDisabled by the user. Do not deliberately introduce symmetry changes unless explicitly requested.'
        prompt=f"""JX / SWORDONLINE SPRITE AI ROUND-TRIP — {mode.upper()}

SOURCE RESOURCE
Virtual path: {vp}
Detected/selected garment type: {use_kind}
Native SPR canvas: {canvas} pixels
AI working canvas: {ai_canvas} pixels ({scale}x working scale)
Frames: {frames}
Directions: {dirs}

HIGHEST PRIORITY — SOURCE PRESERVATION
Treat the uploaded PNG as the authoritative game asset source.
{edit_goal}

Preserve exactly:
- outer silhouette and transparent footprint
- garment proportions and construction
- pose and orientation
- camera angle and perspective
- position and scale inside the existing canvas
- all structural openings and transparent gaps
- major color/material regions unless Material Change was explicitly requested

GARMENT-SPECIFIC LOCK
{geo}
{detail}

{asymmetry_block}

DESIGN LIMIT
{design_lock}

SPR ROUND-TRIP COMPATIBILITY — CRITICAL
The edited PNG will be downsampled and converted back into a JX / SwordOnline SPR.
- Keep a fully transparent RGBA background.
- Do not crop, reframe, recenter, rotate, mirror, zoom or move the asset.
- Keep the exact input canvas size.
- Do not add environment, floor, pedestal, mannequin, character body, head, hands, legs, weapons, cast shadows outside the asset, aura, particles, text, border or watermark.
- Preserve transparent holes/open areas where structurally appropriate.
- Do not create loose pixels or effects outside the source silhouette.

DOWNSAMPLING OPTIMIZATION
The AI image is a high-resolution working image and will be reduced back to {canvas}.
Prioritize clean medium-scale forms, readable material separation, controlled local contrast and strong edges.
Avoid micro-texture, excessive sharpening, tiny ornaments, noisy patterns and details that disappear after downsampling.
Lighting should remain soft, baked and game-sprite compatible; no cinematic relighting or bloom.

USER REQUEST
{extra_line}

FINAL REQUIREMENT
The result must still be immediately recognizable as the SAME JX asset after downsampling. Preserve geometry first; improve or alter only the aspects explicitly permitted above."""
        if hasattr(self,'ai_rt_prompt_text'):
            self.ai_rt_prompt_text.delete('1.0','end'); self.ai_rt_prompt_text.insert('1.0',prompt)
        return prompt

    def ai_rt_copy_prompt(self):
        prompt=self.ai_rt_prompt_text.get('1.0','end-1c').strip() if hasattr(self,'ai_rt_prompt_text') else ''
        if not prompt: prompt=self.ai_rt_generate_prompt()
        try:
            self.root.clipboard_clear(); self.root.clipboard_append(prompt); self.root.update()
            self.ai_rt_info.set('AI prompt copied to clipboard.')
        except Exception as e: messagebox.showerror('Copy Prompt',str(e))

    def ai_rt_save_prompt(self):
        prompt=self.ai_rt_prompt_text.get('1.0','end-1c').strip() if hasattr(self,'ai_rt_prompt_text') else ''
        if not prompt: prompt=self.ai_rt_generate_prompt()
        stem='JX_SPR_AI_PROMPT'
        if self.ai_rt_reference:
            stem=Path(self.ai_rt_reference.get('virtual_path','asset').replace('\\','/')).stem+'_AI_PROMPT'
        p=filedialog.asksaveasfilename(title='Save AI Prompt',defaultextension='.txt',initialfile=stem+'.txt',filetypes=[('Text','*.txt')])
        if not p:return
        try:
            Path(p).write_text(prompt,encoding='utf-8')
            self.ai_rt_info.set(f'Prompt saved: {p}')
        except Exception as e: messagebox.showerror('Save Prompt',str(e))

    def ai_rt_use_selected(self):
        try:
            r=self.rs_selected()
            if not r: raise ValueError('Hãy chọn một SPR trong Resource Studio trước.')
            pak,entry=self.rs_entry(r)
            raw,detail=native_read_xpack_entry_bytes(pak,entry)
            spr=parse_spr_bytes(raw,f"PAK://{r.get('pak_name')}#{r.get('elem_index')}::{r.get('virtual_path')}")
            full=[]; frame_meta=[]
            for i in range(spr['frames']):
                fr=decode_spr_frame(spr,i)
                full.append(self.ai_rt_frame_to_canvas(spr,fr))
                frame_meta.append({'frame':i,'width':fr['width'],'height':fr['height'],'offset_x':fr['offset_x'],'offset_y':fr['offset_y']})
            self.ai_rt_reference={'row':dict(r),'pak':str(pak),'entry':entry,'raw':raw,'spr':spr,
                                  'virtual_path':normalize_virtual_path(r['virtual_path']),'frame_meta':frame_meta}
            self.ai_rt_original_canvas=full; self.ai_rt_edited=[]; self.ai_rt_edited_canvas=[]; self.ai_rt_workspace=None
            self.ai_rt_frame.set(0); self.ai_rt_spin.configure(to=max(0,spr['frames']-1))
            self.ai_rt_ref_label.set(f"Reference: {Path(r['virtual_path'].replace('\\','/')).name} | {r.get('pak_name')} entry={r.get('elem_index')} | Canvas={spr['width']}×{spr['height']} F={spr['frames']} D={spr['directions']} Colors={spr['colors']}")
            self.ai_rt_edit_label.set('Edited: none')
            self.notebook.select(self.ai_rt_tab); self.ai_rt_render()
            self.ai_rt_generate_prompt()
            self.ai_rt_info.set('Reference loaded. Prompt Generator đã tạo prompt theo loại resource. Export AI Workspace để tạo PNG phóng lớn + metadata. Mọi frame được xuất trên FULL CANVAS nên vị trí/offset không bị mất.')
        except Exception as e:
            messagebox.showerror('SPR Builder with ChatGPT',str(e))

    def ai_rt_frame_to_canvas(self,spr,fr):
        cw,ch=int(spr['width']),int(spr['height']); out=[(0,0,0,0)]*(cw*ch)
        fw,fh=int(fr['width']),int(fr['height']); ox,oy=int(fr['offset_x']),int(fr['offset_y'])
        for y in range(fh):
            ty=oy+y
            if ty<0 or ty>=ch: continue
            for x in range(fw):
                tx=ox+x
                if tx<0 or tx>=cw: continue
                p=fr['rgba'][y*fw+x]
                if p[3]: out[ty*cw+tx]=p
        return {'width':cw,'height':ch,'rgba':out}

    def ai_rt_resize_bilinear(self,im,nw,nh):
        sw,sh=int(im['width']),int(im['height']); src=im['rgba']; nw=max(1,int(nw)); nh=max(1,int(nh))
        if sw==nw and sh==nh: return {'width':sw,'height':sh,'rgba':list(src)}
        out=[]
        for y in range(nh):
            fy=((y+0.5)*sh/nh)-0.5; y0=max(0,min(sh-1,int(math.floor(fy)))); y1=min(sh-1,y0+1); wy=max(0.0,min(1.0,fy-y0))
            for x in range(nw):
                fx=((x+0.5)*sw/nw)-0.5; x0=max(0,min(sw-1,int(math.floor(fx)))); x1=min(sw-1,x0+1); wx=max(0.0,min(1.0,fx-x0))
                p00=src[y0*sw+x0]; p10=src[y0*sw+x1]; p01=src[y1*sw+x0]; p11=src[y1*sw+x1]
                vals=[]
                for c in range(4):
                    a=p00[c]*(1-wx)+p10[c]*wx; b=p01[c]*(1-wx)+p11[c]*wx
                    vals.append(max(0,min(255,int(round(a*(1-wy)+b*wy)))))
                out.append(tuple(vals))
        return {'width':nw,'height':nh,'rgba':out}

    def ai_rt_resize_nearest(self,im,nw,nh):
        sw,sh=int(im['width']),int(im['height']); src=im['rgba']; nw=max(1,int(nw)); nh=max(1,int(nh)); out=[]
        for y in range(nh):
            sy=min(sh-1,int(y*sh/nh))
            for x in range(nw):
                sx=min(sw-1,int(x*sw/nw)); out.append(src[sy*sw+sx])
        return {'width':nw,'height':nh,'rgba':out}

    def ai_rt_export_workspace(self):
        if not self.ai_rt_reference:
            messagebox.showwarning('SPR Builder with ChatGPT','Hãy Use Selected Resource trước.'); return
        base=filedialog.askdirectory(title='Chọn nơi tạo AI Workspace')
        if not base:return
        try:
            ref=self.ai_rt_reference; spr=ref['spr']; scale=max(1,min(16,int(self.ai_rt_scale.get())))
            stem=Path(ref['virtual_path'].replace('\\','/')).stem
            ws=Path(base)/(stem+'_AI_WORKSPACE')
            native=ws/'original_native'; aiin=ws/'ai_input'; edited=ws/'edited'; output=ws/'output'
            for d in (native,aiin,edited,output): d.mkdir(parents=True,exist_ok=True)
            (ws/'original.spr').write_bytes(ref['raw'])
            for i,im in enumerate(self.ai_rt_original_canvas):
                png_write_rgba(native/f'frame_{i:04d}.png',im['width'],im['height'],im['rgba'])
                up=self.ai_rt_resize_nearest(im,im['width']*scale,im['height']*scale)
                png_write_rgba(aiin/f'frame_{i:04d}.png',up['width'],up['height'],up['rgba'])
            meta={'Tool':f'JX Client Scanner v{VERSION}','Workflow':'SPR_AI_ROUND_TRIP','VirtualPath':ref['virtual_path'],
                  'PakName':ref['row'].get('pak_name',''),'PakOrder':ref['row'].get('pak_order',''),'ElemIndex':ref['row'].get('elem_index',''),
                  'CanvasWidth':spr['width'],'CanvasHeight':spr['height'],'Frames':spr['frames'],'Directions':spr['directions'],
                  'Interval':spr['interval'],'Colors':spr['colors'],'CenterX':spr['center_x'],'CenterY':spr['center_y'],
                  'AIWorkingScale':scale,'FrameMeta':ref['frame_meta'],
                  'Instructions':['Edit PNG files from ai_input. Keep transparent RGBA background.','Do not crop/reframe; keep subject position inside the full canvas.','Save edited files with matching frame_0000.png names into edited folder.']}
            (ws/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
            # Store the exact generated prompt next to ai_input so each workspace is self-contained.
            prompt=self.ai_rt_generate_prompt()
            (ws/'AI_PROMPT.txt').write_text(prompt,encoding='utf-8')
            readme=(
                'JX SPR AI ROUND-TRIP WORKSPACE\n\n'
                '1) Send PNG(s) from ai_input to ChatGPT / image editor.\n'
                '2) Keep transparent background and composition/position.\n'
                '3) Put returned PNG(s) into edited with matching frame names.\n'
                '4) In tool: Import Edited PNG/Folder -> Preview -> BUILD SPR or BUILD + CLONE PAK.\n\n'
                f'Native canvas: {spr["width"]}x{spr["height"]}\nAI scale: {scale}x\nFrames: {spr["frames"]}\n')
            (ws/'README_AI_WORKFLOW.txt').write_text(readme,encoding='utf-8')
            self.ai_rt_workspace=ws
            self.ai_rt_info.set(f'AI Workspace PASS: {ws} | ai_input={spr["frames"]} PNG @ {scale}×. Đưa ảnh trong ai_input cho ChatGPT; lưu kết quả vào edited.')
            try: os.startfile(aiin)
            except Exception: pass
        except Exception as e: messagebox.showerror('Export AI Workspace',str(e))

    def ai_rt_import_edited(self):
        if not self.ai_rt_reference:
            messagebox.showwarning('SPR Builder with ChatGPT','Hãy Use Selected Resource trước.'); return
        spr=self.ai_rt_reference['spr']; n=spr['frames']
        try:
            if n==1:
                p=filedialog.askopenfilename(title='Chọn PNG đã chỉnh',filetypes=[('PNG','*.png')])
                if not p:return
                files=[Path(p)]
            else:
                d=filedialog.askdirectory(title=f'Chọn folder chứa {n} edited PNG frames')
                if not d:return
                d=Path(d); files=[]
                for i in range(n):
                    cand=d/f'frame_{i:04d}.png'
                    if not cand.exists(): raise FileNotFoundError(f'Thiếu {cand.name}')
                    files.append(cand)
            canv=[]; opacity_warnings=[]
            for i,p in enumerate(files):
                im=png_read_rgba(p)
                opaque=sum(1 for q in im['rgba'] if q[3]>=250)
                if opaque > len(im['rgba'])*0.95: opacity_warnings.append(p.name)
                norm=self.ai_rt_resize_bilinear(im,spr['width'],spr['height'])
                canv.append(norm)
            self.ai_rt_edited=[str(p) for p in files]; self.ai_rt_edited_canvas=canv
            self.ai_rt_frame.set(0); self.ai_rt_edit_label.set(f'Edited: {len(files)} frame(s) loaded | normalized → {spr["width"]}×{spr["height"]}')
            self.ai_rt_render()
            warn=(' | WARNING: gần như opaque: '+', '.join(opacity_warnings[:5])) if opacity_warnings else ''
            self.ai_rt_info.set(f'Import edited PASS. Preview đang hiển thị full canvas trước/sau.{warn}')
        except Exception as e: messagebox.showerror('Import Edited PNG',str(e))

    def ai_rt_step(self,delta):
        if not self.ai_rt_reference:return
        n=self.ai_rt_reference['spr']['frames']; self.ai_rt_frame.set((int(self.ai_rt_frame.get())+delta)%max(1,n)); self.ai_rt_render()

    def ai_rt_render(self):
        if not self.ai_rt_reference:return
        spr=self.ai_rt_reference['spr']; n=spr['frames']
        try:i=max(0,min(n-1,int(self.ai_rt_frame.get())))
        except Exception:i=0
        self.ai_rt_frame.set(i); zoom=max(1,int(self.ai_rt_zoom.get()))
        def render_one(canvas,im,which):
            frame={'width':im['width'],'height':im['height'],'rgba':im['rgba']}
            photo=frame_to_tk_photo(frame,zoom)
            if which=='o': self.ai_rt_photo_orig=photo
            else:self.ai_rt_photo_edit=photo
            canvas.delete('all'); cw=max(canvas.winfo_width(),photo.width()+20); ch=max(canvas.winfo_height(),photo.height()+20)
            x=max(10,(cw-photo.width())//2); y=max(10,(ch-photo.height())//2); canvas.create_image(x,y,image=photo,anchor='nw')
        render_one(self.ai_rt_canvas_orig,self.ai_rt_original_canvas[i],'o')
        if self.ai_rt_edited_canvas and i<len(self.ai_rt_edited_canvas): render_one(self.ai_rt_canvas_edit,self.ai_rt_edited_canvas[i],'e')
        else:self.ai_rt_canvas_edit.delete('all')

    def ai_rt_build_bytes(self):
        if not self.ai_rt_reference: raise ValueError('Chưa có reference.')
        if not self.ai_rt_edited_canvas: raise ValueError('Chưa Import Edited PNG/Folder.')
        ref=self.ai_rt_reference; spr=ref['spr']; alpha=max(0,min(255,int(self.ai_rt_alpha.get())))
        works=[]
        for i,im in enumerate(self.ai_rt_edited_canvas):
            c=crop_rgba(im,alpha)
            works.append(c)
        palette=median_cut_palette(works,min(256,max(2,int(spr['colors'] or 256))),alpha)
        frames=[]; frame_meta=[]
        for i,c in enumerate(works):
            ox=int(c.get('crop_x',0)); oy=int(c.get('crop_y',0))
            blob=encode_jx_rle_frame(c,palette,alpha,ox,oy); frames.append(blob)
            frame_meta.append({'frame':i,'width':c['width'],'height':c['height'],'offset_x':ox,'offset_y':oy,'source':self.ai_rt_edited[i]})
        header=SPR_HEADER.pack(b'SPR\x00',int(spr['width']),int(spr['height']),int(spr['center_x'])&0xffff,int(spr['center_y'])&0xffff,
                               len(frames),len(palette),max(1,int(spr['directions'])),max(1,int(spr['interval'] or 1)),0,0,0,0,0,0)
        pal=b''.join(bytes(c) for c in palette); off=0; offs=[]
        for fr in frames: offs.append(SPR_OFFS.pack(off,len(fr))); off+=len(fr)
        data=header+pal+b''.join(offs)+b''.join(frames)
        parsed=parse_spr_bytes(data,'<AI Round-Trip>')
        for i in range(parsed['frames']): decode_spr_frame(parsed,i)
        return data,frame_meta,parsed

    def ai_rt_build_dialog(self):
        try:
            data,meta,parsed=self.ai_rt_build_bytes()
            initial=Path(self.ai_rt_reference['virtual_path'].replace('\\','/')).name
            out=filedialog.asksaveasfilename(title='Build AI-edited SPR',initialfile=initial,defaultextension='.spr',filetypes=[('JX Sprite','*.spr')])
            if not out:return
            Path(out).write_bytes(data)
            side=Path(out).with_suffix('.spr.txt')
            report={'Tool':f'JX Client Scanner v{VERSION}','Mode':'AI_ROUND_TRIP','Reference':self.ai_rt_reference['virtual_path'],
                    'Output':str(out),'Canvas':[parsed['width'],parsed['height']],'Frames':parsed['frames'],'Directions':parsed['directions'],
                    'Interval':parsed['interval'],'Colors':parsed['colors'],'EditedFrames':self.ai_rt_edited,'FrameMeta':meta,'Verification':'PASS parse+decode'}
            side.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            self.ai_rt_info.set(f'BUILD SPR PASS: {out}')
            messagebox.showinfo('SPR Builder with ChatGPT',f'BUILD PASS\n\n{out}\n{side}')
        except Exception as e: messagebox.showerror('SPR Builder with ChatGPT',f'BUILD FAIL:\n{e}')

    def ai_rt_clone_pak(self):
        try:
            data,meta,parsed=self.ai_rt_build_bytes(); ref=self.ai_rt_reference; row=ref['row']
            src_pak,_=self.rs_entry(row); src_pak=Path(src_pak)
            default_name=src_pak.stem+'_ai'+src_pak.suffix
            clone=filedialog.asksaveasfilename(title='Clone PAK chứa AI-edited SPR',initialdir=str(src_pak.parent),initialfile=default_name,
                                               defaultextension='.pak',filetypes=[('JX XPack','*.pak')])
            if not clone:return
            clone=Path(clone)
            if clone.resolve()==src_pak.resolve(): raise ValueError('Clone PAK phải có tên khác source PAK.')
            if clone.parent.resolve()!=src_pak.parent.resolve(): raise ValueError('Hãy lưu clone cùng thư mục source PAK.')
            if clone.exists() and not messagebox.askyesno('Clone PAK',f'{clone.name} đã tồn tại. Ghi đè?'): return
            shutil.copy2(src_pak,clone)
            xp=parse_xpack(clone)
            if not xp.get('valid'): raise ValueError(f'Clone PAK invalid: {xp.get("error")}')
            elem=int(row.get('elem_index',-1))
            if elem<0 or elem>=len(xp['entries']): raise IndexError(f'elem_index {elem} invalid')
            old=xp['entries'][elem]; uid=old[0]
            if len(data)>0x00FFFFFF: raise ValueError('SPR > 24-bit payload limit.')
            with clone.open('r+b') as f:
                f.seek(0,os.SEEK_END); new_off=f.tell(); f.write(data)
                idx_pos=xp['index_offset']+elem*XPACK_INDEX.size; f.seek(idx_pos)
                f.write(XPACK_INDEX.pack(uid,new_off,len(data),len(data)&0x00FFFFFF)); f.flush(); os.fsync(f.fileno())
            chk=parse_xpack(clone)
            if not chk.get('valid'): raise ValueError(f'Patched clone invalid: {chk.get("error")}')
            rb,detail=native_read_xpack_entry_bytes(clone,chk['entries'][elem])
            if rb!=data: raise ValueError('Readback bytes mismatch.')
            test=parse_spr_bytes(rb,f'PAK://{clone.name}#{elem}')
            for i in range(test['frames']): decode_spr_frame(test,i)
            ini,backup,order=self._package_ini_insert_before_source(clone.name,src_pak.name)
            rp=self.rs_output()/'AI_ROUNDTRIP_CLONE_LAST_REPORT.txt'
            rp.parent.mkdir(parents=True,exist_ok=True)
            rp.write_text(json.dumps({'Tool':f'JX Client Scanner v{VERSION}','Mode':'AI_ROUND_TRIP_CLONE_PAK','SourcePak':str(src_pak),
                                      'ClonePak':str(clone),'VirtualPath':ref['virtual_path'],'ElemIndex':elem,'PackageOrder':order,
                                      'PackageIni':str(ini),'PackageIniBackup':str(backup) if backup else '','Verification':'PASS'},ensure_ascii=False,indent=2),encoding='utf-8')
            self.ai_rt_info.set(f'CLONE PAK PASS: {clone.name} | package order={order}')
            messagebox.showinfo('SPR Builder with ChatGPT',f'PASS\n\nSource giữ nguyên:\n{src_pak}\n\nClone:\n{clone}\n\nResource:\n{ref["virtual_path"]}\n\npackage.ini order={order}. Restart Game.exe để test.')
        except Exception as e: messagebox.showerror('SPR Builder with ChatGPT',f'CLONE PAK FAIL:\n{e}')

    def ai_rt_open_workspace(self):
        if not self.ai_rt_workspace:
            messagebox.showinfo('SPR Builder with ChatGPT','Chưa tạo AI Workspace.'); return
        try:os.startfile(self.ai_rt_workspace)
        except Exception as e:messagebox.showerror('SPR Builder with ChatGPT',str(e))

    # ---------------- Detached SPR Palette (Patch 02.2.1) ----------------
    def _init_spr_palette_state(self):
        self.pal_search_var=tk.StringVar()
        self.pal_info_var=tk.StringVar(value='Open Palette → Load / Refresh để dùng toàn bộ SPR index.')
        self.pal_always_top_var=tk.BooleanVar(value=True)
        # Share the exact same placement mode with Real-Time UI Designer.
        # The alias keeps old Palette code compatible.
        self.pal_placement_mode=self.rtui_placement_mode
        self.pal_window=None; self.pal_grid=None
        self.pal_drag_candidate=-1; self.pal_drag_start_xy=None
        self.pal_rows=[]; self.pal_filtered=[]; self.pal_start=0
        self.pal_mode='static'
        self.pal_static_rows=[]; self.pal_animation_rows=[]; self.pal_unknown_rows=[]
        self.pal_static_start=0; self.pal_animation_start=0
        self.pal_cells=[]; self.pal_cells_by_mode={}
        self.pal_thumb_cache={}; self.pal_spr_cache={}; self.pal_pak_cache={}
        self.pal_meta_cache={}
        self.pal_load_token=0; self.pal_selected_row=None
        self.pal_anim_after=None; self.pal_anim_cursor=0
        self.pal_anim_generation=0
        self.pal_view_cols=4
        self.pal_view_rows=2
        self.pal_view_count=self.pal_view_cols*self.pal_view_rows
        self.pal_classifier_thread=None; self.pal_classifier_stop=threading.Event()
        self.pal_classifier_queue=queue.Queue()
        self.pal_classifier_done=False
        self.pal_classifier_generation=0

        # Patch 02.2.1.7 - background prefetch/decode-ahead.
        self.pal_prefetch_thread=None
        self.pal_prefetch_stop=threading.Event()
        self.pal_prefetch_queue=queue.Queue()
        self.pal_prefetch_generation=0
        self.pal_prefetch_cache={}
        self.pal_prefetch_order=[]
        self.pal_prefetch_limit=24
        self.pal_prefetch_running=False
        self.pal_pak_path_cache={}

        # Patch 02.2.1.8 - GIF-style full-frame animation cache.
        self.pal_fullframe_cache={}
        self.pal_fullframe_order=[]
        self.pal_fullframe_limit=12
        self.pal_fullframe_queue=queue.Queue()
        self.pal_fullframe_generation=0
        self.pal_fullframe_poll_after=None
        self.pal_fullframe_poll_active=False
        self.pal_fullframe_decode_slots=threading.Semaphore(2)
        self.pal_photo_build_after=None
        self.pal_photo_build_generation=0

    def open_spr_palette(self):
        if self.pal_window is not None:
            try:
                if self.pal_window.winfo_exists():
                    self.pal_window.deiconify(); self.pal_window.lift()
                    if self.pal_always_top_var.get():self.pal_window.attributes('-topmost',True)
                    return
            except Exception:pass

        win=tk.Toplevel(self.root)
        self.pal_window=win
        win.title('JX SPR Palette — Drag Directly To Game')
        win.geometry('860x560')
        win.minsize(700,500)
        win.resizable(True,True)
        try:win.attributes('-topmost',bool(self.pal_always_top_var.get()))
        except Exception:pass
        win.protocol('WM_DELETE_WINDOW',self.close_spr_palette)

        # Patch 02.2.1.3: use a dedicated bindtag injected into each palette
        # tile widget. This avoids relying on Toplevel event propagation while
        # still using one common handler for all thumbnails.
        self.pal_bindtag='JXPaletteDirectDrag'
        win.bind_class(self.pal_bindtag,'<ButtonPress-1>',self.pal_any_button_press)
        win.bind_class(self.pal_bindtag,'<B1-Motion>',self.pal_any_motion)
        win.bind_class(self.pal_bindtag,'<ButtonRelease-1>',self.pal_any_button_release)
        self.rtui_log_add('Detached SPR Palette opened: DIRECT DRAG bindtag ACTIVE')

        top=ttk.Frame(win); top.pack(fill='x',padx=10,pady=8)
        ttk.Label(top,text='SPR Palette',font=('Segoe UI',17,'bold')).pack(side='left')
        ttk.Button(top,text='Load / Refresh',command=self.pal_sync_from_resource).pack(side='right')
        ttk.Button(top,text='Rebuild Cache',command=self.pal_rebuild_persistent_cache).pack(side='right',padx=4)
        ttk.Checkbutton(top,text='Always On Top',variable=self.pal_always_top_var,
                        command=self.pal_toggle_topmost).pack(side='right',padx=8)
        ttk.Button(top,text='Delete Follow',command=self.rtui_delete_saved_follow_spr).pack(side='right',padx=4)
        ttk.Button(top,text='Save Follow',command=self.rtui_save_follow_spr).pack(side='right',padx=4)
        ttk.Button(top,text='Clear Test Sprites',command=self.rtui_clear_test_sprites).pack(side='right',padx=4)
        ttk.Checkbutton(top,text='Cross-Client Cache',variable=self.rtui_external_cache_enabled).pack(side='right',padx=4)
        ttk.Label(top,text='Placement:').pack(side='right',padx=(8,2))
        ttk.Combobox(top,textvariable=self.pal_placement_mode,state='readonly',width=12,
                     values=('SCREEN','WORLD','FOLLOW PLAYER')).pack(side='right',padx=2)
        ttk.Label(top,text='FOLLOW PLAYER = visual only, collision OFF').pack(side='right',padx=(6,2))
        ttk.Label(top,text='Character Layer:').pack(side='right',padx=(8,2))
        ttk.Combobox(top,textvariable=self.rtui_world_character_layer,state='readonly',width=16,
                     values=('UNDER CHARACTER','OVER CHARACTER')).pack(side='right',padx=2)

        bar=ttk.Frame(win); bar.pack(fill='x',padx=10,pady=(0,6))
        ttk.Label(bar,text='Search:').pack(side='left')
        ent=ttk.Entry(bar,textvariable=self.pal_search_var)
        ent.pack(side='left',fill='x',expand=True,padx=(5,8))
        ent.bind('<KeyRelease>',lambda e:self.pal_apply_filter())
        ttk.Button(bar,text='◀ Page',command=lambda:self.pal_scroll_rows(-self.pal_view_count)).pack(side='left',padx=2)
        ttk.Button(bar,text='Page ▶',command=lambda:self.pal_scroll_rows(self.pal_view_count)).pack(side='left',padx=2)

        hint=ttk.Label(win,text='GIF-STYLE 4×2 | Persistent Index: CLIENT_MAPPING\\spr_index.sqlite | ID #1...#N',
                       font=('Segoe UI',9,'bold'))
        hint.pack(fill='x',padx=12,pady=(0,5))

        self.pal_tabs=ttk.Notebook(win)
        self.pal_tabs.pack(fill='both',expand=True,padx=10,pady=(0,4))
        self.pal_static_tab=tk.Frame(self.pal_tabs,bg='#303030')
        self.pal_animation_tab=tk.Frame(self.pal_tabs,bg='#303030')
        self.pal_tabs.add(self.pal_static_tab,text='Static SPR')
        self.pal_tabs.add(self.pal_animation_tab,text='Animation SPR')
        self.pal_tabs.bind('<<NotebookTabChanged>>',self.pal_tab_changed)

        self.pal_cells_by_mode={}
        for mode,parent_tab in (('static',self.pal_static_tab),('animation',self.pal_animation_tab)):
            grid=tk.Frame(parent_tab,bg='#303030')
            grid.pack(fill='both',expand=True)
            for rr in range(self.pal_view_rows):grid.rowconfigure(rr,weight=1,uniform='palrow')
            for cc in range(self.pal_view_cols):grid.columnconfigure(cc,weight=1,uniform='palcol')
            cells=[]
            for i in range(self.pal_view_count):
                cell=tk.Frame(grid,bg='#3a3a3a',bd=1,relief='solid')
                cell.grid(row=i//self.pal_view_cols,column=i%self.pal_view_cols,
                          sticky='nsew',padx=3,pady=3)
                canv=tk.Canvas(cell,bg='#252525',highlightthickness=0,height=125)
                canv.pack(fill='both',expand=True,padx=3,pady=(3,1))
                lab=tk.Label(cell,text='',bg='#3a3a3a',fg='white',anchor='w',justify='left',
                             font=('Segoe UI',8),wraplength=190)
                lab.pack(fill='x',padx=4,pady=(1,3))
                for w in (cell,canv,lab):
                    try:
                        tags=list(w.bindtags())
                        if self.pal_bindtag not in tags:
                            tags.insert(0,self.pal_bindtag)
                            w.bindtags(tuple(tags))
                    except Exception:pass
                    w.bind('<MouseWheel>',self.pal_mousewheel,add='+')
                canv.bind('<Double-1>',lambda e,idx=i:self.pal_open_viewer(idx),add='+')
                cells.append({'frame':cell,'canvas':canv,'label':lab,'row':None,'photo':None,
                              'anim_frame':0,'next_due':0.0,'mode':mode,
                              'image_id':None,'anim_key':None,'ready':False,
                              'display_id':0})
            self.pal_cells_by_mode[mode]=cells

        self.pal_cells=self.pal_cells_by_mode['static']
        self.pal_grid=self.pal_static_tab
        ttk.Label(win,textvariable=self.pal_info_var,justify='left').pack(fill='x',padx=12,pady=(2,8))

        # Reuse the already-loaded Resource Studio index whenever possible.
        if getattr(self,'rs_rows',None):
            self.pal_rows=list(self.rs_rows)
            self.pal_start_classifier()
            self.pal_apply_filter()
        else:
            self.pal_info_var.set('Palette ready. Bấm Load / Refresh để load SPR index.')

    def pal_prefetch_key(self,r):
        return (r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path',''))

    def pal_prefetch_cache_put(self,key,item):
        self.pal_prefetch_cache[key]=item
        try:self.pal_prefetch_order.remove(key)
        except Exception:pass
        self.pal_prefetch_order.append(key)
        while len(self.pal_prefetch_order)>self.pal_prefetch_limit:
            old=self.pal_prefetch_order.pop(0)
            if old!=key:self.pal_prefetch_cache.pop(old,None)

    def pal_prefetch_cache_get(self,r):
        key=self.pal_prefetch_key(r)
        item=self.pal_prefetch_cache.get(key)
        if item:
            try:self.pal_prefetch_order.remove(key)
            except Exception:pass
            self.pal_prefetch_order.append(key)
        return item

    def pal_schedule_prefetch(self):
        if not self.pal_filtered:return

        self.pal_prefetch_generation+=1
        generation=self.pal_prefetch_generation
        self.pal_prefetch_stop.set()
        self.pal_prefetch_stop=threading.Event()
        stop_event=self.pal_prefetch_stop

        start=self.pal_start
        visible=self.pal_view_count
        cols=self.pal_view_cols
        wanted=[]

        # Next full 4x2 viewport.
        for i in range(start+visible,min(len(self.pal_filtered),start+visible*2)):
            wanted.append(self.pal_filtered[i])

        # One previous row for fast reverse scrolling.
        prev_start=max(0,start-cols)
        for i in range(prev_start,start):
            if i<len(self.pal_filtered):wanted.append(self.pal_filtered[i])

        unique=[]; seen=set()
        for r in wanted:
            k=self.pal_prefetch_key(r)
            if k in seen or k in self.pal_prefetch_cache:continue
            seen.add(k); unique.append(r)
        if not unique:return

        self.pal_prefetch_running=True
        client=str(self.client_var.get().strip())
        self.pal_prefetch_thread=threading.Thread(
            target=self.pal_prefetch_worker,
            args=(unique,client,generation,stop_event,self.pal_mode),
            name='JXPalettePrefetch',daemon=True)
        self.pal_prefetch_thread.start()
        self.root.after(60,lambda g=generation:self.pal_prefetch_poll(g))

    def pal_prefetch_worker(self,rows,client_text,generation,stop_event,mode):
        client=Path(client_text)
        pak_cache={}
        pak_path_cache=self.pal_pak_path_cache

        for r in rows:
            if stop_event.is_set() or generation!=self.pal_prefetch_generation:break
            key=self.pal_prefetch_key(r)
            try:
                pak_name=r.get('pak_name','')
                low=pak_name.lower()
                pak=pak_path_cache.get(low)
                if pak is None:
                    cands=[client/'data'/pak_name,client/pak_name]
                    pak=next((p for p in cands if p.exists()),None)
                    if pak is None:
                        pak=next((p for p in client.rglob('*.pak') if p.name.lower()==low),None)
                    pak_path_cache[low]=pak
                if not pak:raise FileNotFoundError(pak_name)

                pk=str(pak).lower()
                parsed=pak_cache.get(pk)
                if parsed is None:
                    parsed=parse_xpack(pak)
                    if not parsed.get('valid'):raise ValueError(parsed.get('error'))
                    pak_cache[pk]=parsed

                ei=int(r.get('elem_index','-1'))
                if ei<0 or ei>=len(parsed['entries']):raise IndexError(ei)
                entry=parsed['entries'][ei]
                raw,detail=native_read_xpack_entry_bytes(pak,entry)
                spr=parse_spr_bytes(raw,'PAL_PREFETCH')

                # Heavy work done outside Tk.
                fr0=decode_spr_frame(spr,0)
                item={
                    'spr':spr,
                    'frame0':fr0,
                    'frames':int(spr.get('frames') or 1),
                    'interval':int(spr.get('interval') or 80),
                    'pak':str(pak),
                }

                # 02.2.1.8: only frame0 is prefetched. Full animation frame
                # decoding happens once when the SPR becomes visible.

                try:self.pal_prefetch_queue.put_nowait(('ready',generation,key,item))
                except Exception:pass
            except Exception as e:
                try:self.pal_prefetch_queue.put_nowait(('error',generation,key,repr(e)))
                except Exception:pass

        try:self.pal_prefetch_queue.put_nowait(('done',generation))
        except Exception:pass

    def pal_prefetch_poll(self,generation=None):
        if generation!=self.pal_prefetch_generation:return
        finished=False
        try:
            for _ in range(100):
                try:item=self.pal_prefetch_queue.get_nowait()
                except queue.Empty:break
                if item[0]=='ready':
                    _,gen,key,data=item
                    if gen==self.pal_prefetch_generation:self.pal_prefetch_cache_put(key,data)
                elif item[0]=='done':
                    _,gen=item
                    if gen==self.pal_prefetch_generation:finished=True
        except Exception:pass

        if finished:
            self.pal_prefetch_running=False
            return

        th=self.pal_prefetch_thread
        if th and th.is_alive():
            self.root.after(60,lambda g=generation:self.pal_prefetch_poll(g))
        else:
            self.pal_prefetch_running=False

    def pal_prefetch_take_frame(self,r,frame_index=0):
        item=self.pal_prefetch_cache_get(r)
        if not item:return None,None
        spr=item.get('spr')
        if spr is None:return None,None
        if frame_index==0:return spr,item.get('frame0')
        return spr,None


    def pal_fullframe_key(self,r):
        return (r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path',''))

    def pal_fullframe_touch(self,key):
        try:self.pal_fullframe_order.remove(key)
        except Exception:pass
        self.pal_fullframe_order.append(key)

    def pal_fullframe_evict(self):
        visible=set()
        for cell in self.pal_cells_by_mode.get('animation',[]):
            r=cell.get('row')
            if r:visible.add(self.pal_fullframe_key(r))
        guard=0
        while len(self.pal_fullframe_order)>self.pal_fullframe_limit and guard<100:
            guard+=1
            old=self.pal_fullframe_order[0]
            if old in visible:
                self.pal_fullframe_order.append(self.pal_fullframe_order.pop(0))
                continue
            self.pal_fullframe_order.pop(0)
            self.pal_fullframe_cache.pop(old,None)

    def pal_fullframe_start_poll(self):
        if self.pal_fullframe_poll_active:return
        self.pal_fullframe_poll_active=True
        self.pal_fullframe_poll_after=self.root.after(30,self.pal_fullframe_poll)

    def pal_request_fullframe_cache(self,r):
        if self.pal_mode!='animation' or not r:return
        key=self.pal_fullframe_key(r)
        cache=self.pal_fullframe_cache.get(key)
        if cache:
            self.pal_fullframe_touch(key)
            return

        try:
            pref=self.pal_prefetch_cache_get(r)
            spr=pref.get('spr') if pref else None
            if spr is None:spr=self.pal_load_spr(r)
        except Exception:
            return

        cache={
            'state':'DECODING','spr':spr,
            'frames':max(1,int(spr.get('frames') or 1)),
            'interval':max(30,int(spr.get('interval') or 80)),
            'decoded':None,'photos':None,'build_index':0,
            'progress':0,'error':None
        }
        self.pal_fullframe_cache[key]=cache
        self.pal_fullframe_touch(key)
        self.pal_fullframe_evict()
        generation=self.pal_fullframe_generation

        th=threading.Thread(
            target=self.pal_fullframe_decode_worker,
            args=(key,spr,generation),
            name='JXPaletteFullFrameDecode',daemon=True)
        th.start()
        self.pal_fullframe_start_poll()

    def pal_fullframe_decode_worker(self,key,spr,generation):
        # At most two full SPR decoders run concurrently. Initial load can take
        # time, but playback later performs zero frame decoding.
        with self.pal_fullframe_decode_slots:
            frames=max(1,int(spr.get('frames') or 1))
            decoded=[]
            try:
                for fi in range(frames):
                    if generation!=self.pal_fullframe_generation:return
                    decoded.append(decode_spr_frame(spr,fi))
                    if fi==0 or fi%4==3 or fi+1==frames:
                        try:self.pal_fullframe_queue.put_nowait(
                            ('progress',generation,key,fi+1,frames))
                        except Exception:pass
                try:self.pal_fullframe_queue.put_nowait(
                    ('decoded',generation,key,decoded))
                except Exception:pass
            except Exception as e:
                try:self.pal_fullframe_queue.put_nowait(
                    ('error',generation,key,repr(e)))
                except Exception:pass

    def pal_fullframe_poll(self):
        self.pal_fullframe_poll_after=None
        any_building=False
        try:
            for _ in range(200):
                try:item=self.pal_fullframe_queue.get_nowait()
                except queue.Empty:break
                kind=item[0]
                if kind=='progress':
                    _,gen,key,pos,total=item
                    if gen!=self.pal_fullframe_generation:continue
                    cache=self.pal_fullframe_cache.get(key)
                    if cache:
                        cache['progress']=pos
                        cache['frames']=total
                elif kind=='decoded':
                    _,gen,key,decoded=item
                    if gen!=self.pal_fullframe_generation:continue
                    cache=self.pal_fullframe_cache.get(key)
                    if cache:
                        cache['decoded']=decoded
                        cache['photos']=[None]*len(decoded)
                        cache['build_index']=0
                        cache['state']='BUILDING'
                        any_building=True
                elif kind=='error':
                    _,gen,key,err=item
                    if gen!=self.pal_fullframe_generation:continue
                    cache=self.pal_fullframe_cache.get(key)
                    if cache:
                        cache['state']='ERROR'; cache['error']=err
        except Exception:pass

        for cache in self.pal_fullframe_cache.values():
            if cache.get('state') in ('DECODING','BUILDING'):
                any_building=True; break

        if any_building:self.pal_start_photo_build()

        # Keep polling only while some visible/full cache entry is still loading.
        active=False
        for cache in self.pal_fullframe_cache.values():
            if cache.get('state') in ('DECODING','BUILDING'):
                active=True; break
        if active:
            self.pal_fullframe_poll_after=self.root.after(30,self.pal_fullframe_poll)
        else:
            self.pal_fullframe_poll_active=False

    def pal_start_photo_build(self):
        if self.pal_photo_build_after:return
        generation=self.pal_photo_build_generation
        self.pal_photo_build_after=self.root.after(
            1,lambda g=generation:self.pal_photo_build_tick(g))

    def pal_photo_build_tick(self,generation=None):
        self.pal_photo_build_after=None
        if generation!=self.pal_photo_build_generation:return

        # Tk PhotoImage must be created on Tk thread. Limit to 2 conversions per
        # tick so the Palette stays interactive during the first load.
        built=0; pending=False
        visible_keys=[]
        for cell in self.pal_cells_by_mode.get('animation',[]):
            r=cell.get('row')
            if r:visible_keys.append(self.pal_fullframe_key(r))

        for key in visible_keys:
            cache=self.pal_fullframe_cache.get(key)
            if not cache or cache.get('state')!='BUILDING':continue
            decoded=cache.get('decoded') or []
            photos=cache.get('photos') or []
            bi=int(cache.get('build_index',0))
            while bi<len(decoded) and built<2:
                photos[bi]=frame_to_tk_photo(decoded[bi],1)
                bi+=1; built+=1
            cache['build_index']=bi
            cache['photos']=photos
            if bi>=len(decoded):
                cache['decoded']=None
                cache['state']='READY'
                cache['build_index']=0
                self.pal_fullframe_touch(key)
            else:
                pending=True
            if built>=2:break

        if not pending:
            for key in visible_keys:
                cache=self.pal_fullframe_cache.get(key)
                if cache and cache.get('state')=='BUILDING':
                    pending=True; break

        if pending:
            self.pal_photo_build_after=self.root.after(
                5,lambda g=generation:self.pal_photo_build_tick(g))

    def pal_ensure_cell_id_overlay(self,cell):
        c=cell.get('canvas')
        if c is None:return
        display_id=int(cell.get('display_id') or 0)
        try:
            c.delete('spr_id')
            if display_id>0:
                c.create_text(
                    8,8,text=f"#{display_id}",fill='white',
                    anchor='nw',tags='spr_id')
                try:c.tag_raise('spr_id')
                except Exception:pass
        except Exception:pass

    def pal_bind_canvas_image(self,cell,photo):
        c=cell['canvas']
        x=max(10,c.winfo_width())//2
        y=max(10,c.winfo_height())//2
        iid=cell.get('image_id')
        if iid is None:
            iid=c.create_image(x,y,image=photo,anchor='center',tags='sprite')
            cell['image_id']=iid
        else:
            try:
                c.coords(iid,x,y)
                c.itemconfig(iid,image=photo)
            except Exception:
                try:c.delete('sprite')
                except Exception:pass
                iid=c.create_image(x,y,image=photo,anchor='center',tags='sprite')
                cell['image_id']=iid
        cell['photo']=photo
        self.pal_ensure_cell_id_overlay(cell)

    def pal_update_cell_cache_status(self,cell,cache):
        r=cell.get('row')
        if not r:return
        vp=normalize_virtual_path(r.get('virtual_path',''))
        if not cache:
            status='LOADING'
            frames='?'
        else:
            state=cache.get('state','LOADING')
            frames=cache.get('frames','?')
            if state=='DECODING':
                status=f"DECODING {cache.get('progress',0)}/{frames}"
            elif state=='BUILDING':
                status=f"BUILDING {cache.get('build_index',0)}/{frames}"
            elif state=='READY':
                status='READY'
            elif state=='ERROR':
                status='ERROR'
            else:
                status=state
        display_id=int(cell.get('display_id') or 0)
        prefix=(f"#{display_id}  " if display_id>0 else '')
        cell['label'].configure(
            text=prefix+Path(vp).name+'\n'+vp+f'\n{status} | Frames: {frames}')

    def pal_stop_visible_animation(self):
        self.pal_anim_generation+=1
        if self.pal_anim_after:
            try:self.root.after_cancel(self.pal_anim_after)
            except Exception:pass
            self.pal_anim_after=None

    def pal_release_visible_cells(self):
        # Release Tk PhotoImage references and all off-screen parsed SPRs.
        visible=set()
        for cells in getattr(self,'pal_cells_by_mode',{}).values():
            for cell in cells:
                r=cell.get('row')
                if r:
                    visible.add((r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path','')))
                cell['photo']=None
                cell['row']=None
                cell['anim_frame']=0
                cell['next_due']=0.0
                cell['anim_key']=None
                cell['ready']=False
                cell['display_id']=0
                try:
                    cell['canvas'].delete('status')
                    cell['canvas'].delete('spr_id')
                    if cell.get('image_id') is not None:
                        cell['canvas'].itemconfig(cell['image_id'],image='')
                    cell['label'].configure(text='')
                except Exception:pass

        # PhotoImage cache is only useful for static thumbnails. Keep it small.
        while len(self.pal_thumb_cache)>24:
            try:self.pal_thumb_cache.pop(next(iter(self.pal_thumb_cache)),None)
            except Exception:break

        # Parsed animated SPRs can be much larger. Drop anything that is no
        # longer visible, while retaining a very small recent cache.
        for key in list(self.pal_spr_cache.keys()):
            if key not in visible and len(self.pal_spr_cache)>12:
                self.pal_spr_cache.pop(key,None)

    def pal_prune_after_view_change(self):
        active=set()
        for cell in self.pal_cells:
            r=cell.get('row')
            if r:
                active.add((r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path','')))
        # Animation images are never retained off-screen.
        if self.pal_mode=='animation':
            for key in list(self.pal_thumb_cache.keys()):
                if key not in active:
                    self.pal_thumb_cache.pop(key,None)
            for key in list(self.pal_spr_cache.keys()):
                if key not in active:
                    self.pal_spr_cache.pop(key,None)
        else:
            while len(self.pal_thumb_cache)>24:
                try:self.pal_thumb_cache.pop(next(iter(self.pal_thumb_cache)),None)
                except Exception:break
            while len(self.pal_spr_cache)>24:
                try:self.pal_spr_cache.pop(next(iter(self.pal_spr_cache)),None)
                except Exception:break
        self.pal_fullframe_evict()

    def pal_tab_changed(self,event=None):
        self.pal_stop_visible_animation()
        try:
            sel=self.pal_tabs.index(self.pal_tabs.select())
            self.pal_mode='animation' if sel==1 else 'static'
        except Exception:
            self.pal_mode='static'
        self.pal_cells=self.pal_cells_by_mode.get(self.pal_mode,[])
        self.pal_start=self.pal_animation_start if self.pal_mode=='animation' else self.pal_static_start
        self.pal_apply_filter(render=True)

    def pal_update_animation_timer(self):
        self.pal_stop_visible_animation()
        if self.pal_window is None or self.pal_mode!='animation':return
        self.pal_anim_generation+=1
        generation=self.pal_anim_generation
        now=time.monotonic()
        for cell in self.pal_cells_by_mode.get('animation',[]):
            cell['next_due']=now
        self.pal_anim_after=self.root.after(
            16,lambda g=generation:self.pal_animation_tick(g))

    def pal_animation_tick(self,generation=None):
        self.pal_anim_after=None
        if generation!=self.pal_anim_generation:return
        if self.pal_window is None or self.pal_mode!='animation':return

        now=time.monotonic()
        for cell in self.pal_cells_by_mode.get('animation',[]):
            r=cell.get('row')
            if not r:continue
            key=self.pal_fullframe_key(r)
            cache=self.pal_fullframe_cache.get(key)

            if not cache:
                self.pal_request_fullframe_cache(r)
                continue

            if cache.get('state')!='READY':
                self.pal_update_cell_cache_status(cell,cache)
                continue

            photos=cache.get('photos') or []
            if not photos:continue
            if now<float(cell.get('next_due',0.0)):continue

            fi=int(cell.get('anim_frame',0))%len(photos)
            photo=photos[fi]
            if photo is not None:
                self.pal_bind_canvas_image(cell,photo)
                cell['anim_frame']=(fi+1)%len(photos)
                cell['next_due']=now+max(
                    0.03,float(cache.get('interval',80))/1000.0)
                self.pal_fullframe_touch(key)
                if not cell.get('ready'):
                    cell['ready']=True
                    self.pal_update_cell_cache_status(cell,cache)

        # READY playback does no PAK access, SPR parsing, frame decoding,
        # PhotoImage construction, Canvas deletion or Canvas item creation.
        # It only switches a prebuilt PhotoImage reference with itemconfig().
        self.pal_anim_after=self.root.after(
            16,lambda g=generation:self.pal_animation_tick(g))

    def pal_start_classifier(self,force=False,ignore_disk_cache=False):
        if (not force and self.pal_classifier_done and
            len(self.pal_static_rows)+len(self.pal_animation_rows)>=len(self.pal_rows)):
            return
        rows=list(self.pal_rows)
        client=str(self.client_var.get().strip())
        if not ignore_disk_cache and self.pal_try_load_persistent_index(rows,client):
            self.pal_apply_filter(render=False)
            try:self.pal_render_page()
            except Exception:pass
            return
        if self.pal_classifier_thread and self.pal_classifier_thread.is_alive():
            if not force:return
            self.pal_classifier_stop.set()

        self.pal_classifier_generation+=1
        generation=self.pal_classifier_generation
        if force:
            self.pal_prefetch_generation+=1
            self.pal_prefetch_stop.set()
            self.pal_prefetch_cache.clear()
            self.pal_prefetch_order.clear()
        self.pal_classifier_stop=threading.Event()
        self.pal_classifier_done=False
        self.pal_classifier_queue=queue.Queue()
        self.pal_unknown_rows=list(rows)
        self.pal_static_rows=[]; self.pal_animation_rows=[]
        self.pal_classifier_thread=threading.Thread(
            target=self.pal_classifier_worker,args=(rows,client,generation,self.pal_classifier_stop),
            name='JXPaletteClassifier',daemon=True)
        self.pal_classifier_thread.start()
        self.root.after(100,lambda g=generation:self.pal_classifier_poll(g))

    def pal_classifier_worker(self,rows,client_text,generation,stop_event):
        client=Path(client_text)
        pak_cache={}
        pak_path_cache=self.pal_pak_path_cache
        for n,r in enumerate(rows):
            if stop_event.is_set() or generation!=self.pal_classifier_generation:break
            key=(r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path',''))
            meta=self.pal_meta_cache.get(key)
            if meta is None:
                try:
                    pak_name=r.get('pak_name','')
                    low=pak_name.lower()
                    pak=pak_path_cache.get(low)
                    if pak is None:
                        cands=[client/'data'/pak_name,client/pak_name]
                        pak=next((p for p in cands if p.exists()),None)
                        if pak is None:
                            # One bounded recursive lookup per unseen PAK name.
                            pak=next((p for p in client.rglob('*.pak') if p.name.lower()==low),None)
                        pak_path_cache[low]=pak
                    if not pak:raise FileNotFoundError(pak_name)
                    pk=str(pak).lower()
                    parsed=pak_cache.get(pk)
                    if parsed is None:
                        parsed=parse_xpack(pak)
                        if not parsed.get('valid'):raise ValueError(parsed.get('error'))
                        pak_cache[pk]=parsed
                    ei=int(r.get('elem_index','-1'))
                    entry=parsed['entries'][ei]
                    raw,detail=native_read_xpack_entry_bytes(pak,entry)
                    spr=parse_spr_bytes(raw,'PAL_CLASSIFY')
                    meta={'frames':int(spr.get('frames') or 1),
                          'interval':int(spr.get('interval') or 80)}
                    self.pal_meta_cache[key]=meta
                except Exception:
                    meta={'frames':1,'interval':80,'error':1}
            mode='animation' if int(meta.get('frames',1))>1 else 'static'
            try:self.pal_classifier_queue.put_nowait(('row',mode,r,key,meta,n+1,len(rows)))
            except Exception:pass
        try:self.pal_classifier_queue.put_nowait(('done',))
        except Exception:pass

    def pal_classifier_poll(self,generation=None):
        if generation is not None and generation!=self.pal_classifier_generation:return
        changed=False
        try:
            for _ in range(250):
                try:item=self.pal_classifier_queue.get_nowait()
                except queue.Empty:break
                if item[0]=='done':
                    self.pal_classifier_done=True
                    changed=True
                    continue
                _,mode,r,key,meta,pos,total=item
                if mode=='animation':self.pal_animation_rows.append(r)
                else:self.pal_static_rows.append(r)
                changed=True
                if pos%100==0:
                    self.pal_info_var.set(
                        f'Classifying SPR... {pos}/{total} | Static {len(self.pal_static_rows)} | '
                        f'Animation {len(self.pal_animation_rows)}'
                    )
        except Exception:
            pass
        if changed:
            self.pal_apply_filter(render=False)
            if self.pal_classifier_done:
                self.pal_render_page()
                rows=list(self.pal_rows); client=str(self.client_var.get().strip())
                self.pal_info_var.set(f'Classification complete | saving persistent cache...')
                self.pal_save_persistent_index(rows,client)
                self.pal_info_var.set(
                    f'CACHE READY | Indexed {len(rows)} SPR | Static {len(self.pal_static_rows)} | '
                    f'Animation {len(self.pal_animation_rows)}'
                )
        if self.pal_classifier_thread and self.pal_classifier_thread.is_alive():
            self.root.after(100,lambda g=generation:self.pal_classifier_poll(g))
        elif not self.pal_classifier_done:
            self.root.after(100,lambda g=generation:self.pal_classifier_poll(g))

    def pal_hit_test_screen(self,sx,sy):
        for i,cell in enumerate(self.pal_cells):
            frame=cell.get('frame')
            if frame is None:continue
            try:
                if not frame.winfo_ismapped():continue
                x0=frame.winfo_rootx(); y0=frame.winfo_rooty()
                x1=x0+frame.winfo_width(); y1=y0+frame.winfo_height()
                if x0<=sx<x1 and y0<=sy<y1:return i
            except Exception:pass
        return -1

    def pal_any_button_press(self,event):
        try:sx,sy=int(event.x_root),int(event.y_root)
        except Exception:
            try:sx,sy=self.root.winfo_pointerxy()
            except Exception:sx=sy=0
        hit=self.pal_hit_test_screen(sx,sy)
        if hit<0:return
        if not self.pal_cells[hit].get('row'):return
        self.pal_drag_candidate=hit
        self.pal_drag_start_xy=(sx,sy)
        self.rtui_log_add(f'Palette PRESS cell={hit} screen=({sx},{sy})')

    def pal_any_motion(self,event):
        if self.pal_drag_candidate<0 or self.rtui_dragging:return
        try:sx,sy=int(event.x_root),int(event.y_root)
        except Exception:return
        if self.pal_drag_start_xy:
            dx=abs(sx-self.pal_drag_start_xy[0]); dy=abs(sy-self.pal_drag_start_xy[1])
            if dx<3 and dy<3:return
        hit=self.pal_drag_candidate
        self.rtui_log_add(f'Palette DRAG THRESHOLD cell={hit}')
        self.pal_press(hit,event)

    def pal_any_button_release(self,event):
        if self.rtui_dragging:
            self.rtui_drag_end(event)
        self.pal_drag_candidate=-1
        self.pal_drag_start_xy=None


    def close_spr_palette(self):
        if self.rtui_dragging:
            # Do not destroy the grab owner during an active drag.
            return
        self.pal_stop_visible_animation()
        self.pal_prefetch_generation+=1
        self.pal_prefetch_stop.set()
        self.pal_prefetch_running=False
        self.pal_fullframe_generation+=1
        self.pal_photo_build_generation+=1
        if self.pal_fullframe_poll_after:
            try:self.root.after_cancel(self.pal_fullframe_poll_after)
            except Exception:pass
            self.pal_fullframe_poll_after=None
        self.pal_fullframe_poll_active=False
        if self.pal_photo_build_after:
            try:self.root.after_cancel(self.pal_photo_build_after)
            except Exception:pass
            self.pal_photo_build_after=None
        # IMPORTANT 02.2.1.6:
        # Do not stop the background classifier just because the detachable
        # Toplevel is closed. It owns no Tk widgets and can safely finish.
        # This fixes reopen-while-classifier-is-exiting leaving Animation empty.
        self.pal_release_visible_cells()
        if self.pal_window is not None:
            try:self.pal_window.destroy()
            except Exception:pass
        self.pal_window=None; self.pal_grid=None; self.pal_cells=[]; self.pal_cells_by_mode={}

    def pal_toggle_topmost(self):
        if self.pal_window is not None:
            try:self.pal_window.attributes('-topmost',bool(self.pal_always_top_var.get()))
            except Exception:pass

    def pal_sync_from_resource(self):
        if not getattr(self,'rs_rows',None):
            try:self.rs_load_index()
            except Exception as e:self.pal_info_var.set('Load index error: '+str(e)); return
        self.pal_rows=list(getattr(self,'rs_rows',[]))
        self.rtui_log_add(f'Palette index sync: rows={len(self.pal_rows)}')
        self.pal_start_classifier(force=False)
        self.pal_apply_filter()

    def pal_apply_filter(self,render=True):
        q=self.pal_search_var.get().strip().lower()
        base=self.pal_animation_rows if self.pal_mode=='animation' else self.pal_static_rows
        # Before classifier returns its first rows, keep Palette useful.
        if not base and not self.pal_classifier_done:
            base=[]
        self.pal_filtered=[r for r in base if not q or q in r.get('virtual_path','').lower() or q in r.get('pak_name','').lower()]
        if self.pal_mode=='animation':
            self.pal_animation_start=min(self.pal_animation_start,max(0,len(self.pal_filtered)-1))
            self.pal_start=self.pal_animation_start
        else:
            self.pal_static_start=min(self.pal_static_start,max(0,len(self.pal_filtered)-1))
            self.pal_start=self.pal_static_start
        if render:
            self.pal_render_page()
            if self.pal_filtered:self.root.after(30,self.pal_schedule_prefetch)

    def pal_scroll_rows(self,delta):
        if not self.pal_filtered:return
        cols=self.pal_view_cols
        visible=self.pal_view_count
        last_row=max(0,((len(self.pal_filtered)-1)//cols)*cols)
        max_start=max(0,last_row-(visible-cols))
        requested=self.pal_start+int(delta)
        # Always align viewport to a complete 4-SPR row.
        requested=(requested//cols)*cols
        self.pal_start=max(0,min(max_start,requested))
        if self.pal_mode=='animation':self.pal_animation_start=self.pal_start
        else:self.pal_static_start=self.pal_start
        self.pal_render_page()

    def pal_mousewheel(self,event):
        # One wheel notch = one virtual row (4 SPR). Old row is released and
        # exactly four new resources enter the 4x2 viewport.
        self.pal_scroll_rows(self.pal_view_cols if getattr(event,'delta',0)<0 else -self.pal_view_cols)
        return 'break'

    def pal_entry(self,r):
        pak=self.rs_find_pak(r.get('pak_name',''))
        if not pak:raise FileNotFoundError(r.get('pak_name',''))
        key=str(pak).lower(); parsed=self.pal_pak_cache.get(key)
        if parsed is None:
            parsed=parse_xpack(pak)
            if not parsed.get('valid'):raise ValueError(parsed.get('error'))
            if len(self.pal_pak_cache)>24:self.pal_pak_cache.clear()
            self.pal_pak_cache[key]=parsed
        idx=int(r.get('elem_index','-1'))
        if idx<0 or idx>=len(parsed['entries']):raise IndexError(idx)
        return pak,parsed['entries'][idx]

    def pal_load_spr(self,r):
        key=(r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path',''))
        spr=self.pal_spr_cache.get(key)
        if spr is not None:return spr

        pref=self.pal_prefetch_cache_get(r)
        if pref and pref.get('spr') is not None:
            spr=pref['spr']
            self.pal_spr_cache[key]=spr
            return spr
        pak,entry=self.pal_entry(r); data,detail=native_read_xpack_entry_bytes(pak,entry)
        spr=parse_spr_bytes(data,f"PAK://{r.get('pak_name')}#{r.get('elem_index')}::{r.get('virtual_path')}")
        # Bounded FIFO-style eviction instead of clearing every cached object at once.
        if len(self.pal_spr_cache)>=24:
            try:
                oldkey=next(iter(self.pal_spr_cache))
                if oldkey!=key:self.pal_spr_cache.pop(oldkey,None)
            except Exception:pass
        if len(self.pal_thumb_cache)>=24:
            try:self.pal_thumb_cache.pop(next(iter(self.pal_thumb_cache)),None)
            except Exception:pass
        self.pal_spr_cache[key]=spr; return spr

    def pal_render_page(self):
        if self.pal_window is None or not self.pal_cells:return
        self.pal_stop_visible_animation()
        self.pal_load_token+=1; token=self.pal_load_token
        for i,cell in enumerate(self.pal_cells):
            idx=self.pal_start+i
            cell['photo']=None; cell['anim_frame']=0; cell['next_due']=0.0
            cell['anim_key']=None; cell['ready']=False; cell['display_id']=0
            try:
                cell['canvas'].delete('status')
                cell['canvas'].delete('spr_id')
                if cell.get('image_id') is not None:
                    cell['canvas'].itemconfig(cell['image_id'],image='')
            except Exception:pass
            if idx>=len(self.pal_filtered):
                cell['row']=None; cell['label'].configure(text=''); continue
            r=self.pal_filtered[idx]; cell['row']=r
            display_id=idx+1
            cell['display_id']=display_id
            vp=normalize_virtual_path(r.get('virtual_path',''))
            key=(r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path',''))
            meta=self.pal_meta_cache.get(key,{})
            suffix=f"\nFrames: {meta.get('frames','?')}" if self.pal_mode=='animation' else ''
            cell['label'].configure(text=f"#{display_id}  "+Path(vp).name+'\n'+vp+suffix)
            cell['canvas'].create_text(
                8,8,text=f"#{display_id}",fill='white',anchor='nw',
                tags='spr_id')
            cell['canvas'].create_text(
                8,28,text='loading...',fill='white',anchor='nw',
                tags='status')
        tabname='Animation' if self.pal_mode=='animation' else 'Static'
        self.pal_info_var.set(
            f'{tabname}: {len(self.pal_filtered)} SPR | showing '
            f'{self.pal_start+1 if self.pal_filtered else 0}–'
            f'{min(len(self.pal_filtered),self.pal_start+self.pal_view_count)} '
            f'| viewport {self.pal_view_cols}×{self.pal_view_rows} | prefetch + GIF cache ON'
        )
        self.pal_prune_after_view_change()
        self.root.after(1,lambda:self.pal_load_next(0,token))

    def pal_load_next(self,i,token):
        if self.pal_window is None or not self.pal_cells:return
        if token!=self.pal_load_token or i>=self.pal_view_count:return
        cell=self.pal_cells[i]; r=cell.get('row')
        if r:
            try:
                key=(r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path',''))
                photo=None if self.pal_mode=='animation' else self.pal_thumb_cache.get(key)
                if photo is None:
                    spr,fr=self.pal_prefetch_take_frame(r,0)
                    if spr is None:spr=self.pal_load_spr(r)
                    if fr is None:fr=decode_spr_frame(spr,0)
                    photo=frame_to_tk_photo(fr,1)
                    if self.pal_mode!='animation':self.pal_thumb_cache[key]=photo
                c=cell['canvas']
                try:c.delete('status')
                except Exception:pass
                self.pal_bind_canvas_image(cell,photo)
                if self.pal_mode=='animation':
                    cell['anim_key']=self.pal_fullframe_key(r)
                    self.pal_request_fullframe_cache(r)
                    self.pal_update_cell_cache_status(
                        cell,self.pal_fullframe_cache.get(cell['anim_key']))
            except Exception:
                try:
                    cell['canvas'].delete('status')
                    cell['canvas'].create_text(8,28,text='preview error',fill='white',anchor='nw',tags='status')
                    self.pal_ensure_cell_id_overlay(cell)
                except Exception:pass
        if i+1>=self.pal_view_count:
            self.pal_prune_after_view_change()
            self.pal_update_animation_timer()
            self.root.after(20,self.pal_schedule_prefetch)
        else:
            self.root.after(8,lambda:self.pal_load_next(i+1,token))

    def pal_press(self,cell_index,event):
        if not (0<=cell_index<len(self.pal_cells)):
            self.rtui_log_add(f'Palette press ignored: invalid cell {cell_index}')
            return
        r=self.pal_cells[cell_index].get('row')
        if not r:
            self.rtui_log_add(f'Palette press ignored: cell {cell_index} has no row')
            return

        vp=normalize_virtual_path(r.get('virtual_path',''))
        try:
            spr=self.pal_load_spr(r)
        except Exception as e:
            self.pal_info_var.set('SPR load error: '+str(e))
            self.rtui_log_add(f'Palette SPR LOAD FAIL: {vp} | {e}')
            return

        # Critical 02.2.1.1 change:
        # arm resource and START DRAG before any optional preview/UI sync.
        self.pal_selected_row=r
        try:
            for j,c in enumerate(self.pal_cells):
                c['frame'].configure(relief=('sunken' if j==cell_index else 'solid'),bd=(3 if j==cell_index else 1))
        except Exception:pass
        self.rtui_resource={
            'row':r,'spr':spr,'virtual_path':vp,'runtime_virtual_path':'',
            'canvas':(spr['width'],spr['height']),
            'frames':spr['frames'],'directions':spr['directions'],
            'colors':spr['colors'],'interval':spr['interval'],
            'center':(spr.get('center_x',0),spr.get('center_y',0))
        }
        self.rtui_log_add(
            f'Palette SPR ARMED: cell={cell_index} path={vp} '
            f"canvas={spr['width']}x{spr['height']} frames={spr['frames']} "
            f"center=({spr.get('center_x',0)},{spr.get('center_y',0)})"
        )

        # Drag must begin even if the hidden/main Runtime preview cannot refresh.
        self.rtui_drag_start(event)
        self.rtui_palette_native_drag_begin()
        self.pal_info_var.set('DRAGGING → Game.exe: '+vp)

        # Optional synchronization only. Failure here must never cancel drag.
        try:self.rtui_custom_w.set(int(spr['width']))
        except Exception as e:self.rtui_log_add('Palette sync custom W failed: '+str(e))
        try:self.rtui_custom_h.set(int(spr['height']))
        except Exception as e:self.rtui_log_add('Palette sync custom H failed: '+str(e))
        try:
            self.rtui_resource_info.set(
                f"{vp}\nCanvas {spr['width']}×{spr['height']} | "
                f"Frames {spr['frames']} | Palette direct drag"
            )
        except Exception as e:self.rtui_log_add('Palette sync resource info failed: '+str(e))
        try:self.rtui_spr_path.set(vp)
        except Exception as e:self.rtui_log_add('Palette sync path failed: '+str(e))
        try:self.rtui_render_resource_preview()
        except Exception as e:self.rtui_log_add('Palette preview refresh skipped: '+str(e))
        try:self.rtui_update_resize_preview()
        except Exception as e:self.rtui_log_add('Palette resize preview skipped: '+str(e))


    def pal_open_viewer(self,cell_index):
        r=self.pal_cells[cell_index].get('row') if 0<=cell_index<len(self.pal_cells) else None
        if not r:return
        try:
            pak,entry=self.pal_entry(r); data,detail=native_read_xpack_entry_bytes(pak,entry)
            self.viewer_load_memory(data,r.get('virtual_path','')); self.notebook.select(self.viewer_tab)
        except Exception as e:self.pal_info_var.set('Viewer error: '+str(e))

    def _build_resource_studio(self,parent):
        self.rs_rows=[]; self.rs_filtered=[]; self.rs_refs={}
        self.rs_search_var=tk.StringVar()
        self.rs_info_var=tk.StringVar(value='Bấm Load Index sau khi scan V4.3.1.')
        self.rs_preview_info=tk.StringVar(value='Chọn một SPR để xem preview trực tiếp từ PAK.')
        self.rs_preview_spr=None
        self.rs_preview_photo=None
        self.rs_preview_cache={}
        self.rs_preview_playing=False
        self.rs_preview_after=None
        self.rs_preview_frame=0
        self.rs_preview_token=0

        top=ttk.Frame(parent); top.pack(fill='x',padx=10,pady=10)
        ttk.Label(top,text='JX Resource Studio',style='Title.TLabel').grid(row=0,column=0,columnspan=9,sticky='w')
        ttk.Label(top,text='Search virtual SPR path:').grid(row=1,column=0,sticky='w',pady=(8,0))
        ent=ttk.Entry(top,textvariable=self.rs_search_var); ent.grid(row=2,column=0,columnspan=4,sticky='ew',padx=(0,6))
        ent.bind('<KeyRelease>',lambda e:self.rs_apply_filter())
        ttk.Button(top,text='Load Index',command=self.rs_load_index).grid(row=2,column=4,padx=3)
        ttk.Button(top,text='Open Full Viewer',command=self.rs_view_pak).grid(row=2,column=5,padx=3)
        ttk.Button(top,text='Extract + TXT',command=self.rs_extract_with_txt).grid(row=2,column=6,padx=3)
        ttk.Button(top,text='Find References',command=self.rs_show_refs).grid(row=2,column=7,padx=3)
        ttk.Button(top,text='Open SPR Palette',command=self.open_spr_palette).grid(row=2,column=8,padx=3)
        ttk.Button(top,text='Build Replacement',command=self.rs_build_replacement).grid(row=2,column=8,padx=3)
        top.columnconfigure(0,weight=1)

        pane=ttk.Panedwindow(parent,orient='horizontal')
        pane.pack(fill='both',expand=True,padx=10,pady=(0,6))

        left=ttk.Frame(pane)
        right=ttk.Frame(pane)
        pane.add(left,weight=3)
        pane.add(right,weight=2)

        cols=('path','pak','order','method','frame','refs')
        self.rs_tree=ttk.Treeview(left,columns=cols,show='headings',selectmode='browse')
        headers={'path':'Virtual SPR Path','pak':'PAK','order':'Order','method':'Compression','frame':'Frame','refs':'NpcRes Refs'}
        widths={'path':460,'pak':110,'order':50,'method':75,'frame':45,'refs':70}
        for c in cols:
            self.rs_tree.heading(c,text=headers[c]); self.rs_tree.column(c,width=widths[c],anchor='w')
        self.rs_tree.grid(row=0,column=0,sticky='nsew')
        sy=ttk.Scrollbar(left,orient='vertical',command=self.rs_tree.yview); sy.grid(row=0,column=1,sticky='ns')
        sx=ttk.Scrollbar(left,orient='horizontal',command=self.rs_tree.xview); sx.grid(row=1,column=0,sticky='ew')
        self.rs_tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        self.rs_tree.bind('<Double-1>',lambda e:self.rs_view_pak())
        self.rs_tree.bind('<<TreeviewSelect>>',lambda e:self.rs_selection_changed())
        left.rowconfigure(0,weight=1); left.columnconfigure(0,weight=1)

        ttk.Label(right,text='Live SPR Preview',font=('Segoe UI',12,'bold')).pack(anchor='w',padx=6,pady=(2,4))
        ctr=ttk.Frame(right); ctr.pack(fill='x',padx=6)
        ttk.Button(ctr,text='◀',width=3,command=lambda:self.rs_preview_step(-1)).pack(side='left')
        ttk.Button(ctr,text='▶',width=3,command=lambda:self.rs_preview_step(1)).pack(side='left',padx=(4,0))
        self.rs_preview_play_btn=ttk.Button(ctr,text='Play',width=7,command=self.rs_preview_toggle)
        self.rs_preview_play_btn.pack(side='left',padx=8)
        ttk.Label(ctr,text='Frame:').pack(side='left')
        self.rs_preview_frame_var=tk.IntVar(value=0)
        self.rs_preview_spin=ttk.Spinbox(ctr,from_=0,to=0,width=6,textvariable=self.rs_preview_frame_var,
                                         command=self.rs_preview_render)
        self.rs_preview_spin.pack(side='left',padx=(3,8))
        self.rs_preview_frame_var.trace_add('write',lambda *_: self.rs_preview_render_safe())

        canvas_wrap=ttk.Frame(right); canvas_wrap.pack(fill='both',expand=True,padx=6,pady=6)
        self.rs_preview_canvas=tk.Canvas(canvas_wrap,bg=self.ui['canvas'],highlightthickness=0)
        self.rs_preview_canvas.grid(row=0,column=0,sticky='nsew')
        pys=ttk.Scrollbar(canvas_wrap,orient='vertical',command=self.rs_preview_canvas.yview)
        pxs=ttk.Scrollbar(canvas_wrap,orient='horizontal',command=self.rs_preview_canvas.xview)
        pys.grid(row=0,column=1,sticky='ns'); pxs.grid(row=1,column=0,sticky='ew')
        self.rs_preview_canvas.configure(yscrollcommand=pys.set,xscrollcommand=pxs.set)
        canvas_wrap.rowconfigure(0,weight=1); canvas_wrap.columnconfigure(0,weight=1)

        ttk.Label(right,textvariable=self.rs_preview_info,justify='left',wraplength=430).pack(fill='x',padx=8,pady=(0,8))

        prompt_box=ttk.LabelFrame(right,text='Sprite Sheet Prompt Generator'); prompt_box.pack(fill='x',padx=6,pady=(0,8))
        pbar=ttk.Frame(prompt_box); pbar.pack(fill='x',padx=6,pady=(5,3))
        ttk.Button(pbar,text='Generate Prompt',command=self.rs_generate_sprite_sheet_prompt).pack(side='left')
        ttk.Button(pbar,text='Copy Prompt',command=self.rs_copy_sprite_sheet_prompt).pack(side='left',padx=5)
        ttk.Button(pbar,text='Save .txt',command=self.rs_save_sprite_sheet_prompt).pack(side='left')
        self.rs_sheet_prompt_text=tk.Text(prompt_box,height=9,wrap='word',font=('Consolas',9)); self.rs_sheet_prompt_text.pack(fill='x',padx=6,pady=(0,6))
        self.rs_generate_sprite_sheet_prompt()

        act=ttk.Frame(parent); act.pack(fill='x',padx=10,pady=(0,6))
        ttk.Button(act,text='Replace Same Path (safe)',command=self.rs_replace_same_path).pack(side='left')
        ttk.Button(act,text='Replace + Relink NpcRes',command=self.rs_replace_relink).pack(side='left',padx=6)
        ttk.Button(act,text='Open loose/extracted path',command=self.rs_open_related_folder).pack(side='left',padx=6)
        ttk.Label(parent,textvariable=self.rs_info_var,justify='left',wraplength=1120).pack(fill='x',padx=12,pady=(0,10))

    def rs_generate_sprite_sheet_prompt(self):
        if not hasattr(self,'rs_sheet_prompt_text'): return
        spr=self.rs_preview_spr; frames=int(spr['frames']) if spr else 15; fw=int(spr['width']) if spr else 145; fh=int(spr['height']) if spr else 128
        cols,rows=(5,3) if frames==15 else (max(1,int(math.ceil(math.sqrt(frames)))),0)
        if rows==0: rows=max(1,int(math.ceil(frames/float(cols))))
        sw,sh=fw*cols,fh*rows; ax=fw//2; ay=int(round(fh*78/128.0)); k=0; order=[]
        for r in range(rows):
            cells=[]
            for c in range(cols):
                if k<frames: cells.append('Frame %02d'%k); k+=1
            if cells: order.append('ROW %d: '%(r+1)+' | '.join(cells))
        prompt = SPRITE_SHEET_PROMPT_TEMPLATE.format(frames=frames,cols=cols,rows=rows,fw=fw,fh=fh,sw=sw,sh=sh,ax=ax,ay=ay,last=max(0,frames-1),order='\n'.join(order))
        self.rs_sheet_prompt_text.delete('1.0','end'); self.rs_sheet_prompt_text.insert('1.0',prompt)

    def rs_copy_sprite_sheet_prompt(self):
        if not hasattr(self,'rs_sheet_prompt_text'): return
        text=self.rs_sheet_prompt_text.get('1.0','end-1c'); self.clipboard_clear(); self.clipboard_append(text); self.update_idletasks(); self.rs_info_var.set('Sprite Sheet prompt đã copy vào clipboard.')

    def rs_save_sprite_sheet_prompt(self):
        if not hasattr(self,'rs_sheet_prompt_text'): return
        path=filedialog.asksaveasfilename(title='Save Sprite Sheet Prompt',defaultextension='.txt',filetypes=[('Text','*.txt'),('All files','*.*')],initialfile='JX_Ground_Aura_Sprite_Sheet_Prompt.txt')
        if path: Path(path).write_text(self.rs_sheet_prompt_text.get('1.0','end-1c'),encoding='utf-8'); self.rs_info_var.set(f'Đã lưu prompt: {path}')

    # ---------------- Persistent SPR Index Cache (Patch 02.2.1.9.2) ----------------
    def client_mapping_dir(self,create=False):
        client=Path(self.client_var.get().strip())
        p=client/'CLIENT_MAPPING'
        if create:p.mkdir(parents=True,exist_ok=True)
        return p

    def pal_index_db_path(self,create=False):
        return self.client_mapping_dir(create=create)/'spr_index.sqlite'

    def pal_cache_pak_signature(self,client,rows):
        names=sorted({str(r.get('pak_name','')).strip() for r in rows if r.get('pak_name')})
        sig=[]
        for name in names:
            p=None
            for c in (client/'data'/name,client/name):
                if c.exists():p=c;break
            if p is None:
                try:p=next((x for x in client.rglob('*.pak') if x.name.lower()==name.lower()),None)
                except Exception:p=None
            if p is None:
                sig.append((name,'',-1,-1));continue
            try:
                st=p.stat()
                sig.append((name,str(p.resolve()),int(st.st_size),
                            int(getattr(st,'st_mtime_ns',int(st.st_mtime*1000000000)))))
            except Exception:sig.append((name,str(p),-1,-1))
        raw=json.dumps(sig,ensure_ascii=False,separators=(',',':'))
        return hashlib.sha1(raw.encode('utf-8','replace')).hexdigest(),sig

    def pal_index_db_open(self,path):
        db=sqlite3.connect(str(path),timeout=15)
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA synchronous=NORMAL')
        db.execute('CREATE TABLE IF NOT EXISTS cache_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS spr_index(pak_name TEXT NOT NULL,elem_index TEXT NOT NULL,virtual_path TEXT NOT NULL,frames INTEGER NOT NULL,interval_ms INTEGER NOT NULL,mode TEXT NOT NULL,PRIMARY KEY(pak_name,elem_index,virtual_path))')
        db.execute('CREATE INDEX IF NOT EXISTS idx_spr_mode ON spr_index(mode)')
        db.commit()
        return db

    def pal_try_load_persistent_index(self,rows,client_text):
        try:
            client=Path(client_text)
            dbpath=self.pal_index_db_path(create=True)
            if not dbpath.exists():return False
            signature,_=self.pal_cache_pak_signature(client,rows)
            db=self.pal_index_db_open(dbpath)
            meta=dict(db.execute('SELECT key,value FROM cache_meta').fetchall())
            if meta.get('schema')!='1' or meta.get('pak_signature')!=signature or int(meta.get('row_count','-1'))!=len(rows):
                db.close();return False
            cached={}
            for pak,ei,vp,frames,interval_ms,mode in db.execute('SELECT pak_name,elem_index,virtual_path,frames,interval_ms,mode FROM spr_index'):
                cached[(pak,ei,vp)]={'frames':int(frames),'interval':int(interval_ms),'mode':mode}
            db.close()
            if len(cached)!=len(rows):return False
            static=[]; animation=[]
            for r in rows:
                key=(r.get('pak_name',''),str(r.get('elem_index','')),r.get('virtual_path',''))
                m=cached.get(key)
                if m is None:return False
                origkey=(r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path',''))
                self.pal_meta_cache[origkey]={'frames':m['frames'],'interval':m['interval']}
                (animation if m['mode']=='animation' else static).append(r)
            self.pal_static_rows=static; self.pal_animation_rows=animation; self.pal_unknown_rows=[]
            self.pal_classifier_done=True
            self.pal_info_var.set(f'DISK CACHE READY | Indexed {len(rows)} SPR | Static {len(static)} | Animation {len(animation)}')
            self.rtui_log_add(f'Persistent SPR index HIT: {dbpath} | rows={len(rows)} static={len(static)} animation={len(animation)}')
            return True
        except Exception as e:
            try:self.rtui_log_add('Persistent SPR index load skipped: '+str(e))
            except Exception:pass
            return False

    def pal_save_persistent_index(self,rows,client_text):
        try:
            client=Path(client_text); dbpath=self.pal_index_db_path(create=True)
            signature,sig_rows=self.pal_cache_pak_signature(client,rows)
            db=self.pal_index_db_open(dbpath); db.execute('DELETE FROM spr_index')
            batch=[]
            for r in rows:
                key=(r.get('pak_name',''),r.get('elem_index',''),r.get('virtual_path',''))
                m=self.pal_meta_cache.get(key)
                if not m:continue
                frames=int(m.get('frames',1) or 1); interval=int(m.get('interval',80) or 80)
                mode='animation' if frames>1 else 'static'
                batch.append((key[0],str(key[1]),key[2],frames,interval,mode))
            db.executemany('INSERT OR REPLACE INTO spr_index(pak_name,elem_index,virtual_path,frames,interval_ms,mode) VALUES(?,?,?,?,?,?)',batch)
            meta={'schema':'1','client_root':str(client.resolve()),'pak_signature':signature,
                  'row_count':str(len(rows)),'indexed_count':str(len(batch)),
                  'built_at':datetime.now().isoformat(timespec='seconds'),
                  'pak_signature_detail':json.dumps(sig_rows,ensure_ascii=False)}
            db.executemany('INSERT OR REPLACE INTO cache_meta(key,value) VALUES(?,?)',meta.items())
            db.commit();db.close()
            self.rtui_log_add(f'Persistent SPR index SAVED: {dbpath} | rows={len(batch)}')
            return True
        except Exception as e:
            try:self.rtui_log_add('Persistent SPR index save failed: '+str(e))
            except Exception:pass
            return False

    def pal_rebuild_persistent_cache(self):
        try:
            db=self.pal_index_db_path(create=True)
            for p in (db,Path(str(db)+'-wal'),Path(str(db)+'-shm')):
                try:
                    if p.exists():p.unlink()
                except Exception:pass
            self.pal_meta_cache.clear(); self.pal_classifier_done=False
            self.pal_info_var.set('Persistent cache cleared. Rebuilding from PAK...')
            self.pal_start_classifier(force=True,ignore_disk_cache=True)
        except Exception as e:
            messagebox.showerror('SPR Palette Cache','Không rebuild được cache:\n'+str(e))

    def rs_output(self):
        client=Path(self.client_var.get().strip())
        if str(self.client_var.get().strip()):
            p=client/'CLIENT_MAPPING'
            try:
                if self.output_var.get().strip()!=str(p):self.output_var.set(str(p))
            except Exception:pass
            return p
        return Path(self.output_var.get().strip())

    def rs_client(self):
        return Path(self.client_var.get().strip())

    def rs_load_index(self):
        out=self.rs_output()
        idx=out/'10_KNOWN_PATH_TO_PAK.tsv'
        if not idx.exists():
            messagebox.showwarning('Resource Studio','Chưa có 10_KNOWN_PATH_TO_PAK.tsv. Hãy scan V4.3 trước.'); return
        refs_file=out/'27_RESOURCE_REFERENCE_GRAPH.tsv'
        self.rs_refs=defaultdict(list)
        if refs_file.exists():
            with refs_file.open('r',encoding='utf-8',errors='replace',newline='') as f:
                for r in csv.DictReader(f,delimiter='\t'):
                    self.rs_refs[normalize_virtual_path(r.get('virtual_path',''))].append(r)
        rows=[]
        with idx.open('r',encoding='utf-8',errors='replace',newline='') as f:
            for r in csv.DictReader(f,delimiter='\t'):
                vp=normalize_virtual_path(r.get('virtual_path',''))
                if not vp.lower().endswith('.spr') or not r.get('pak_name'):
                    continue
                r['virtual_path']=vp
                rows.append(r)
        # One row per exact path + pak occurrence; preserve duplicate PAK copies.
        self.rs_rows=rows
        self.rs_apply_filter()
        if hasattr(self,'pal_rows'):
            self.pal_rows=list(rows)
            if getattr(self,'pal_window',None) is not None:self.pal_start_classifier(force=False)
            self.pal_apply_filter()
        self.rs_info_var.set(f'Loaded {len(rows)} SPR path→PAK rows; {sum(len(v) for v in self.rs_refs.values())} reverse NpcRes references.')

    def rs_apply_filter(self):
        q=self.rs_search_var.get().strip().lower()
        rows=[r for r in self.rs_rows if not q or q in r.get('virtual_path','').lower() or q in r.get('pak_name','').lower()]
        self.rs_filtered=rows[:10000]
        self.rs_tree.delete(*self.rs_tree.get_children())
        for i,r in enumerate(self.rs_filtered):
            vp=normalize_virtual_path(r.get('virtual_path',''))
            self.rs_tree.insert('', 'end', iid=str(i), values=(
                vp,r.get('pak_name',''),r.get('pak_order',''),r.get('method',''),
                r.get('frame',''),len(self.rs_refs.get(vp,[]))
            ))
        if len(rows)>10000:
            self.rs_info_var.set(f'{len(rows)} matches; showing first 10,000. Narrow Search.')

    def rs_selected(self):
        sel=self.rs_tree.selection()
        if not sel:return None
        try:return self.rs_filtered[int(sel[0])]
        except Exception:return None

    def rs_selection_changed(self):
        r=self.rs_selected()
        if not r:return
        vp=normalize_virtual_path(r['virtual_path'])
        refs=self.rs_refs.get(vp,[])
        self.rs_info_var.set(
            f"{vp}\nHash={r.get('uId_hex','')} | {r.get('pak_name','')} order={r.get('pak_order','')} "
            f"entry={r.get('elem_index','')} | {r.get('method','')} frame={r.get('frame','')} | NpcRes refs={len(refs)}"
        )
        self.rs_preview_load_selected()
        # Keep Real-Time UI Designer resource in sync only when user has already initialized the tab.
        if hasattr(self,'rtui_resource_info'):
            try:self.rtui_resource_info.set('Resource Studio selected: '+vp+' | bấm Use Selected Resource để arm drag/drop.')
            except Exception:pass

    def rs_preview_stop(self):
        self.rs_preview_playing=False
        try:self.rs_preview_play_btn.configure(text='Play')
        except Exception:pass
        if self.rs_preview_after:
            try:self.root.after_cancel(self.rs_preview_after)
            except Exception:pass
            self.rs_preview_after=None

    def rs_preview_load_selected(self):
        r=self.rs_selected()
        if not r:return
        self.rs_preview_stop()
        self.rs_preview_token+=1
        token=self.rs_preview_token
        self.rs_preview_info.set('Đang đọc SPR trực tiếp từ PAK...')
        self.rs_preview_canvas.delete('all')
        try:
            pak,entry=self.rs_entry(r)
            data,detail=native_read_xpack_entry_bytes(pak,entry)
            if token!=self.rs_preview_token:return
            self.rs_preview_spr=parse_spr_bytes(data,f"PAK://{r.get('pak_name')}#{r.get('elem_index')}::{r.get('virtual_path')}")
            self.rs_preview_cache={}
            self.rs_preview_frame=0
            self.rs_preview_frame_var.set(0)
            self.rs_preview_spin.configure(to=max(0,self.rs_preview_spr['frames']-1))
            self.rs_preview_render()
        except Exception as e:
            self.rs_preview_spr=None
            self.rs_preview_info.set(f'Preview error: {e}')

    def rs_preview_render_safe(self):
        try:self.rs_preview_render()
        except Exception:pass

    def rs_preview_render(self):
        s=self.rs_preview_spr
        if not s:return
        try:i=int(self.rs_preview_frame_var.get())
        except Exception:i=0
        i=max(0,min(i,s['frames']-1))
        self.rs_preview_frame=i
        if i not in self.rs_preview_cache:
            fr=decode_spr_frame(s,i)
            self.rs_preview_cache[i]=(fr,frame_to_tk_photo(fr,1))
        fr,img=self.rs_preview_cache[i]
        self.rs_preview_photo=img
        c=self.rs_preview_canvas
        c.delete('all')
        cw=max(c.winfo_width(),fr['width']+20); ch=max(c.winfo_height(),fr['height']+20)
        x=max(10,(cw-fr['width'])//2); y=max(10,(ch-fr['height'])//2)
        c.create_image(x,y,image=img,anchor='nw')
        c.configure(scrollregion=(0,0,max(cw,x+fr['width']+10),max(ch,y+fr['height']+10)))
        self.rs_preview_info.set(
            f"{Path(str(s.get('source_name',s['path']))).name} | Canvas {s['width']}×{s['height']} | "
            f"Frames {s['frames']} | Directions {s['directions']} | Interval {s['interval']} ms | Colors {s['colors']}\n"
            f"Frame {i}: {fr['width']}×{fr['height']} offset=({fr['offset_x']},{fr['offset_y']})"
        )

    def rs_preview_step(self,delta):
        s=self.rs_preview_spr
        if not s:return
        self.rs_preview_stop()
        i=(self.rs_preview_frame+delta)%s['frames']
        self.rs_preview_frame_var.set(i)

    def rs_preview_toggle(self):
        if not self.rs_preview_spr:return
        if self.rs_preview_playing:
            self.rs_preview_stop()
        else:
            self.rs_preview_playing=True
            self.rs_preview_play_btn.configure(text='Stop')
            # Pre-decode all frames once. Subsequent loop is only image switching.
            try:
                for i in range(self.rs_preview_spr['frames']):
                    if i not in self.rs_preview_cache:
                        fr=decode_spr_frame(self.rs_preview_spr,i)
                        self.rs_preview_cache[i]=(fr,frame_to_tk_photo(fr,1))
            except Exception as e:
                self.rs_preview_stop(); self.rs_preview_info.set(f'Preview cache error: {e}'); return
            self.rs_preview_tick()

    def rs_preview_tick(self):
        if not self.rs_preview_playing or not self.rs_preview_spr:return
        i=(self.rs_preview_frame+1)%self.rs_preview_spr['frames']
        self.rs_preview_frame_var.set(i)
        delay=max(20,int(self.rs_preview_spr.get('interval') or 40))
        self.rs_preview_after=self.root.after(delay,self.rs_preview_tick)

    def rs_find_pak(self,pak_name):
        client=self.rs_client()
        direct=client/'data'/pak_name
        if direct.exists():return direct
        direct=client/pak_name
        if direct.exists():return direct
        low=pak_name.lower()
        for p in client.rglob('*.pak'):
            if p.name.lower()==low:return p
        return None

    def rs_entry(self,r):
        pak=self.rs_find_pak(r.get('pak_name',''))
        if not pak:raise FileNotFoundError(f"Không tìm thấy {r.get('pak_name','')} trong client")
        parsed=parse_xpack(pak)
        if not parsed.get('valid'):raise ValueError(f"PAK invalid: {parsed.get('error')}")
        idx=int(r.get('elem_index','-1'))
        if idx<0 or idx>=len(parsed['entries']):raise IndexError(f'elem_index {idx} out of range')
        return pak, parsed['entries'][idx]

    def viewer_load_memory(self,raw,source_name):
        try:
            self.viewer_stop_play()
            self.viewer_spr=parse_spr_bytes(raw,source_name)
            self.viewer_path_var.set(source_name); self.viewer_frame_var.set(0)
            self.viewer_decoded_cache={}; self.viewer_photo_cache={}
            self.viewer_spin.configure(to=max(0,self.viewer_spr['frames']-1))
            self.notebook.select(self.viewer_tab); self.viewer_render()
        except Exception as e:
            messagebox.showerror('Resource Studio',f'Không đọc được SPR từ PAK:\n{e}')

    def rs_view_pak(self):
        r=self.rs_selected()
        if not r:return
        try:
            pak,entry=self.rs_entry(r)
            data,detail=native_read_xpack_entry_bytes(pak,entry)
            src=f"PAK://{r.get('pak_name')}#{r.get('elem_index')}::{r.get('virtual_path')}"
            self.viewer_load_memory(data,src)
        except Exception as e:
            messagebox.showerror('Resource Studio',f'View from PAK thất bại:\n{e}')

    def rs_reference_text(self,vp):
        refs=self.rs_refs.get(normalize_virtual_path(vp),[])
        lines=[]
        for x in refs:
            lines.append(
                f"{x.get('npc_name','')} | part={x.get('section_name','')} | table={x.get('resource_table_path','')} "
                f"| equip={x.get('equip_index','')} {x.get('equip_name','')} | action={x.get('action_index','')} {x.get('action_name','')}"
            )
        return lines

    def rs_extract_with_txt(self):
        r=self.rs_selected()
        if not r:return
        outdir=filedialog.askdirectory(title='Chọn thư mục Extract SPR + TXT')
        if not outdir:return
        try:
            pak,entry=self.rs_entry(r)
            data,detail=native_read_xpack_entry_bytes(pak,entry)
            vp=normalize_virtual_path(r['virtual_path'])
            dst=Path(outdir)/Path(vp.replace('\\','/')).name
            dst.write_bytes(data)
            refs=self.rs_reference_text(vp)
            side=dst.with_suffix(dst.suffix+'.txt')
            meta=[
                '[JX RESOURCE INFO]',
                f'VirtualPath={vp}',
                f'Hash={r.get("uId_hex","")}',
                f'PakName={r.get("pak_name","")}',
                f'PakOrder={r.get("pak_order","")}',
                f'ElemIndex={r.get("elem_index","")}',
                f'Compression={r.get("method","")}',
                f'FrameCompressed={r.get("frame","")}',
                f'OriginalSize={r.get("original_size","")}',
                f'Detail={detail}',
                '',
                '[NpcRes References]'
            ] + (refs if refs else ['(none indexed)'])
            write_text_safe(side,'\n'.join(meta))
            messagebox.showinfo('Resource Studio',f'Đã extract:\n{dst}\n{side}')
        except Exception as e:
            messagebox.showerror('Resource Studio',f'Extract thất bại:\n{e}')

    def rs_show_refs(self):
        r=self.rs_selected()
        if not r:return
        vp=normalize_virtual_path(r['virtual_path']); refs=self.rs_refs.get(vp,[])
        win=tk.Toplevel(self.root); win.title('NpcRes References'); win.geometry('1000x500')
        t=tk.Text(win,wrap='none',font=('Consolas',9)); t.pack(fill='both',expand=True)
        t.insert('end',vp+'\n'+'='*100+'\n')
        if not refs:t.insert('end','Không có exact NpcRes reference trong index.\n')
        for i,x in enumerate(refs,1):
            t.insert('end',
                f"[{i}] NPC={x.get('npc_name','')} CharacterType={x.get('character_type','')}\n"
                f"    Part={x.get('section_name','')} ResourceTable={x.get('resource_table_path','')}\n"
                f"    Equip={x.get('equip_index','')} {x.get('equip_name','')} | Action={x.get('action_index','')} {x.get('action_name','')}\n"
                f"    RawSPR={x.get('raw_spr','')} | Exact={x.get('virtual_path','')}\n\n")
        t.configure(state='disabled')

    def _backup_files(self,files_to_backup):
        out=self.rs_output()
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        root=out/'resource_backups'/stamp
        client=self.rs_client()
        for p in files_to_backup:
            try: rel=p.relative_to(client)
            except Exception: rel=Path(p.name)
            dst=root/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dst)
        return root

    def rs_replace_same_path(self):
        r=self.rs_selected()
        if not r:return
        newfile=filedialog.askopenfilename(title='Chọn SPR mới',filetypes=[('JX Sprite','*.spr')])
        if not newfile:return
        try:
            # validate before touching client
            parse_spr_file(Path(newfile))
            vp=normalize_virtual_path(r['virtual_path'])
            rel=vp.lstrip('\\').replace('\\',os.sep)
            dst=self.rs_client()/rel
            backup=None
            if dst.exists(): backup=self._backup_files([dst])
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(newfile,dst)
            report=self.rs_output()/'REPLACE_LAST_REPORT.txt'
            write_text_safe(report,
                f"Mode=SamePath\nVirtualPath={vp}\nNewFile={newfile}\nDestination={dst}\n"
                f"Backup={backup or '(no previous loose file)'}\n"
                "NpcResChanged=NO\n"
                "Note=Runtime winner still depends on g_SetPakFileMode.\n")
            messagebox.showinfo('Resource Studio',
                f'Đã đặt SPR mới theo SAME PATH:\n{dst}\n\nNpcRes không đổi.\nBackup: {backup or "(không có loose cũ)"}')
        except Exception as e:
            messagebox.showerror('Resource Studio',f'Replace Same Path thất bại:\n{e}')

    def rs_replace_relink(self):
        r=self.rs_selected()
        if not r:return
        vp_old=normalize_virtual_path(r['virtual_path'])
        refs=self.rs_refs.get(vp_old,[])
        if not refs:
            messagebox.showwarning('Resource Studio','Không có exact NpcRes references để relink an toàn.'); return
        newfile=filedialog.askopenfilename(title='Chọn SPR mới',filetypes=[('JX Sprite','*.spr')])
        if not newfile:return
        try: parse_spr_file(Path(newfile))
        except Exception as e:
            messagebox.showerror('Resource Studio',f'SPR mới không hợp lệ:\n{e}'); return
        newname=Path(newfile).name
        if not messagebox.askyesno('Replace + Relink',
            f'Sẽ backup và sửa {len(refs)} exact reference(s) của:\n{vp_old}\n\n'
            f'thành filename: {newname}\n\nTiếp tục?'): return
        client=self.rs_client()
        affected=[]
        for x in refs:
            rp=x.get('resource_table_path','')
            p=client/Path(rp.replace('/',os.sep))
            if p.exists() and p not in affected: affected.append(p)
        try:
            backup=self._backup_files(affected)
            changes=[]
            for p in affected:
                raw=p.read_bytes()
                done=False
                for enc in ('gbk','cp936','utf-8-sig','utf-8','latin-1'):
                    try: s=raw.decode(enc)
                    except Exception: continue
                    old_names=set()
                    for x in refs:
                        if x.get('resource_table_path','').replace('\\','/').lower()==p.relative_to(client).as_posix().lower():
                            if x.get('raw_spr'): old_names.add(x['raw_spr'])
                    s2=s
                    local=0
                    for old in sorted(old_names,key=len,reverse=True):
                        # exact cell/token replacement, case-insensitive, not broad substring in longer filename
                        pat=re.compile(r'(?i)(?<![A-Za-z0-9_.-])'+re.escape(old)+r'(?![A-Za-z0-9_.-])')
                        s2,n=pat.subn(newname,s2); local+=n
                    if local:
                        p.write_bytes(s2.encode(enc))
                        changes.append((p,local,enc)); done=True
                    break
                if not done:
                    changes.append((p,0,'NO_CHANGE'))
            # place new loose SPR at same ResFilePath folder, but new filename
            old_rel=vp_old.lstrip('\\').replace('\\',os.sep)
            new_dst=(client/old_rel).with_name(newname)
            new_dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(newfile,new_dst)
            report=self.rs_output()/'REPLACE_LAST_REPORT.txt'
            lines=[
                'Mode=Replace+Relink',f'OldVirtualPath={vp_old}',f'NewFile={newfile}',f'NewDestination={new_dst}',
                f'Backup={backup}',f'ExpectedRefs={len(refs)}','',
                '[Patched Files]'
            ]+[f'{p} | replacements={n} | encoding={enc}' for p,n,enc in changes]
            write_text_safe(report,'\n'.join(lines))
            total=sum(n for _,n,_ in changes)
            messagebox.showinfo('Resource Studio',
                f'Relink hoàn tất.\nPatched exact tokens: {total}\nNew SPR: {new_dst}\nBackup: {backup}\n\nHãy scan lại để verification.')
        except Exception as e:
            messagebox.showerror('Resource Studio',f'Relink thất bại:\n{e}')

    def rs_open_related_folder(self):
        r=self.rs_selected()
        if not r:return
        vp=normalize_virtual_path(r['virtual_path'])
        loose=self.rs_client()/vp.lstrip('\\').replace('\\',os.sep)
        extracted=self.rs_output()/'extracted_character'/vp.lstrip('\\').replace('\\',os.sep)
        target=loose.parent if loose.exists() else extracted.parent if extracted.exists() else self.rs_output()
        try:os.startfile(target)
        except Exception as e:messagebox.showerror('Resource Studio',str(e))

    def _scan_disk_log(self,msg):
        path=self.scan_disk_log_path
        if not path:return
        try:
            line=f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {display_safe(msg)}\n"
            with self.scan_disk_log_lock:
                with open(path,'a',encoding='utf-8',errors='replace') as f:
                    f.write(line); f.flush()
        except Exception:
            pass

    def _scan_touch(self,phase=None,progress=None):
        now=time.time()
        self.scan_last_activity=now
        if phase is not None:self.scan_phase=str(phase)
        if progress is not None:
            try:self.scan_last_progress=float(progress)
            except Exception:pass

    def _scan_ui_post(self,kind,*args):
        try:self.scan_ui_queue.put_nowait((kind,args))
        except Exception:pass

    def _scan_schedule_ui_poll(self):
        try:
            if self.scan_poll_after is None:
                self.scan_poll_after=self.root.after(100,self._scan_poll_ui)
        except Exception:
            pass

    def _scan_poll_ui(self):
        self.scan_poll_after=None
        try:
            for _ in range(200):
                try:kind,args=self.scan_ui_queue.get_nowait()
                except queue.Empty:break
                if kind=='log':
                    msg=args[0]
                    self.log_text.insert("end",display_safe(msg)+"\n")
                    self.log_text.see("end")
                elif kind=='progress':
                    self.progress_var.set(args[0])
                elif kind=='status':
                    self.status_var.set(args[0])
                elif kind=='done':
                    self._scan_finish_ui(bool(args[0]),str(args[1]) if len(args)>1 else '')
        except Exception:
            pass

        self._scan_update_watchdog()
        self._scan_schedule_ui_poll()

    def _scan_update_watchdog(self):
        th=self.scan_worker_thread
        if not th or not th.is_alive():
            if not th:
                self.scan_monitor_var.set('Worker: IDLE')
            return
        now=time.time()
        elapsed=max(0.0,now-self.scan_started_at)
        idle=max(0.0,now-self.scan_last_activity)
        state='RUNNING' if idle < 10 else ('BUSY' if idle < 30 else 'STALLED?')
        self.scan_monitor_var.set(
            f"Worker: {state} | phase={self.scan_phase} | "
            f"progress={self.scan_last_progress:.1f}% | "
            f"last activity={idle:.1f}s | elapsed={elapsed/60.0:.1f} min"
        )

        tick=int(elapsed)
        last=getattr(self,'_scan_last_heartbeat_tick',-999)
        if tick-last >= 5:
            self._scan_last_heartbeat_tick=tick
            self._scan_disk_log(
                f"HEARTBEAT worker_alive=1 phase={self.scan_phase} "
                f"progress={self.scan_last_progress:.1f}% "
                f"idle={idle:.1f}s elapsed={elapsed:.1f}s"
            )

    def _scan_ui_progress(self,value,phase=None):
        try:value=float(value)
        except Exception:value=0.0
        self._scan_touch(phase=phase,progress=value)
        self._scan_ui_post('progress',value)

    def _scan_ui_status(self,text,phase=None):
        self._scan_touch(phase=phase)
        self._scan_ui_post('status',text)

    def _scan_check_cancel(self):
        if self.scan_cancel_event.is_set():
            raise RuntimeError('__JX_SCAN_CANCELLED__')

    def log(self,msg):
        self._scan_touch()
        self._scan_disk_log(msg)
        if threading.current_thread() is threading.main_thread():
            self.log_text.insert("end",display_safe(msg)+"\n")
            self.log_text.see("end")
        else:
            self._scan_ui_post('log',msg)

    def cancel_scan(self):
        th=self.scan_worker_thread
        if not th or not th.is_alive():
            return
        self.scan_cancel_event.set()
        self.status_var.set('Đang yêu cầu hủy scan...')
        self.scan_monitor_var.set('Worker: CANCEL REQUESTED')
        self._scan_disk_log('CANCEL REQUESTED by user')

    def _scan_finish_ui(self,ok,message):
        self.scan_button.configure(state='normal')
        self.scan_cancel_button.configure(state='disabled')
        self.scan_worker_thread=None
        if ok:
            self.scan_monitor_var.set('Worker: COMPLETED')
            if message:
                messagebox.showinfo(APP_TITLE,message)
        else:
            if message=='__CANCELLED__':
                self.status_var.set('Scan đã hủy.')
                self.scan_monitor_var.set('Worker: CANCELLED')
            else:
                self.status_var.set('Scan lỗi.')
                self.scan_monitor_var.set('Worker: ERROR')
                if message:
                    messagebox.showerror(APP_TITLE,message)


    def choose_client(self):
        p=filedialog.askdirectory(title="Chọn thư mục client JX")
        if p:
            self.client_var.set(p)
            mapping=Path(p)/'CLIENT_MAPPING'
            self.output_var.set(str(mapping))
            try: mapping.mkdir(parents=True,exist_ok=True)
            except Exception as e:
                messagebox.showwarning(APP_TITLE,'Không thể tạo CLIENT_MAPPING:\n'+str(e))

    def choose_output(self):
        p=filedialog.askdirectory(title="Chọn thư mục mapping / kết quả")
        if p: self.output_var.set(p)

    def choose_existing_scan(self):
        """Reuse a completed scanner mapping folder without running the expensive scan again."""
        p=filedialog.askdirectory(title='Chọn folder JX_CLIENT_MAPPING đã scan trước đó')
        if not p:
            return
        out=Path(p)
        required=out/'10_KNOWN_PATH_TO_PAK.tsv'
        stats_path=out/'07_STATS.json'
        if not required.exists():
            messagebox.showerror(APP_TITLE,
                'Folder này chưa có 10_KNOWN_PATH_TO_PAK.tsv.\n'
                'Hãy chọn đúng folder mapping đã scan hoàn tất.')
            return
        self.output_var.set(str(out))
        # Recover the original client root from scan metadata when available.
        if stats_path.exists():
            try:
                stats=json.loads(stats_path.read_text(encoding='utf-8',errors='replace'))
                cr=str(stats.get('client_root','')).strip()
                if cr and Path(cr).exists():
                    self.client_var.set(cr)
            except Exception:
                pass
        self.status_var.set('Đã nạp mapping có sẵn — không cần scan lại.')
        self.log(f'USE EXISTING MAPPING: {out}')
        try:
            self.rs_load_index()
        except Exception as e:
            self.log(f'WARN load Resource Studio index: {e}')
        messagebox.showinfo(APP_TITLE,
            'Đã dùng mapping đã scan trước đó.\n\n'
            'Bạn có thể vào Resource Studio / SPR Builder ngay, không cần bấm Quét.')

    def open_output(self):
        p=self.output_var.get().strip()
        if p and Path(p).exists(): os.startfile(p)
        else: messagebox.showwarning(APP_TITLE,"Thư mục kết quả chưa tồn tại.")

    def scan(self):
        if self.scan_worker_thread and self.scan_worker_thread.is_alive():
            messagebox.showwarning(APP_TITLE,'Scanner đang chạy.')
            return

        client=Path(self.client_var.get().strip())
        if not client.exists() or not client.is_dir():
            messagebox.showerror(APP_TITLE,"Thư mục client không hợp lệ."); return
        output=client/'CLIENT_MAPPING'
        self.output_var.set(str(output))

        try:output.mkdir(parents=True,exist_ok=True)
        except Exception as e:
            messagebox.showerror(APP_TITLE,f"Không tạo được thư mục kết quả:\n{e}"); return

        self.scan_option_hash_all=bool(self.hash_all_var.get())
        self.scan_option_scan_text=bool(self.scan_text_var.get())
        self.scan_option_native_extract=bool(self.native_extract_var.get())

        self.scan_cancel_event.clear()
        self.scan_started_at=time.time()
        self.scan_last_activity=self.scan_started_at
        self.scan_last_progress=0.0
        self.scan_phase='STARTING'
        self._scan_last_heartbeat_tick=-999
        self.scan_disk_log_path=output/'JX_SCANNER_LIVE.log'

        try:
            self.scan_disk_log_path.write_text(
                f"JX Workshop Scanner Live Log\n"
                f"Started: {datetime.now().isoformat(timespec='seconds')}\n"
                f"Client: {client}\nOutput: {output}\n\n",
                encoding='utf-8'
            )
        except Exception:
            pass

        self.log_text.delete("1.0","end")
        self.progress_var.set(0)
        self.status_var.set("Đang quét v4.3...")
        self.scan_monitor_var.set('Worker: STARTING')
        self.scan_button.configure(state='disabled')
        self.scan_cancel_button.configure(state='normal')

        self.scan_worker_thread=threading.Thread(
            target=self._scan_worker_entry,
            args=(client,output),
            name='JXScannerWorker',
            daemon=True
        )
        self.scan_worker_thread.start()
        self._scan_disk_log(f'WORKER START pid={os.getpid()} thread={self.scan_worker_thread.name}')

    def _scan_worker_entry(self,client,output):
        try:
            self._scan_worker(client,output)
        except RuntimeError as e:
            if str(e)=='__JX_SCAN_CANCELLED__':
                self._scan_disk_log('SCAN CANCELLED cleanly')
                self._scan_ui_post('done',False,'__CANCELLED__')
            else:
                import traceback
                tb=traceback.format_exc()
                self._scan_disk_log('SCAN ERROR: '+repr(e))
                self._scan_disk_log(tb)
                self._scan_ui_post('log',tb)
                self._scan_ui_post('done',False,f'Scanner gặp lỗi:\n{e}\n\nChi tiết đã ghi vào JX_SCANNER_LIVE.log')
        except Exception as e:
            import traceback
            tb=traceback.format_exc()
            self._scan_disk_log('SCAN FATAL ERROR: '+repr(e))
            self._scan_disk_log(tb)
            self._scan_ui_post('log',tb)
            self._scan_ui_post('done',False,f'Scanner gặp lỗi:\n{e}\n\nChi tiết đã ghi vào JX_SCANNER_LIVE.log')

    def _scan_worker(self,client,output):
        self._scan_check_cancel()
        errors=[]; ext_counter=Counter(); all_files=[]; loose_paths=set(); known_paths=set(); text_ref_sources=defaultdict(set)
        pak_files=[]; tree=[str(client.resolve())]

        self.log("[1/9] Quét client, tree, manifest và path ứng viên...")
        for current_root,dirs,files in os.walk(client):
            self._scan_check_cancel()
            dirs[:]=sorted(d for d in dirs if d.lower() not in DEFAULT_EXCLUDED_DIR_NAMES)
            current=Path(current_root); rel_dir=current.relative_to(client); indent="    "*len(rel_dir.parts)
            if rel_dir.parts: tree.append(f"{indent}[DIR] {display_safe(rel_dir.as_posix())}/")
            for fname in sorted(files):
                self._scan_check_cancel()
                p=current/fname
                try: rel=p.relative_to(client); rels=rel.as_posix(); size=p.stat().st_size
                except Exception as e: errors.append(f"{p}: {e}"); continue
                ext=p.suffix.lower(); ext_counter[ext or "[no_ext]"]+=1; tree.append(f"{indent}    {display_safe(fname)}")
                digest=sha1_file(p) if (self.scan_option_hash_all or ext in HASH_EXTENSIONS) else ""
                all_files.append((rels,ext,size,digest))
                vp=normalize_virtual_path(rels)
                known_paths.add(vp)
                if ext==".spr": loose_paths.add(vp)
                if ext==".pak": pak_files.append(p)
                if self.scan_option_scan_text and ext in TEXT_EXTENSIONS:
                    text,enc=safe_read_text(p)
                    if text is not None:
                        for token in collect_resource_tokens(text):
                            known_paths.add(token); text_ref_sources[token].add(rels)
        write_text_safe(output/"00_CLIENT_TREE.txt","\n".join(tree))
        with open(output/"01_FILE_MANIFEST.tsv","w",encoding="utf-8",errors="backslashreplace",newline="") as f:
            f.write("relative_path\textension\tsize_bytes\tsha1\n")
            for r in sorted(all_files): f.write("\t".join(map(display_safe,r))+"\n")
        self._scan_ui_progress(20,'FILE_SCAN')

        self.log("[2/9] Đọc package.ini theo KPakList::Open...")
        ini_path,pkg_path,pkg_order,pkg_note=extract_package_ini(client)
        order_by_name={name.lower():idx for idx,name in pkg_order}
        # basename lookup for config paths that don't resolve exactly
        by_basename=defaultdict(list)
        for p in pak_files: by_basename[p.name.lower()].append(p)
        ordered_paks=[]; used=set()
        for idx,name in pkg_order:
            expected=resolve_pak_path(client,pkg_path,name)
            actual=expected if expected.exists() else (by_basename.get(Path(name).name.lower(),[None])[0])
            if actual and actual.exists():
                ordered_paks.append((idx,name,actual)); used.add(str(actual.resolve()).lower())
            else:
                ordered_paks.append((idx,name,None))
        extra_index=(max([x[0] for x in ordered_paks],default=-1)+1)
        for p in sorted(pak_files):
            if str(p.resolve()).lower() not in used:
                ordered_paks.append((extra_index,p.name,p)); extra_index+=1
        self.log(f"  package.ini: {ini_path if ini_path else 'NOT FOUND'}; configured={len(pkg_order)}; discovered={len(pak_files)}")
        self._scan_ui_progress(28,'PACKAGE_INI')

        self.log("[3/9] Parse header + index của từng XPack...")
        parsed={}; pak_summary=[]; id_locations=defaultdict(list)
        for pos,(order_idx,config_name,p) in enumerate(ordered_paks):
            if p is None:
                pak_summary.append((order_idx,config_name,"",0,"MISSING",0,0,0,0,"configured pak not found")); continue
            xp=parse_xpack(p); parsed[p]=xp
            relp=display_safe(p.relative_to(client).as_posix()) if str(p).lower().startswith(str(client).lower()) else display_safe(str(p))
            status="VALID" if xp["valid"] else "INVALID/UNSUPPORTED"
            pak_summary.append((order_idx,config_name,relp,xp["size"],status,xp["count"],xp["index_offset"],xp["data_offset"],xp["crc32"],xp.get("error","") or ("unsorted_ids=%d"%xp.get("unsorted_ids",0))))
            if xp["valid"]:
                for elem_idx,e in enumerate(xp["entries"]):
                    id_locations[e[0]].append((order_idx,config_name,p,elem_idx,e))
            if pos % 3 == 0:
                self._scan_ui_progress(28+22*(pos+1)/max(len(ordered_paks),1),'XPACK_PARSE'); self._scan_check_cancel()
        with open(output/"08_XPACK_SUMMARY.tsv","w",encoding="utf-8",errors="backslashreplace",newline="") as f:
            f.write("pak_order\tconfig_name\tactual_path\tfile_size\tstatus\tentry_count\tindex_offset\tdata_offset\tcrc32\tnote\n")
            for r in pak_summary: f.write("\t".join(display_safe(x) for x in r)+"\n")

        self.log("[4/9] Xuất raw XPack index...")
        with open(output/"09_XPACK_INDEX.tsv","w",encoding="utf-8",errors="backslashreplace",newline="") as f:
            f.write("pak_order\tpak_name\telem_index\tuId_hex\tuId_dec\toffset\toriginal_size\tcompress_flag_hex\tmethod\tframe_compressed\tcompressed_size_field\n")
            for order_idx,config_name,p in ordered_paks:
                if not p or not parsed.get(p,{}).get("valid"): continue
                for i,e in enumerate(parsed[p]["entries"]):
                    uid,off,orig,flag,method,frame,comp=e
                    f.write(f"{order_idx}\t{display_safe(config_name)}\t{i}\t0x{uid:08X}\t{uid}\t{off}\t{orig}\t0x{flag:08X}\t{method}\t{int(frame)}\t{comp}\n")
        self._scan_ui_progress(55,'XPACK_PARSE')

        self.log("[5/9] Tính JX FileNameToId cho path ứng viên và dò qua Pak...")
        path_matches=[]
        for vp in sorted(known_paths):
            uid=jx_filename_to_id(vp); locs=sorted(id_locations.get(uid,[]),key=lambda x:x[0])
            sources=";".join(sorted(text_ref_sources.get(vp,set())))
            if locs:
                for rank,loc in enumerate(locs):
                    order_idx,pak_name,p,elem_idx,e=loc
                    path_matches.append((vp,uid,order_idx,pak_name,elem_idx,e[1],e[2],e[3],e[4],int(e[5]),e[6],rank==0,sources))
            else:
                path_matches.append((vp,uid,"","","","","","","","","",False,sources))
        with open(output/"10_KNOWN_PATH_TO_PAK.tsv","w",encoding="utf-8",errors="backslashreplace",newline="") as f:
            f.write("virtual_path\tuId_hex\tpak_order\tpak_name\telem_index\toffset\toriginal_size\tcompress_flag_hex\tmethod\tframe\tcompressed_size_field\tfirst_pak_winner\treference_sources\n")
            for r in path_matches:
                vp,uid,*rest=r
                vals=[vp,f"0x{uid:08X}"]+list(rest)
                if len(vals)>7 and isinstance(vals[7],int): vals[7]=f"0x{vals[7]:08X}"
                f.write("\t".join(display_safe(x) for x in vals)+"\n")
        self._scan_ui_progress(70,'PATH_MATCH')

        self.log("[6/9] Phân tích override loose ↔ Pak và trace nhân vật...")
        override_rows=[]; character_rows=[]
        for vp in sorted(known_paths):
            uid=jx_filename_to_id(vp); locs=sorted(id_locations.get(uid,[]),key=lambda x:x[0]); is_loose=vp in loose_paths
            first=locs[0] if locs else None
            pak_orders=",".join(str(x[0]) for x in locs); pak_names=";".join(x[1] for x in locs)
            if is_loose and locs:
                override_rows.append((vp,f"0x{uid:08X}",1,len(locs),pak_orders,pak_names,first[0],first[1],"Depends on g_SetPakFileMode: disk-first => loose wins; pak-first => first Pak wins"))
            low=vp.lower().replace("\\","/")
            if any(h in low for h in NPCRES_HINTS):
                character_rows.append((vp,f"0x{uid:08X}",int(is_loose),len(locs),pak_orders,pak_names,(first[0] if first else ""),(first[1] if first else ""),";".join(sorted(text_ref_sources.get(vp,set())))))
        with open(output/"11_OVERRIDE_ANALYSIS.tsv","w",encoding="utf-8",errors="backslashreplace",newline="") as f:
            f.write("virtual_path\tuId_hex\tloose_exists\tpak_copy_count\tpak_orders\tpak_names\tfirst_pak_order\tfirst_pak_name\tprecedence_note\n")
            for r in override_rows: f.write("\t".join(display_safe(x) for x in r)+"\n")
        with open(output/"12_CHARACTER_PAK_TRACE.tsv","w",encoding="utf-8",errors="backslashreplace",newline="") as f:
            f.write("virtual_path\tuId_hex\tloose_exists\tpak_copy_count\tpak_orders\tpak_names\tfirst_pak_order\tfirst_pak_name\treference_sources\n")
            for r in character_rows: f.write("\t".join(display_safe(x) for x in r)+"\n")

        with open(output/"13_DUPLICATE_PAK_IDS.tsv","w",encoding="utf-8",errors="backslashreplace",newline="") as f:
            f.write("uId_hex\tcopy_count\tpak_orders\tpak_names\telem_indexes\n")
            for uid,locs in sorted(id_locations.items()):
                if len(locs)>1:
                    locs=sorted(locs,key=lambda x:x[0])
                    f.write(f"0x{uid:08X}\t{len(locs)}\t{','.join(str(x[0]) for x in locs)}\t{';'.join(display_safe(x[1]) for x in locs)}\t{','.join(str(x[3]) for x in locs)}\n")
        self._scan_ui_progress(88,'NPCRES_PARSE')

        self.log("[7/9] Parse settings/npcres thành bảng cell + resource references...")
        npcres_cells=[]; npcres_refs=[]
        npcres_files=[]
        for rels,ext,size,digest in all_files:
            low=rels.lower().replace('\\','/')
            if 'settings/npcres/' in low and ext in TEXT_EXTENSIONS:
                npcres_files.append((rels,ext,size))
                fp=client / Path(rels.replace('/', os.sep))
                text,enc=safe_read_text(fp)
                if text is None:
                    continue
                for row_no,line in enumerate(text.splitlines(),1):
                    cells=split_legacy_row(line)
                    for col_no,cell in enumerate(cells,1):
                        val=cell.strip()
                        if not val: continue
                        npcres_cells.append((rels,enc or '',row_no,col_no,val))
                        # find every explicit resource extension in a cell, including bare filenames
                        for m in re.finditer(r'(?i)([^\t\r\n"\'<>|,;]+?\.(?:spr|txt|tab|ini|wav))\b', val):
                            tok=m.group(1).strip()
                            cands=resource_candidate_paths(tok, rels)
                            npcres_refs.append((rels,enc or '',row_no,col_no,val,tok,infer_character_part(rels,tok),';'.join(cands)))
        with open(output/'15_NPCRES_TABLE_CELLS.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write('source_file\tencoding\trow\tcolumn\tcell_value\n')
            for r in npcres_cells: f.write('\t'.join(display_safe(x) for x in r)+'\n')
        with open(output/'16_CHARACTER_RESOURCE_REFERENCES.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write('source_file\tencoding\trow\tcolumn\tcell_value\traw_resource\tinferred_part\tcandidate_virtual_paths\n')
            for r in npcres_refs: f.write('\t'.join(display_safe(x) for x in r)+'\n')
        self._scan_ui_progress(91,'CHARACTER_RESOLVE')

        self.log("[8/9] Resolve từng resource NPC/player sang loose/Pak/order...")
        resolver_rows=[]; player_rows=[]
        for src,enc,row_no,col_no,cell,tok,part,cands_joined in npcres_refs:
            cands=[x for x in cands_joined.split(';') if x]
            resolved_any=False
            for vp in cands:
                uid=jx_filename_to_id(vp)
                locs=sorted(id_locations.get(uid,[]),key=lambda x:x[0])
                is_loose=vp in loose_paths
                if not is_loose and not locs:
                    continue
                resolved_any=True
                first=locs[0] if locs else None
                state=('LOOSE+PAK' if is_loose and locs else 'LOOSE_ONLY' if is_loose else 'PAK_ONLY')
                row=(src,row_no,col_no,tok,part,vp,f'0x{uid:08X}',int(is_loose),len(locs),
                     ','.join(str(x[0]) for x in locs),';'.join(x[1] for x in locs),
                     first[0] if first else '',first[1] if first else '',state)
                resolver_rows.append(row)
                low=(src+' '+vp).lower().replace('\\','/')
                if ('spr/npcres/human/' in low or any(k in low for k in ('dnn','dsn','gsn','jsf','jsm','jsx','player','partfilename'))):
                    player_rows.append(row)
            if not resolved_any:
                vp=cands[0] if cands else ''
                uid=jx_filename_to_id(vp) if vp else 0
                row=(src,row_no,col_no,tok,part,vp,(f'0x{uid:08X}' if vp else ''),0,0,'','','','','UNRESOLVED')
                resolver_rows.append(row)
                low=(src+' '+tok).lower()
                if any(k in low for k in ('dnn','dsn','gsn','jsf','jsm','jsx','player','partfilename')):
                    player_rows.append(row)
        header='source_file\trow\tcolumn\traw_resource\tinferred_part\tresolved_virtual_path\tuId_hex\tloose_exists\tpak_copy_count\tpak_orders\tpak_names\tfirst_pak_order\tfirst_pak_name\tstate\n'
        with open(output/'17_CHARACTER_RESOLVER.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write(header)
            for r in resolver_rows: f.write('\t'.join(display_safe(x) for x in r)+'\n')
        with open(output/'18_PLAYER_RESOURCE_CANDIDATES.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write(header)
            seen=set()
            for r in player_rows:
                key=tuple(r)
                if key in seen: continue
                seen.add(key); f.write('\t'.join(display_safe(x) for x in r)+'\n')
        self.log('[9/13] Exact KNpcRes path resolver theo CharacterType/PartFileName/ResFilePath...')
        exact_rows,character_chains=find_npcres_exact_paths(client,loose_paths,id_locations)
        exact_header=('npc_name\tcharacter_type\tres_file_path\tpart_file_name\tsection_name\tpart_index\tresource_table\tequip_index\tequip_name\t'
                      'action_index\taction_name\traw_spr\texact_virtual_path\tuId_hex\tloose_exists\tpak_copy_count\tpak_orders\tpak_names\tfirst_pak_order\tfirst_pak_name\tstate\tkind_table\tresource_table_path\n')
        with open(output/'24_EXACT_CHARACTER_PATHS.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write(exact_header)
            for r in exact_rows:f.write('\t'.join(display_safe(x) for x in r)+'\n')
        with open(output/'25_CHARACTER_CHAIN_SUMMARY.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write('kind_table\trow\tnpc_name\tcharacter_type\tres_file_path\tpart_file_name\n')
            for r in character_chains:f.write('\t'.join(display_safe(x) for x in r)+'\n')
        exact_states=Counter(r[20] for r in exact_rows)
        # V4.3 reverse graph: exact SPR -> every KNpcRes caller.
        with open(output/'27_RESOURCE_REFERENCE_GRAPH.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write('virtual_path\tuId_hex\tnpc_name\tcharacter_type\tsection_name\tresource_table\tresource_table_path\tequip_index\tequip_name\taction_index\taction_name\traw_spr\tstate\n')
            for x in exact_rows:
                vals=(x[12],x[13],x[0],x[1],x[4],x[6],x[22],x[7],x[8],x[9],x[10],x[11],x[20])
                f.write('\t'.join(display_safe(v) for v in vals)+'\n')
        self.log(f"  Exact SPR rows: {len(exact_rows)}; resolved={len(exact_rows)-exact_states.get('UNRESOLVED',0)}; unresolved={exact_states.get('UNRESOLVED',0)}")
        self._scan_ui_progress(96,'NATIVE_EXTRACT')

        self.log('[10/13] Native PAK audit + lập targeted extraction plan...')
        compression_counts=Counter()
        for order_idx,config_name,pakp in ordered_paks:
            if not pakp or not parsed.get(pakp,{}).get('valid'): continue
            for e in parsed[pakp]['entries']:
                compression_counts[(e[4],int(e[5]))]+=1
        with open(output/'20_XPACK_COMPRESSION_AUDIT.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write('method\tframe_compressed\tentry_count\n')
            for (method,frame),cnt in sorted(compression_counts.items()):
                f.write(f'{method}\t{frame}\t{cnt}\n')

        # Unique first-winner PAK targets from resolved player rows + known character paths.
        plan_by_path={}
        resolver_iter=list(player_rows)
        for r in resolver_iter:
            vp=r[5]; state=r[-1]
            if not vp or state not in ('PAK_ONLY','LOOSE+PAK'): continue
            uid=jx_filename_to_id(vp); locs=sorted(id_locations.get(uid,[]),key=lambda x:x[0])
            if not locs: continue
            loc=locs[0]
            plan_by_path.setdefault(vp,(r[4],state,uid,loc))
        for r in character_rows:
            vp=r[0]; uid=jx_filename_to_id(vp); locs=sorted(id_locations.get(uid,[]),key=lambda x:x[0])
            if locs and vp not in plan_by_path:
                plan_by_path[vp]=('CHARACTER/NPCRES','PAK_MATCH',uid,locs[0])
        # V4.1 exact engine paths have priority and greatly expand targeted player resources.
        for r in exact_rows:
            vp=r[12]; state=r[20]
            if state not in ('PAK_ONLY','LOOSE+PAK') or not vp: continue
            uid=jx_filename_to_id(vp); locs=sorted(id_locations.get(uid,[]),key=lambda x:x[0])
            if locs: plan_by_path[vp]=(r[4], 'EXACT_'+state, uid, locs[0])

        extract_plan=[]
        for vp,(part,state,uid,loc) in sorted(plan_by_path.items()):
            order_idx,pak_name,pakp,elem_idx,e=loc
            extract_plan.append((vp,f'0x{uid:08X}',part,state,order_idx,pak_name,elem_idx,e[1],e[2],f'0x{e[3]:08X}',e[4],int(e[5]),e[6],str(pakp)))
        with open(output/'21_NATIVE_EXTRACT_PLAN.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write('virtual_path\tuId_hex\tinferred_part\tresolver_state\tpak_order\tpak_name\telem_index\toffset\toriginal_size\tcompress_flag_hex\tmethod\tframe\tcompressed_size\tpak_path\n')
            for r in extract_plan: f.write('\t'.join(display_safe(x) for x in r)+'\n')

        self.log(f"  Target PAK resources: {len(extract_plan)}")
        self.log("[11/13] Native targeted extraction theo XPackFile.cpp...")
        extract_results=[]; extract_root=output/'extracted_character'
        if self.scan_option_native_extract:
            if extract_root.exists(): shutil.rmtree(extract_root)
            extract_root.mkdir(parents=True,exist_ok=True)
            for i,r in enumerate(extract_plan):
                vp=r[0]; uid=jx_filename_to_id(vp); loc=sorted(id_locations.get(uid,[]),key=lambda x:x[0])[0]
                order_idx,pak_name,pakp,elem_idx,e=loc
                status,outrel,detail,esize=native_extract_xpack_entry(pakp,e,vp,extract_root)
                extract_results.append((vp,f'0x{uid:08X}',order_idx,pak_name,elem_idx,e[4],int(e[5]),e[2],e[6],status,esize,outrel,detail))
                if i and i%100==0:
                    self.log(f"  extracted {i}/{len(extract_plan)}...")
                    self._scan_check_cancel()
        else:
            for r in extract_plan:
                extract_results.append((r[0],r[1],r[4],r[5],r[6],r[10],r[11],r[8],r[12],'SKIPPED',0,'','Native extraction disabled by user'))
        with open(output/'22_NATIVE_EXTRACT_RESULTS.tsv','w',encoding='utf-8',errors='backslashreplace',newline='') as f:
            f.write('virtual_path\tuId_hex\tpak_order\tpak_name\telem_index\tmethod\tframe\toriginal_size\tcompressed_size\tstatus\textracted_size\toutput_relative\tdetail\n')
            for r in extract_results: f.write('\t'.join(display_safe(x) for x in r)+'\n')

        self.log("[12/13] Tạo report V4/V4.1, stats và folder upload...")
        valid_paks=sum(1 for x in parsed.values() if x.get("valid")); invalid_paks=sum(1 for x in parsed.values() if not x.get("valid"))
        matched_paths=sum(1 for vp in known_paths if id_locations.get(jx_filename_to_id(vp)))
        duplicate_ids=sum(1 for locs in id_locations.values() if len(locs)>1)
        stats={
            "app":APP_TITLE,"version":VERSION,"scan_time":datetime.now().isoformat(timespec="seconds"),
            "client_root":str(client.resolve()),"output_root":str(output.resolve()),"total_files":len(all_files),
            "pak_files_discovered":len(pak_files),"pak_entries_from_package_ini":len(pkg_order),"valid_xpack_files":valid_paks,
            "invalid_or_unsupported_paks":invalid_paks,"total_xpack_index_entries":sum(len(x.get("entries",[])) for x in parsed.values()),
            "known_virtual_paths":len(known_paths),"known_paths_found_in_paks":matched_paths,"loose_spr_files":len(loose_paths),
            "loose_paths_also_in_pak":len(override_rows),"character_trace_rows":len(character_rows),"duplicate_ids_across_paks":duplicate_ids,
            "npcres_text_files_parsed":len(npcres_files),"npcres_table_cells":len(npcres_cells),"npcres_resource_references":len(npcres_refs),"character_resolver_rows":len(resolver_rows),"player_resource_candidate_rows":len(player_rows),
            "exact_character_rows":len(exact_rows),"exact_character_resolved":sum(1 for x in exact_rows if x[20] != 'UNRESOLVED'),"exact_character_unresolved":sum(1 for x in exact_rows if x[20] == 'UNRESOLVED'),
            "native_extract_targets":len(extract_plan),"native_extract_ok":sum(1 for x in extract_results if x[9]=='OK'),"native_extract_failed_or_unsupported":sum(1 for x in extract_results if x[9] not in ('OK','SKIPPED')),
            "extensions":dict(sorted(ext_counter.items(),key=lambda x:(-x[1],x[0]))),"errors":len(errors)
        }
        write_text_safe(output/"07_STATS.json",json.dumps(stats,ensure_ascii=False,indent=2))
        if errors: write_text_safe(output/"99_ERRORS.txt","\n".join(display_safe(x) for x in errors))
        report=f"""# JX CLIENT SCANNER V2 REPORT\n\nGenerated: {datetime.now().isoformat(timespec='seconds')}\n\nClient: `{display_safe(client.resolve())}`\n\n## Pak/XPack\n\n- package.ini: `{display_safe(ini_path) if ini_path else 'NOT FOUND'}`\n- Package Path: `{display_safe(pkg_path)}`\n- Configured Pak entries: **{len(pkg_order)}**\n- Pak files discovered: **{len(pak_files)}**\n- Valid XPack: **{valid_paks}**\n- Invalid/unsupported: **{invalid_paks}**\n- Total XPack index entries: **{stats['total_xpack_index_entries']}**\n\n## Path matching\n\n- Known virtual paths: **{len(known_paths)}**\n- Known paths found by exact JX FileNameToId in Pak: **{matched_paths}**\n- Loose SPR: **{len(loose_paths)}**\n- Loose paths also present in at least one Pak: **{len(override_rows)}**\n- Character/NpcRes trace rows: **{len(character_rows)}**\n- IDs duplicated across multiple Pak: **{duplicate_ids}**\n\n## Important interpretation\n\nXPack stores IDs, not original filenames. `10_KNOWN_PATH_TO_PAK.tsv` reconstructs membership by applying the same `KPakList::FileNameToId` algorithm to known client/config/resource paths and matching the resulting ID against XPack index entries.\n\nAmong Pak files, lower package order wins because KPakList scans packages from first to last. Disk-vs-Pak precedence still depends on runtime `g_SetPakFileMode`; therefore `11_OVERRIDE_ANALYSIS.tsv` reports both sides instead of assuming one.\n\n## Upload back to ChatGPT\n\nPrioritize: `08_XPACK_SUMMARY.tsv`, `10_KNOWN_PATH_TO_PAK.tsv`, `11_OVERRIDE_ANALYSIS.tsv`, `12_CHARACTER_PAK_TRACE.tsv`, `13_DUPLICATE_PAK_IDS.tsv`, `14_V2_REPORT.md`, `07_STATS.json`.\n"""
        write_text_safe(output/"14_V2_REPORT.md",report)
        state_counts=Counter(r[-1] for r in resolver_rows)
        v3_report=f"""# JX CLIENT SCANNER V3 — CHARACTER RESOURCE RESOLVER

Generated: {datetime.now().isoformat(timespec='seconds')}

Client: `{display_safe(client.resolve())}`

## NPCRes parsing

- NPCRes text files parsed: **{len(npcres_files)}**
- Non-empty table cells captured: **{len(npcres_cells)}**
- Resource references discovered in NPCRes cells: **{len(npcres_refs)}**
- Resolver rows: **{len(resolver_rows)}**
- Player/human candidate rows: **{len(player_rows)}**

## Resolver states

- LOOSE_ONLY: **{state_counts.get('LOOSE_ONLY',0)}**
- PAK_ONLY: **{state_counts.get('PAK_ONLY',0)}**
- LOOSE+PAK: **{state_counts.get('LOOSE+PAK',0)}**
- UNRESOLVED: **{state_counts.get('UNRESOLVED',0)}**

## Files to inspect first

- `16_CHARACTER_RESOURCE_REFERENCES.tsv` — exact source table/row/column and raw resource text.
- `17_CHARACTER_RESOLVER.tsv` — resolved path with loose/Pak/order state.
- `18_PLAYER_RESOURCE_CANDIDATES.tsv` — player/human-focused shortlist.
- `12_CHARACTER_PAK_TRACE.tsv` — compatibility trace from V2.

## Upload bundle

Scanner creates `upload\\` automatically after all reports are finished. The root mapping directory still retains every full output file.
"""
        write_text_safe(output/'19_V3_REPORT.md',v3_report)
        result_counts=Counter(r[9] for r in extract_results)
        v4_report=f"""# JX CLIENT SCANNER V4 — NATIVE PAK READER & CHARACTER EXTRACTOR

Generated: {datetime.now().isoformat(timespec='seconds')}

Client: `{display_safe(client.resolve())}`

## Source-grounded XPack behavior

- Native methods implemented: NONE, UCL, UCL_2ND.
- FRAME SPR: rebuilds original SPR from SPRHEAD + palette + per-frame table/data.
- BZIP2 is detected but intentionally marked unsupported because the BZIP2 calls are commented out in the source branch used as reference.

## Compression audit

"""
        for (method,frame),cnt in sorted(compression_counts.items()):
            v4_report += f"- {method}, frame={frame}: **{cnt}** entries\n"
        v4_report += f"""

## Targeted extraction

- Planned character/NpcRes PAK resources: **{len(extract_plan)}**
- Native extraction enabled: **{self.scan_option_native_extract}**
- OK: **{result_counts.get('OK',0)}**
- Failed/unsupported: **{sum(v for k,v in result_counts.items() if k not in ('OK','SKIPPED'))}**
- Extracted binaries folder: `extracted_character\\` (not copied into upload bundle)

## Outputs

- `20_XPACK_COMPRESSION_AUDIT.tsv`
- `21_NATIVE_EXTRACT_PLAN.tsv`
- `22_NATIVE_EXTRACT_RESULTS.tsv`
- `23_V4_REPORT.md`

The upload bundle contains reports/manifests only; extracted binary resources remain in the root mapping folder to avoid creating an oversized upload bundle.
"""
        write_text_safe(output/'23_V4_REPORT.md',v4_report)
        legacy_probe_ok=sum(1 for x in extract_results if 'LEGACY_UCL_PROBE' in x[12])
        v41_report=f"""# JX CLIENT SCANNER V4.2 — SMOOTH SPR ANIMATION + PNG EXPORT

Generated: {datetime.now().isoformat(timespec='seconds')}

## Exact KNpcRes chain

The resolver follows the source chain: CharacterType -> ResFilePath + PartFileName -> part section names -> resource table -> positional action cell -> ComposePathAndName().

- Character rows resolved from exact tables: **{len(exact_rows)}**
- Resolved to loose and/or Pak: **{sum(1 for x in exact_rows if x[20] != 'UNRESOLVED')}**
- Still unresolved: **{sum(1 for x in exact_rows if x[20] == 'UNRESOLVED')}**
- LOOSE_ONLY: **{exact_states.get('LOOSE_ONLY',0)}**
- PAK_ONLY: **{exact_states.get('PAK_ONLY',0)}**
- LOOSE+PAK: **{exact_states.get('LOOSE+PAK',0)}**

## Native extraction

- Targets after exact resolver: **{len(extract_plan)}**
- OK: **{sum(1 for x in extract_results if x[9]=='OK')}**
- Legacy NONE entries successfully verified as UCL probe: **{legacy_probe_ok}**

## SPR Viewer

The second application tab reads standard loose/rebuilt SPR files directly: SPRHEAD, RGB palette, SPROFFS, SPRFRAME and JX RLE blocks. It supports frame navigation, playback and 1x-4x zoom.

## New V4.1 outputs

- `24_EXACT_CHARACTER_PATHS.tsv`
- `25_CHARACTER_CHAIN_SUMMARY.tsv`
- `26_V4_1_REPORT.md`
"""
        write_text_safe(output/'26_V4_1_REPORT.md',v41_report)
        v43_report=f"""# JX CLIENT SCANNER V4.3 — RESOURCE STUDIO

Generated: {datetime.now().isoformat(timespec='seconds')}

## New V4.3 capabilities

- Direct SPR viewing from XPack/PAK: selected entry is decompressed in memory, then passed to SPR Viewer.
- Extract SPR + sidecar TXT with virtual path, hash, Pak/order/entry and NpcRes references.
- Reverse reference graph: `27_RESOURCE_REFERENCE_GRAPH.tsv`.
- Replace Same Path: copies a validated SPR to the exact loose virtual path without changing NpcRes.
- Replace + Relink: backs up affected NpcRes tables, replaces only indexed exact SPR tokens, copies the new SPR beside the old virtual path, and writes `REPLACE_LAST_REPORT.txt`.
- Resource Studio remains conservative: XPack stores hashes only, so browsable paths are paths reconstructed from scanner/mapping knowledge.
"""
        write_text_safe(output/'28_V4_3_REPORT.md',v43_report)
        upload_names=[
            '07_STATS.json','08_XPACK_SUMMARY.tsv','10_KNOWN_PATH_TO_PAK.tsv','11_OVERRIDE_ANALYSIS.tsv',
            '12_CHARACTER_PAK_TRACE.tsv','13_DUPLICATE_PAK_IDS.tsv','14_V2_REPORT.md',
            '15_NPCRES_TABLE_CELLS.tsv','16_CHARACTER_RESOURCE_REFERENCES.tsv','17_CHARACTER_RESOLVER.tsv',
            '18_PLAYER_RESOURCE_CANDIDATES.tsv','19_V3_REPORT.md',
            '20_XPACK_COMPRESSION_AUDIT.tsv','21_NATIVE_EXTRACT_PLAN.tsv','22_NATIVE_EXTRACT_RESULTS.tsv','23_V4_REPORT.md',
            '24_EXACT_CHARACTER_PATHS.tsv','25_CHARACTER_CHAIN_SUMMARY.tsv','26_V4_1_REPORT.md',
            '27_RESOURCE_REFERENCE_GRAPH.tsv','28_V4_3_REPORT.md'
        ]
        copied=copy_upload_bundle(output,upload_names,self.log)
        self._scan_ui_progress(100,"DONE"); self._scan_ui_status("Hoàn tất V4.3.","DONE")
        self.log(""); self.log("HOÀN TẤT V4.3."); self.log(f"Valid XPack: {valid_paks}; resolver rows: {len(resolver_rows)}; player candidates: {len(player_rows)}")
        self.log(f"Kết quả: {output}"); self.log(f"Upload: {output/'upload'}")
        self._scan_disk_log('SCAN COMPLETED successfully')
        self._scan_ui_post(
            'done',True,
            f"Quét hoàn tất.\n\nFolder upload đã tạo với {len(copied)} file:\n{output/'upload'}"
        )


if __name__ == "__main__":
    root=tk.Tk(); app=JXClientScannerV41(root); root.mainloop()
