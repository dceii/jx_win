@echo off
setlocal
cd /d "%~dp0"
title JX Workshop v3

echo ========================================
echo        Starting JX Workshop v3
echo ========================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 "JX_Workshop_v3.py"
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        python "JX_Workshop_v3.py"
    ) else (
        echo [ERROR] Python was not found.
        echo Install Python 3 and enable "Add Python to PATH".
        echo.
        pause
        exit /b 1
    )
)

if not %errorlevel%==0 (
    echo.
    echo [ERROR] JX Workshop exited with an error.
    echo Check the error message above for details.
    pause
)

endlocal
