@echo off
setlocal
title JX Source Intelligence Scanner Launcher
color 0b

echo ========================================================
echo    DANG KHOI CHONG JX SOURCE INTELLIGENCE SCANNER...
echo ========================================================
echo.

:: 1. Kiem tra xem Python da duoc cai dat tren may chua
python --version >nul 2>&1
if %errorlevel% neq 0 (
    color 0c
    echo [LOI]: Khong tim thay Python tren may tinh cua ban!
    echo Vui long tai va cai dat Python tu trang chu: https://www.python.org/
    echo (LUU Y: Khi cai dat, nho tich chon "Add Python to PATH").
    echo.
    pause
    exit /b
)

:: 2. Tu dong tao moi truong ao (venv) neu chua co de co lap thu vien
if not exist "venv" (
    echo [Thong bao]: Dang tao moi truong ao Python (venv) lan dau...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo [LOI]: Khong the tao moi truong ao.
        pause
        exit /b
    )
)

:: 3. Kich hoạt moi truong ao
echo [Thong bao]: Dang kich hoat moi truong ao...
call venv\Scripts\activate.bat

:: 4. Nang cap pip trong moi truong ao cho on dinh
echo [Thong bao]: Dang kiem tra va cap nhat pip...
python -m pip install --upgrade pip >nul 2>&1

:: 5. Cai dat cac dependency neu co file requirements.txt
if exist "requirements.txt" (
    echo [Thong bao]: Dang kiem tra thu vien trong requirements.txt...
    pip install -r requirements.txt
)

echo.
echo ========================================================
echo    HOAN TAT CHUAN BI. DANG MO UNG DUNG...
echo ========================================================
echo.

:: 6. Chay file chinh (.py)
python JX_Source_Intelligence_Scanner_v3_3_FINAL.py

:: 7. Xu ly khi chuong trình dong lai
if %errorlevel% neq 0 (
    echo.
    color 0c
    echo [CANH BAO]: Chuong trinh da ket thuc voi ma loi %errorlevel%.
    pause
) else (
    echo.
    echo [Thong bao]: Chuong trinh da dong. Cam on ban da su dung!
)
